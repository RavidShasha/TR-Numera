import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { User } from '@/api/entities';
import { ProfileUpdateRequest } from '@/api/entities';
import { UploadFile } from '@/api/integrations';
import { FileText, AlertCircle, CheckCircle, Upload, Loader2 } from 'lucide-react';

export default function UpdateProfileRequest() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formState, setFormState] = useState({
    updateType: '',
    reason: '',
    fieldsToUpdate: {}
  });
  const [files, setFiles] = useState([]);
  const [fileUrls, setFileUrls] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const fileInputRef = React.useRef(null);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormState(prev => ({ ...prev, reason: value }));
  };

  const handleSelectChange = (value) => {
    setFormState(prev => ({ ...prev, updateType: value }));

    // Reset fields to update based on selected type
    if (value === 'contact') {
      setFormState(prev => ({
        ...prev,
        fieldsToUpdate: {
          phone_number: '',
          address_street: '',
          address_city: '',
          address_zip_code: ''
        }
      }));
    } else if (value === 'professional') {
      setFormState(prev => ({
        ...prev,
        fieldsToUpdate: {
          profession_level: '', // This would be in freelancer_data
          experience_years: '' // This would be in freelancer_data
        }
      }));
    } else if (value === 'business') {
      setFormState(prev => ({
        ...prev,
        fieldsToUpdate: {
          company_name: '', // This would be in client_data
          business_id_number: '', // This would be in client_data
          industry_type: '' // This would be in client_data
        }
      }));
    } else if (value === 'other') {
      setFormState(prev => ({
        ...prev,
        fieldsToUpdate: {}
      }));
    }
  };

  const handleFieldChange = (name, value) => {
    setFormState(prev => ({
      ...prev,
      fieldsToUpdate: {
        ...prev.fieldsToUpdate,
        [name]: value
      }
    }));
  };

  const handleFileChange = (e) => {
    const selectedFiles = Array.from(e.target.files);
    setFiles(prev => [...prev, ...selectedFiles]);
    // Reset the input
    e.target.value = "";
  };

  const removeFile = (index) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const triggerFileInput = () => {
    fileInputRef.current.click();
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validation
    if (!formState.updateType || !formState.reason) {
      setError('אנא מלא את כל השדות הנדרשים');
      return;
    }

    setIsSubmitting(true);
    setError('');
    setSuccess('');

    try {
      const currentUser = await User.me();

      // Upload files if any
      const uploadedFileUrls = [];
      for (const file of files) {
        const { file_url } = await UploadFile({ file });
        uploadedFileUrls.push(file_url);
      }

      // Create request
      const requestData = {
        user_id: currentUser.id,
        fields_to_update: formState.fieldsToUpdate,
        reason: formState.reason,
        supporting_documents_urls: uploadedFileUrls,
        status: 'pending_approval'
      };

      await ProfileUpdateRequest.create(requestData);

      setSuccess('הבקשה נשלחה בהצלחה ותטופל בהקדם');
      
      // Reset form
      setFormState({
        updateType: '',
        reason: '',
        fieldsToUpdate: {}
      });
      setFiles([]);
      setFileUrls([]);

      // Close dialog after 2 seconds
      setTimeout(() => {
        setIsDialogOpen(false);
        setSuccess('');
      }, 2000);
    } catch (error) {
      console.error('Error submitting request:', error);
      setError('אירעה שגיאה בשליחת הבקשה. אנא נסה שוב מאוחר יותר');
    } finally {
      setIsSubmitting(false);
    }
  };

  const renderFieldsForType = () => {
    if (formState.updateType === 'contact') {
      return (
        <div className="space-y-3">
          <div>
            <Label htmlFor="phone_number">מספר טלפון חדש</Label>
            <Input
              id="phone_number"
              value={formState.fieldsToUpdate.phone_number || ''}
              onChange={(e) => handleFieldChange('phone_number', e.target.value)}
              placeholder="05X-XXXXXXX"
            />
          </div>
          <div>
            <Label htmlFor="address_street">רחוב ומספר בית</Label>
            <Input
              id="address_street"
              value={formState.fieldsToUpdate.address_street || ''}
              onChange={(e) => handleFieldChange('address_street', e.target.value)}
              placeholder="רחוב ומספר בית"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label htmlFor="address_city">עיר</Label>
              <Input
                id="address_city"
                value={formState.fieldsToUpdate.address_city || ''}
                onChange={(e) => handleFieldChange('address_city', e.target.value)}
                placeholder="עיר"
              />
            </div>
            <div>
              <Label htmlFor="address_zip_code">מיקוד</Label>
              <Input
                id="address_zip_code"
                value={formState.fieldsToUpdate.address_zip_code || ''}
                onChange={(e) => handleFieldChange('address_zip_code', e.target.value)}
                placeholder="מיקוד"
              />
            </div>
          </div>
        </div>
      );
    } else if (formState.updateType === 'professional') {
      return (
        <div className="space-y-3">
          <div>
            <Label htmlFor="profession_level">דרגה מקצועית חדשה</Label>
            <Select
              value={formState.fieldsToUpdate.profession_level || ''}
              onValueChange={(value) => handleFieldChange('profession_level', value)}
            >
              <SelectTrigger id="profession_level">
                <SelectValue placeholder="בחר דרגה מקצועית חדשה" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="level_1">סוג 1</SelectItem>
                <SelectItem value="level_2">סוג 2</SelectItem>
                <SelectItem value="level_2_advanced">סוג 2 מתקדם (הנה"ח)</SelectItem>
                <SelectItem value="level_3">סוג 3</SelectItem>
                <SelectItem value="ministry_of_labor">תעודה מטעם משרד הכלכלה</SelectItem>
                <SelectItem value="cpa_chamber">תעודה מטעם לשכת רואי החשבון</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="experience_years">שנות ניסיון</Label>
            <Select
              value={formState.fieldsToUpdate.experience_years || ''}
              onValueChange={(value) => handleFieldChange('experience_years', value)}
            >
              <SelectTrigger id="experience_years">
                <SelectValue placeholder="בחר שנות ניסיון" />
              </SelectTrigger>
              <SelectContent>
                {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 15, 20].map(year => (
                  <SelectItem key={year} value={year.toString()}>
                    {year === 0 ? "פחות משנה" : `${year} שנים`}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      );
    } else if (formState.updateType === 'business') {
      return (
        <div className="space-y-3">
          <div>
            <Label htmlFor="company_name">שם העסק / החברה</Label>
            <Input
              id="company_name"
              value={formState.fieldsToUpdate.company_name || ''}
              onChange={(e) => handleFieldChange('company_name', e.target.value)}
              placeholder="שם העסק או החברה"
            />
          </div>
          <div>
            <Label htmlFor="business_id_number">מספר עוסק / ח.פ.</Label>
            <Input
              id="business_id_number"
              value={formState.fieldsToUpdate.business_id_number || ''}
              onChange={(e) => handleFieldChange('business_id_number', e.target.value)}
              placeholder="מספר עוסק / ח.פ."
            />
          </div>
          <div>
            <Label htmlFor="industry_type">ענף עיסוק</Label>
            <Input
              id="industry_type"
              value={formState.fieldsToUpdate.industry_type || ''}
              onChange={(e) => handleFieldChange('industry_type', e.target.value)}
              placeholder="ענף עיסוק"
            />
          </div>
        </div>
      );
    }

    // For type 'other' we don't display additional fields
    return null;
  };

  return (
    <>
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogTrigger asChild>
          <Button variant="outline" className="gap-2">
            <FileText className="h-4 w-4" />
            הגש בקשת עדכון פרטים
          </Button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>בקשה לעדכון פרטים</DialogTitle>
            <DialogDescription>
              שלח בקשה למנהל המערכת לעדכון פרטיך. בקשה זו תטופל בהקדם.
            </DialogDescription>
          </DialogHeader>

          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {success && (
            <Alert className="bg-green-50 border-green-200">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <AlertDescription className="text-green-700">{success}</AlertDescription>
            </Alert>
          )}

          <form onSubmit={handleSubmit}>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="updateType">סוג העדכון</Label>
                <Select
                  value={formState.updateType}
                  onValueChange={handleSelectChange}
                  required
                >
                  <SelectTrigger id="updateType">
                    <SelectValue placeholder="בחר סוג עדכון" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="contact">פרטי התקשרות</SelectItem>
                    <SelectItem value="professional">פרטים מקצועיים</SelectItem>
                    <SelectItem value="business">פרטי עסק</SelectItem>
                    <SelectItem value="other">אחר</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {formState.updateType && renderFieldsForType()}

              <div className="grid gap-2">
                <Label htmlFor="reason">סיבת הבקשה</Label>
                <Textarea
                  id="reason"
                  value={formState.reason}
                  onChange={handleInputChange}
                  placeholder="נא לציין את סיבת העדכון המבוקש"
                  required
                  className="min-h-[100px]"
                />
              </div>

              <div className="grid gap-2">
                <Label>מסמכים תומכים (אופציונלי)</Label>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  multiple
                  accept="image/*,.pdf"
                  className="hidden"
                />
                
                <div 
                  className="border-2 border-dashed rounded-md p-4 text-center cursor-pointer hover:bg-gray-50 transition-colors"
                  onClick={triggerFileInput}
                >
                  <div className="flex items-center justify-center">
                    <Upload className="h-6 w-6 text-gray-400" />
                  </div>
                  <p className="text-sm mt-2">לחץ להעלאת מסמכים תומכים</p>
                  <p className="text-xs text-gray-500">(למשל: תעודות מקצועיות חדשות, אישורים רשמיים)</p>
                </div>

                {files.length > 0 && (
                  <ul className="mt-3 space-y-2">
                    {files.map((file, index) => (
                      <li key={index} className="flex items-center justify-between bg-gray-50 p-2 rounded-md text-sm">
                        <div className="flex items-center">
                          <FileText className="h-4 w-4 text-blue-500 mr-2 rtl:ml-2 rtl:mr-0" />
                          <span className="truncate max-w-[200px]">{file.name}</span>
                        </div>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="h-6 w-6 p-0"
                          onClick={() => removeFile(index)}
                        >
                          <AlertCircle className="h-4 w-4 text-red-500" />
                        </Button>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>

            <DialogFooter>
              <Button 
                type="submit" 
                disabled={isSubmitting}
                className="gap-2 bg-blue-600 hover:bg-blue-700"
              >
                {isSubmitting && <Loader2 className="h-4 w-4 animate-spin" />}
                שלח בקשה
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
}