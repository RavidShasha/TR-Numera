import React, { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { UploadFile } from '@/api/integrations';
import { ProjectFile } from '@/api/entities';
import { User } from '@/api/entities';
import { Upload, AlertCircle, Check, Loader2 } from 'lucide-react';

export default function FileUploader({ projectId, onFileUploaded }) {
  const [file, setFile] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const fileInputRef = useRef(null);

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setError('');
      setSuccess(false);
    }
  };

  const simulateProgress = () => {
    // Simulate progress since UploadFile doesn't provide real-time progress
    setUploadProgress(0);
    const interval = setInterval(() => {
      setUploadProgress(prev => {
        const newProgress = prev + Math.random() * 10;
        return newProgress > 90 ? 90 : newProgress; // Max at 90% until actual completion
      });
    }, 300);
    
    return interval;
  };

  const handleUpload = async () => {
    if (!file) {
      setError('אנא בחר קובץ להעלאה');
      return;
    }

    if (!projectId) {
      setError('מזהה פרויקט חסר');
      return;
    }

    setIsUploading(true);
    setError('');
    setSuccess(false);

    const progressInterval = simulateProgress();

    try {
      // Upload the file using Core integration
      const { file_url } = await UploadFile({ file });

      // Get current user (to mark as uploader)
      const user = await User.me();

      // Create a ProjectFile record
      const newFile = await ProjectFile.create({
        project_id: projectId,
        filename: file.name,
        file_url: file_url,
        uploaded_by_id: user.id,
        file_type: file.type,
        file_size: file.size
      });

      // Complete the progress
      setUploadProgress(100);
      
      // Show success and reset
      setSuccess(true);
      setFile(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }

      // Notify parent component
      if (onFileUploaded) {
        onFileUploaded(newFile);
      }

      // Reset success message after a delay
      setTimeout(() => {
        setSuccess(false);
      }, 3000);

    } catch (error) {
      console.error('Error uploading file:', error);
      setError('אירעה שגיאה בהעלאת הקובץ. אנא נסה שנית.');
    } finally {
      clearInterval(progressInterval);
      setIsUploading(false);
    }
  };

  return (
    <div className="space-y-4">
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="bg-green-50 border-green-200">
          <Check className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-700">הקובץ הועלה בהצלחה!</AlertDescription>
        </Alert>
      )}

      <div className="flex items-center gap-3">
        <input
          type="file"
          onChange={handleFileChange}
          ref={fileInputRef}
          className="block w-full text-sm text-gray-500
            file:mr-4 file:py-2 file:px-4
            file:rounded-md file:border-0
            file:text-sm file:font-medium
            file:bg-blue-50 file:text-blue-700
            hover:file:bg-blue-100
            file:cursor-pointer"
          disabled={isUploading}
        />
        <Button
          onClick={handleUpload}
          disabled={isUploading || !file}
        >
          {isUploading ? (
            <>
              <Loader2 className="mr-2 rtl:ml-2 rtl:mr-0 h-4 w-4 animate-spin" />
              מעלה...
            </>
          ) : (
            <>
              <Upload className="mr-2 rtl:ml-2 rtl:mr-0 h-4 w-4" />
              העלה
            </>
          )}
        </Button>
      </div>

      {isUploading && (
        <Progress 
          value={uploadProgress} 
          className="h-2"
        />
      )}

      {file && !isUploading && !success && (
        <div className="text-sm text-gray-500">
          נבחר: {file.name} ({(file.size / 1024 / 1024).toFixed(2)} MB)
        </div>
      )}
    </div>
  );
}