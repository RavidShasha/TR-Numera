
import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Loader2, User as UserIcon, Edit3, Trash2, ShieldCheck, ShieldAlert, MoreHorizontal, Check, X, Search, Filter, Eye, Users } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ProfileUpdateRequest } from '@/api/entities';


export default function AdminUsersPage() {
  const [users, setUsers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all'); // For freelancers: pending, approved, rejected

  const [selectedUser, setSelectedUser] = useState(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDeleteAlertOpen, setIsDeleteAlertOpen] = useState(false);
  const [isApprovalModalOpen, setIsApprovalModalOpen] = useState(false);
  const [adminNotes, setAdminNotes] = useState('');

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    setIsLoading(true);
    try {
      const allUsers = await User.list('-created_date');
      setUsers(allUsers);
    } catch (error) {
      console.error("Error fetching users:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleApproveFreelancer = async () => {
    if (!selectedUser || selectedUser.role !== 'freelancer') return;
    try {
      await User.update(selectedUser.id, { 
        freelancer_data: { 
          ...selectedUser.freelancer_data, 
          is_approved: true,
          approval_status: 'approved', // Assuming new field
          approval_admin_notes: adminNotes || 'אושר על ידי מנהל',
          approved_by_admin_id: (await User.me()).id, // Assuming current admin user
          approval_date: new Date().toISOString()
        }
      });
      // Create a notification for the user
      // await Notification.create({ user_id: selectedUser.id, title: "פרופיל הפרילנסר שלך אושר!", message: "כעת תוכל להגיש הצעות לפרויקטים.", type: "profile_update_status", related_entity_id: selectedUser.id, related_entity_type: "User" });
      setAdminNotes('');
      setIsApprovalModalOpen(false);
      fetchUsers(); // Refresh list
    } catch (error) {
      console.error("Error approving freelancer:", error);
    }
  };
  
  const handleRejectFreelancer = async () => {
    if (!selectedUser || selectedUser.role !== 'freelancer' || !adminNotes) {
        alert("יש למלא הערות לדחיית הפרילנסר.");
        return;
    }
    try {
      await User.update(selectedUser.id, { 
        freelancer_data: { 
          ...selectedUser.freelancer_data, 
          is_approved: false,
          approval_status: 'rejected', // Assuming new field
          approval_admin_notes: adminNotes,
          approved_by_admin_id: (await User.me()).id,
          approval_date: new Date().toISOString()
        } 
      });
       // Create a notification for the user
      // await Notification.create({ user_id: selectedUser.id, title: "בקשת אישור הפרופיל שלך נדחתה", message: `סיבת הדחייה: ${adminNotes}. אנא תקן את הפרטים הנדרשים ונסה שנית או פנה לתמיכה.`, type: "profile_update_status", related_entity_id: selectedUser.id, related_entity_type: "User" });
      setAdminNotes('');
      setIsApprovalModalOpen(false);
      fetchUsers(); // Refresh list
    } catch (error) {
      console.error("Error rejecting freelancer:", error);
    }
  };

  // Placeholder for actual delete - User deletion is sensitive
  const handleDeleteUser = async () => {
    if (!selectedUser) return;
    console.warn(`Attempting to delete user ${selectedUser.id} - This should be a soft delete or disable.`);
    // For now, just close and refresh
    setIsDeleteAlertOpen(false);
    // fetchUsers(); // If actual delete/disable happens
  };
  
  const openApprovalModal = (user, notes = '') => {
    setSelectedUser(user);
    setAdminNotes(notes); // Pre-fill notes if available (e.g. from ProfileUpdateRequest)
    setIsApprovalModalOpen(true);
  };

  const filteredUsers = users.filter(user => {
    const searchMatch = searchTerm.trim() === '' || 
                        user.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        user.email?.toLowerCase().includes(searchTerm.toLowerCase());
    const roleMatch = roleFilter === 'all' || user.role === roleFilter;
    
    let statusMatch = true;
    if (roleFilter === 'freelancer' && statusFilter !== 'all') {
        if (statusFilter === 'pending') {
            statusMatch = user.freelancer_data?.is_approved === undefined || user.freelancer_data?.is_approved === null || user.freelancer_data?.approval_status === 'pending_approval';
        } else if (statusFilter === 'approved') {
            statusMatch = user.freelancer_data?.is_approved === true || user.freelancer_data?.approval_status === 'approved';
        } else if (statusFilter === 'rejected') {
            statusMatch = user.freelancer_data?.is_approved === false && user.freelancer_data?.approval_status === 'rejected';
        }
    }

    return searchMatch && roleMatch && statusMatch;
  });

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-80">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    );
  }
  
  const getFreelancerStatusBadge = (freelancerData) => {
    if (!freelancerData) return <Badge variant="outline">לא פרילנסר</Badge>;
    
    // Use approval_status if it exists, otherwise fallback to is_approved
    const status = freelancerData.approval_status; 
    const isApproved = freelancerData.is_approved;

    if (status === 'approved' || (status === undefined && isApproved === true) ) {
        return <Badge className="bg-green-100 text-green-700"><ShieldCheck className="h-3 w-3 mr-1 rtl:ml-1 rtl:mr-0" />מאושר</Badge>;
    } else if (status === 'rejected' || (status === undefined && isApproved === false && freelancerData.approval_admin_notes)) {
        return <Badge variant="destructive"><ShieldAlert className="h-3 w-3 mr-1 rtl:ml-1 rtl:mr-0" />נדחה</Badge>;
    } else if (status === 'pending_approval' || isApproved === undefined || isApproved === null) {
        return <Badge className="bg-yellow-100 text-yellow-700"><ShieldAlert className="h-3 w-3 mr-1 rtl:ml-1 rtl:mr-0" />ממתין לאישור</Badge>;
    }
    return <Badge variant="outline">סטטוס לא ידוע</Badge>;
  };


  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <CardTitle className="text-2xl flex items-center">
              <Users className="h-6 w-6 mr-2 rtl:ml-2 rtl:mr-0 text-blue-600" />
              ניהול משתמשים
            </CardTitle>
            <CardDescription>צפייה, עריכה וניהול של כל המשתמשים במערכת.</CardDescription>
          </div>
           {/* <Button>הוסף משתמש חדש</Button> // Future: Manual user creation by admin */}
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 rtl:right-2.5 rtl:left-auto top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="חפש לפי שם או אימייל"
                className="pl-8 rtl:pr-8 rtl:pl-4"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Select value={roleFilter} onValueChange={setRoleFilter}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <SelectValue placeholder="סנן לפי תפקיד" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">כל התפקידים</SelectItem>
                <SelectItem value="admin">מנהלים</SelectItem>
                <SelectItem value="freelancer">פרילנסרים</SelectItem>
                <SelectItem value="client">לקוחות</SelectItem>
              </SelectContent>
            </Select>
            {roleFilter === 'freelancer' && (
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full sm:w-[180px]">
                  <SelectValue placeholder="סנן לפי סטטוס אישור" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">כל הסטטוסים</SelectItem>
                  <SelectItem value="pending">ממתין לאישור</SelectItem>
                  <SelectItem value="approved">מאושר</SelectItem>
                  <SelectItem value="rejected">נדחה</SelectItem>
                </SelectContent>
              </Select>
            )}
          </div>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>שם מלא</TableHead>
                <TableHead>דוא"ל</TableHead>
                <TableHead>תפקיד</TableHead>
                <TableHead>סטטוס (פרילנסר)</TableHead>
                <TableHead>תאריך הצטרפות</TableHead>
                <TableHead className="text-right">פעולות</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredUsers.map(user => (
                <TableRow key={user.id}>
                  <TableCell className="font-medium">{user.full_name || 'לא הוגדר'}</TableCell>
                  <TableCell>{user.email}</TableCell>
                  <TableCell>
                    <Badge variant={
                      user.role === 'admin' ? 'default' : 
                      user.role === 'freelancer' ? 'secondary' : 'outline'
                    }>
                      {user.role === 'admin' && 'מנהל'}
                      {user.role === 'freelancer' && 'פרילנסר'}
                      {user.role === 'client' && 'לקוח'}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {user.role === 'freelancer' ? getFreelancerStatusBadge(user.freelancer_data) : 'N/A'}
                  </TableCell>
                  <TableCell>{new Date(user.created_date).toLocaleDateString('he-IL')}</TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>פעולות</DropdownMenuLabel>
                        <DropdownMenuItem onClick={() => { /* Implement view profile */ }}>
                          <Eye className="h-4 w-4 mr-2 rtl:ml-2 rtl:mr-0" />
                          צפה בפרופיל
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => { setSelectedUser(user); setIsEditModalOpen(true); }}>
                          <Edit3 className="h-4 w-4 mr-2 rtl:ml-2 rtl:mr-0" />
                          ערוך פרטים (בסיסי)
                        </DropdownMenuItem>
                        {user.role === 'freelancer' && (!user.freelancer_data?.is_approved || user.freelancer_data?.approval_status !== 'approved' ) && (
                            <DropdownMenuItem onClick={() => openApprovalModal(user)}>
                                <ShieldCheck className="h-4 w-4 mr-2 rtl:ml-2 rtl:mr-0" />
                                אשר/דחה פרילנסר
                            </DropdownMenuItem>
                        )}
                        <DropdownMenuSeparator />
                        <DropdownMenuItem 
                            className="text-red-600 focus:text-red-700 focus:bg-red-50"
                            onClick={() => { setSelectedUser(user); setIsDeleteAlertOpen(true); }}
                        >
                          <Trash2 className="h-4 w-4 mr-2 rtl:ml-2 rtl:mr-0" />
                          מחק משתמש (לא פעיל)
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          {filteredUsers.length === 0 && (
            <div className="text-center py-10 text-gray-500">
              לא נמצאו משתמשים התואמים את החיפוש או הסינון.
            </div>
          )}
        </CardContent>
      </Card>

      {/* Edit User Modal (Basic) */}
      <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>עריכת פרטי משתמש (בסיסי)</DialogTitle>
            <DialogDescription>
              כאן תוכל לערוך פרטים בסיסיים של המשתמש. שינויים מורכבים יותר דורשים טיפול מיוחד.
            </DialogDescription>
          </DialogHeader>
          {selectedUser && (
            <div className="py-4 space-y-3">
              <div>
                <Label htmlFor="edit-fullname">שם מלא</Label>
                <Input id="edit-fullname" defaultValue={selectedUser.full_name} />
              </div>
              <div>
                <Label htmlFor="edit-email">דוא"ל (לא ניתן לשינוי)</Label>
                <Input id="edit-email" value={selectedUser.email} disabled />
              </div>
               <div>
                <Label htmlFor="edit-role">תפקיד</Label>
                 <Select defaultValue={selectedUser.role}>
                    <SelectTrigger id="edit-role">
                        <SelectValue/>
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="client">לקוח</SelectItem>
                        <SelectItem value="freelancer">פרילנסר</SelectItem>
                        <SelectItem value="admin">מנהל</SelectItem>
                    </SelectContent>
                 </Select>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditModalOpen(false)}>ביטול</Button>
            <Button onClick={() => { /* Implement save logic */ setIsEditModalOpen(false); }}>שמור שינויים</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete User Confirmation */}
      <AlertDialog open={isDeleteAlertOpen} onOpenChange={setIsDeleteAlertOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>אישור מחיקת משתמש</AlertDialogTitle>
            <AlertDialogDescription>
              האם אתה בטוח שברצונך למחוק את המשתמש {selectedUser?.full_name}? 
              פעולה זו (כרגע) אינה מוחקת בפועל אלא מדמה את התהליך.
              מחיקה בפועל צריכה להיות מלווה במנגנון "מחיקה רכה" או השבתה.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>ביטול</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteUser} className="bg-red-600 hover:bg-red-700">
              מחק (דמה)
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Freelancer Approval Modal */}
      <Dialog open={isApprovalModalOpen} onOpenChange={setIsApprovalModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>אישור/דחיית פרילנסר: {selectedUser?.full_name}</DialogTitle>
            <DialogDescription>
              בדוק את פרטי הפרילנסר לפני אישור או דחייה.
              ניתן לצפות בפרופיל המלא שלו דרך רשימת המשתמשים.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-3">
            <div>
                <Label htmlFor="adminNotes">הערות מנהל (נדרש לדחייה)</Label>
                <Textarea 
                    id="adminNotes" 
                    value={adminNotes} 
                    onChange={(e) => setAdminNotes(e.target.value)}
                    placeholder="הסבר קצר לאישור או סיבת הדחייה" 
                />
            </div>
            {selectedUser?.freelancer_data?.professional_certificate_url && (
                <div>
                    <Label>תעודת מקצוע:</Label>
                    <a href={selectedUser.freelancer_data.professional_certificate_url} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline block truncate">
                        {selectedUser.freelancer_data.professional_certificate_url}
                    </a>
                </div>
            )}
            {selectedUser?.id_card_url && (
                <div>
                    <Label>צילום ת.ז.:</Label>
                    <a href={selectedUser.id_card_url} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline block truncate">
                        {selectedUser.id_card_url}
                    </a>
                </div>
            )}
          </div>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button variant="outline" onClick={() => setIsApprovalModalOpen(false)}>ביטול</Button>
            <Button onClick={handleRejectFreelancer} variant="destructive" disabled={!adminNotes}>
                <X className="h-4 w-4 mr-2 rtl:ml-2 rtl:mr-0" /> דחה פרופיל
            </Button>
            <Button onClick={handleApproveFreelancer} className="bg-green-600 hover:bg-green-700">
                <Check className="h-4 w-4 mr-2 rtl:ml-2 rtl:mr-0" /> אשר פרופיל
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

    </div>
  );
}
