import React, { useState, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Project } from '@/api/entities';
import { ServiceCategory } from '@/api/entities';
import { User } from '@/api/entities';
import { Briefcase, Search, Filter, Star, Loader2, AlertCircle, Heart } from 'lucide-react';
import { FavoriteProject } from '@/api/entities'; // Ensure this entity exists

export default function SearchProjectsPage() {
  const [user, setUser] = useState(null);
  const [projects, setProjects] = useState([]);
  const [categories, setCategories] = useState([]);
  const [clients, setClients] = useState([]);
  const [favoriteProjectIds, setFavoriteProjectIds] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [projectType, setProjectType] = useState('all');
  const [budgetMin, setBudgetMin] = useState('');
  const [budgetMax, setBudgetMax] = useState('');
  const [isUrgent, setIsUrgent] = useState(false);
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const currentUser = await User.me().catch(() => null);
        setUser(currentUser);

        if (currentUser && currentUser.role === 'freelancer') {
          const favs = await FavoriteProject.filter({ user_id: currentUser.id });
          setFavoriteProjectIds(favs.map(fav => fav.project_id));
        }
        
        const [allProjects, allCategories, allClients] = await Promise.all([
          Project.list('-created_date'), // Fetch all projects initially
          ServiceCategory.list(),
          User.filter({ role: 'client' }) // Fetch users who are clients
        ]);

        setProjects(allProjects.filter(p => p.status === 'open')); // Only show open projects
        setCategories(allCategories);
        setClients(allClients);

      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  const getClientName = (clientId) => {
    const client = clients.find(c => c.id === clientId);
    return client ? client.full_name : 'לקוח אנונימי';
  };

  const getCategoryNames = (categoryIds) => {
    if (!categoryIds || !categories.length) return [];
    return categoryIds.map(id => {
      const category = categories.find(c => c.id === id);
      return category ? category.name : '';
    }).filter(Boolean);
  };

  const handleCategoryChange = (categoryId) => {
    setSelectedCategories(prev => 
      prev.includes(categoryId) 
        ? prev.filter(id => id !== categoryId)
        : [...prev, categoryId]
    );
  };
  
  const toggleFavorite = async (projectId) => {
    if (!user || user.role !== 'freelancer') {
      // Could show a login prompt or redirect
      alert("עליך להתחבר כפרילנסר כדי להוסיף למועדפים.");
      return;
    }

    try {
      if (favoriteProjectIds.includes(projectId)) {
        const favToDelete = await FavoriteProject.filter({ user_id: user.id, project_id: projectId });
        if (favToDelete.length > 0) {
          await FavoriteProject.delete(favToDelete[0].id);
        }
        setFavoriteProjectIds(prev => prev.filter(id => id !== projectId));
      } else {
        await FavoriteProject.create({ user_id: user.id, project_id: projectId });
        setFavoriteProjectIds(prev => [...prev, projectId]);
      }
    } catch (error) {
      console.error("Error toggling favorite:", error);
      alert("שגיאה בעידכון מועדפים.");
    }
  };

  const filteredProjects = projects
    .filter(project => {
      const titleMatch = project.title.toLowerCase().includes(searchTerm.toLowerCase());
      const descriptionMatch = project.description.toLowerCase().includes(searchTerm.toLowerCase());
      const categoryMatch = selectedCategories.length === 0 || 
                            project.service_category_ids.some(id => selectedCategories.includes(id));
      const typeMatch = projectType === 'all' || project.project_type === projectType;
      const budgetMinMatch = budgetMin === '' || (project.budget_min && project.budget_min >= parseInt(budgetMin));
      const budgetMaxMatch = budgetMax === '' || (project.budget_max && project.budget_max <= parseInt(budgetMax));
      const urgentMatch = !isUrgent || project.is_urgent;
      
      return (titleMatch || descriptionMatch) && categoryMatch && typeMatch && budgetMinMatch && budgetMaxMatch && urgentMatch;
    })
    .sort((a, b) => new Date(b.created_date) - new Date(a.created_date));

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-80">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto text-blue-600" />
          <p className="mt-2">טוען פרויקטים...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 px-4 sm:px-6 lg:px-8">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-center text-gray-800">חפש פרויקטים</h1>
        <p className="text-center text-gray-600 mt-2">
          מצא את הפרויקט הבא שלך מבין מגוון רחב של הצעות
        </p>
      </header>

      <div className="flex flex-col md:flex-row gap-6">
        {/* Filters Section */}
        <aside className={`md:w-1/4 ${showFilters ? 'block' : 'hidden'} md:block`}>
          <Card className="sticky top-24">
            <CardHeader>
              <CardTitle className="text-lg flex items-center">
                <Filter className="h-5 w-5 mr-2 rtl:ml-2 rtl:mr-0 text-blue-600" />
                סנן תוצאות
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <Label className="font-semibold">תחומי שירות</Label>
                <div className="mt-2 space-y-2 max-h-60 overflow-y-auto">
                  {categories.map(category => (
                    <div key={category.id} className="flex items-center">
                      <Checkbox 
                        id={`cat-${category.id}`}
                        checked={selectedCategories.includes(category.id)}
                        onCheckedChange={() => handleCategoryChange(category.id)}
                      />
                      <Label htmlFor={`cat-${category.id}`} className="ml-2 rtl:mr-2 rtl:ml-0 cursor-pointer">
                        {category.name}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <Label htmlFor="projectType" className="font-semibold">סוג פרויקט</Label>
                <Select value={projectType} onValueChange={setProjectType}>
                  <SelectTrigger id="projectType">
                    <SelectValue placeholder="הכל" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">הכל</SelectItem>
                    <SelectItem value="one_time">חד פעמי</SelectItem>
                    <SelectItem value="ongoing">מתמשך</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="font-semibold">טווח תקציב (₪)</Label>
                <div className="flex gap-2 mt-1">
                  <Input 
                    type="number" 
                    placeholder="מינימום" 
                    value={budgetMin}
                    onChange={(e) => setBudgetMin(e.target.value)}
                  />
                  <Input 
                    type="number" 
                    placeholder="מקסימום" 
                    value={budgetMax}
                    onChange={(e) => setBudgetMax(e.target.value)}
                  />
                </div>
              </div>

              <div className="flex items-center space-x-2 rtl:space-x-reverse">
                <Checkbox 
                  id="isUrgent"
                  checked={isUrgent}
                  onCheckedChange={setIsUrgent}
                />
                <Label htmlFor="isUrgent" className="cursor-pointer font-semibold">הצג פרויקטים דחופים בלבד</Label>
              </div>
            </CardContent>
          </Card>
        </aside>

        {/* Projects List Section */}
        <main className="md:w-3/4">
          <div className="mb-6 flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 rtl:right-2.5 rtl:left-auto top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="חפש לפי כותרת, תיאור..."
                className="pl-8 rtl:pr-8 rtl:pl-4"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Button 
              variant="outline" 
              className="md:hidden"
              onClick={() => setShowFilters(!showFilters)}
            >
              <Filter className="h-4 w-4 mr-2 rtl:ml-2 rtl:mr-0" />
              {showFilters ? 'הסתר מסננים' : 'הצג מסננים'}
            </Button>
            <div className="text-sm text-gray-500 sm:text-right">
              נמצאו {filteredProjects.length} פרויקטים
            </div>
          </div>

          {filteredProjects.length > 0 ? (
            <div className="space-y-4">
              {filteredProjects.map(project => (
                <Card key={project.id} className="hover:shadow-md transition-shadow overflow-hidden">
                  <CardContent className="p-5">
                    <div className="flex flex-col sm:flex-row justify-between items-start mb-2">
                      <Link to={createPageUrl(`Project?id=${project.id}`)} className="block">
                        <h3 className="text-lg font-semibold text-blue-700 hover:text-blue-800 transition-colors">{project.title}</h3>
                      </Link>
                      {user && user.role === 'freelancer' && (
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="text-gray-400 hover:text-red-500"
                          onClick={() => toggleFavorite(project.id)}
                        >
                          <Heart className={`h-5 w-5 ${favoriteProjectIds.includes(project.id) ? 'fill-red-500 text-red-500' : ''}`} />
                        </Button>
                      )}
                    </div>
                    <p className="text-sm text-gray-500 mb-1">
                      פורסם על ידי: {getClientName(project.client_id)}
                      <span className="mx-2">|</span>
                      פורסם בתאריך: {new Date(project.created_date).toLocaleDateString('he-IL')}
                    </p>
                    <p className="text-gray-700 text-sm line-clamp-3 mb-3">{project.description}</p>
                    
                    <div className="flex flex-wrap gap-1.5 mb-3">
                      {getCategoryNames(project.service_category_ids).map((name, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">{name}</Badge>
                      ))}
                    </div>
                    
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center text-sm">
                      <div className="space-x-3 rtl:space-x-reverse text-gray-600 mb-2 sm:mb-0">
                        {project.budget_min && project.budget_max ? (
                          <span>תקציב: ₪{project.budget_min} - ₪{project.budget_max}</span>
                        ) : project.budget_min ? (
                          <span>תקציב: מ-₪{project.budget_min}</span>
                        ) : project.budget_max ? (
                          <span>תקציב: עד ₪{project.budget_max}</span>
                        ) : (
                          <span>תקציב: לא צוין</span>
                        )}
                        <span>סוג: {project.project_type === 'one_time' ? 'חד פעמי' : 'מתמשך'}</span>
                        {project.is_urgent && <Badge className="bg-red-100 text-red-700">דחוף</Badge>}
                      </div>
                      <Button size="sm" asChild>
                        <Link to={createPageUrl(`Project?id=${project.id}`)}>צפה בפרויקט והגש הצעה</Link>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-16 bg-gray-50 rounded-lg">
              <div className="bg-gray-100 inline-flex rounded-full p-4 mb-4">
                 <Briefcase className="h-8 w-8 text-gray-400" />
              </div>
              <h3 className="text-xl font-medium text-gray-900 mb-2">לא נמצאו פרויקטים</h3>
              <p className="text-gray-500">נסה לשנות את תנאי החיפוש או בדוק שוב מאוחר יותר.</p>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}