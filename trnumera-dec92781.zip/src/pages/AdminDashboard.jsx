import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { User } from '@/api/entities';
import { Project } from '@/api/entities';
import { Proposal } from '@/api/entities';
import { ProfileUpdateRequest } from '@/api/entities';
import { ServiceCategory } from '@/api/entities';

import { 
  Users, Shield, Settings, Briefcase, AlertTriangle, UserCheck, FilePen, FileCheck, 
  ChevronUp, ListChecks, Loader2, HelpCircle, CheckCircle, Activity 
} from 'lucide-react';

export default function AdminDashboardPage() {
  const [user, setUser] = useState(null);
  const [stats, setStats] = useState({
    totalUsers: 0,
    activeFreelancers: 0,
    activeClients: 0,
    pendingFreelancers: 0,
    pendingProjects: 0,
    updateRequests: 0
  });
  const [isLoading, setIsLoading] = useState(true);
  const [pendingFreelancers, setPendingFreelancers] = useState([]);
  const [updateRequests, setUpdateRequests] = useState([]);
  const [recentProjects, setRecentProjects] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Get current user (admin)
        const currentUser = await User.me();
        setUser(currentUser);

        // Verify this is an admin
        if (currentUser?.role !== 'admin') {
          // Redirect non-admins (should be handled by the layout/router too)
          window.location.href = createPageUrl('Home');
          return;
        }

        // Fetch all users
        const allUsers = await User.list();
        const freelancers = allUsers.filter(u => u?.role === 'freelancer');
        const clients = allUsers.filter(u => u?.role === 'client');
        const pendingFreelancersList = freelancers.filter(
          f => f?.freelancer_data && f?.freelancer_data?.is_approved === false
        );
        setPendingFreelancers(pendingFreelancersList.slice(0, 5)); // Get latest 5 for display

        // Fetch profile update requests
        const profileRequests = await ProfileUpdateRequest.list('-created_date');
        const pendingRequests = profileRequests.filter(r => r.status === 'pending');
        setUpdateRequests(pendingRequests.slice(0, 5)); // Get latest 5 for display

        // Fetch recent projects
        const recentProjectsList = await Project.list('-created_date', 5);
        setRecentProjects(recentProjectsList);

        // Set stats
        setStats({
          totalUsers: allUsers.length,
          activeFreelancers: freelancers.filter(f => 
            f?.freelancer_data?.is_approved === true && f?.is_active === true
          ).length,
          activeClients: clients.filter(c => c?.is_active === true).length,
          pendingFreelancers: pendingFreelancersList.length,
          pendingProjects: recentProjectsList.filter(p => p.status === 'open').length,
          updateRequests: pendingRequests.length
        });

      } catch (error) {
        console.error('Error fetching admin data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  // Helper function for formatting dates
  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('he-IL');
  };

  // Get badge for project status
  const getProjectStatusBadge = (status) => {
    switch (status) {
      case 'open':
        return <Badge className="bg-blue-100 text-blue-800">פתוח להצעות</Badge>;
      case 'in_progress':
        return <Badge className="bg-green-100 text-green-800">בתהליך</Badge>;
      case 'pending_payment':
        return <Badge className="bg-amber-100 text-amber-800">ממתין לתשלום</Badge>;
      case 'completed':
        return <Badge className="bg-purple-100 text-purple-800">הושלם</Badge>;
      case 'paid':
        return <Badge className="bg-emerald-100 text-emerald-800">שולם</Badge>;
      case 'cancelled_by_client':
      case 'cancelled_by_freelancer':
      case 'cancelled_by_admin':
        return <Badge variant="destructive">בוטל</Badge>;
      default:
        return null;
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-80">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto text-blue-600" />
          <p className="mt-2">טוען נתונים...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">לוח בקרה למנהל מערכת</h1>
          <p className="text-gray-500">ניהול משתמשים, פרויקטים וקטגוריות</p>
        </div>
        <div className="flex items-center space-x-2 rtl:space-x-reverse">
          <Badge className="bg-indigo-100 text-indigo-800 px-3">מנהל</Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex justify-between">
              <div>
                <p className="text-muted-foreground mb-1">משתמשים פעילים</p>
                <div className="flex items-baseline">
                  <span className="text-3xl font-bold">
                    {stats.activeFreelancers + stats.activeClients}
                  </span>
                  <span className="text-muted-foreground text-sm mx-2">משתמשים</span>
                </div>
                <div className="flex items-center text-sm text-muted-foreground mt-2">
                  <div className="mr-4 rtl:ml-4 rtl:mr-0">
                    <span className="font-medium text-blue-600">{stats.activeFreelancers}</span> פרילנסרים
                  </div>
                  <div>
                    <span className="font-medium text-green-600">{stats.activeClients}</span> לקוחות
                  </div>
                </div>
              </div>
              <div className="p-2 bg-purple-100 text-purple-700 rounded-lg self-start">
                <Users className="h-6 w-6" />
              </div>
            </div>
          </CardContent>
          <CardFooter className="pt-0">
            <Button variant="outline" className="w-full text-sm" asChild>
              <Link to={createPageUrl('AdminUsers')}>
                נהל משתמשים
              </Link>
            </Button>
          </CardFooter>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex justify-between">
              <div>
                <p className="text-muted-foreground mb-1">אישורים ממתינים</p>
                <div className="flex items-baseline">
                  <span className="text-3xl font-bold">{stats.pendingFreelancers}</span>
                  <span className="text-muted-foreground text-sm mx-2">פרילנסרים ממתינים</span>
                </div>
                <div className="text-sm text-muted-foreground mt-2">
                  עוד <span className="font-medium text-amber-600">{stats.updateRequests}</span> בקשות עדכון פרטים
                </div>
              </div>
              <div className="p-2 bg-amber-100 text-amber-700 rounded-lg self-start">
                <AlertTriangle className="h-6 w-6" />
              </div>
            </div>
          </CardContent>
          <CardFooter className="pt-0">
            <Button variant="outline" className="w-full text-sm" asChild>
              <Link to={createPageUrl('AdminApprovals')}>
                אשר משתמשים
              </Link>
            </Button>
          </CardFooter>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex justify-between">
              <div>
                <p className="text-muted-foreground mb-1">פרויקטים פתוחים</p>
                <div className="flex items-baseline">
                  <span className="text-3xl font-bold">{stats.pendingProjects}</span>
                  <span className="text-muted-foreground text-sm mx-2">פרויקטים ממתינים</span>
                </div>
                <div className="text-sm text-muted-foreground mt-2">
                  פרויקטים פתוחים להצעות מפרילנסרים
                </div>
              </div>
              <div className="p-2 bg-blue-100 text-blue-700 rounded-lg self-start">
                <Briefcase className="h-6 w-6" />
              </div>
            </div>
          </CardContent>
          <CardFooter className="pt-0">
            <Button variant="outline" className="w-full text-sm" asChild>
              <Link to={createPageUrl('AdminProjects')}>
                נהל פרויקטים
              </Link>
            </Button>
          </CardFooter>
        </Card>
      </div>

      <Tabs defaultValue="freelancers">
        <TabsList className="grid grid-cols-3 mb-4">
          <TabsTrigger value="freelancers">פרילנסרים ממתינים לאישור</TabsTrigger>
          <TabsTrigger value="updates">בקשות עדכון פרטים</TabsTrigger>
          <TabsTrigger value="projects">פרויקטים אחרונים</TabsTrigger>
        </TabsList>
        <TabsContent value="freelancers">
          <Card>
            <CardHeader>
              <CardTitle>פרילנסרים ממתינים לאישור</CardTitle>
              <CardDescription>
                פרילנסרים שנרשמו וממתינים לאישור המנהל להתחיל לעבוד במערכת
              </CardDescription>
            </CardHeader>
            <CardContent>
              {pendingFreelancers.length === 0 ? (
                <div className="text-center py-8">
                  <div className="bg-green-100 inline-flex rounded-full p-3 mb-4">
                    <CheckCircle className="h-6 w-6 text-green-500" />
                  </div>
                  <p className="text-muted-foreground">אין פרילנסרים ממתינים לאישור כרגע</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {pendingFreelancers.map(freelancer => (
                    <div key={freelancer.id} className="border-b pb-3 flex items-center justify-between">
                      <div>
                        <p className="font-medium">{freelancer.full_name}</p>
                        <div className="flex flex-col sm:flex-row sm:items-center mt-1 text-sm text-gray-500">
                          <span>
                            {freelancer.freelancer_data?.profession === 'accountant' && 'רואה חשבון'}
                            {freelancer.freelancer_data?.profession === 'bookkeeper' && 'מנהל חשבונות'}
                            {freelancer.freelancer_data?.profession === 'payroll_specialist' && 'חשב שכר'}
                          </span>
                          <span className="hidden sm:block mx-2">•</span>
                          <span>{freelancer.freelancer_data?.experience_years || 0} שנות ניסיון</span>
                          <span className="hidden sm:block mx-2">•</span>
                          <span>נרשם: {formatDate(freelancer.created_date)}</span>
                        </div>
                      </div>
                      <Button size="sm" asChild>
                        <Link to={createPageUrl(`AdminUserApproval?id=${freelancer.id}`)}>
                          בדוק ואשר
                        </Link>
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
            {pendingFreelancers.length > 0 && (
              <CardFooter>
                <Button variant="outline" className="w-full" asChild>
                  <Link to={createPageUrl('AdminApprovals')}>
                    צפה בכל הבקשות
                  </Link>
                </Button>
              </CardFooter>
            )}
          </Card>
        </TabsContent>

        <TabsContent value="updates">
          <Card>
            <CardHeader>
              <CardTitle>בקשות עדכון פרטים</CardTitle>
              <CardDescription>
                משתמשים שביקשו לעדכן את פרטיהם וממתינים לאישורך
              </CardDescription>
            </CardHeader>
            <CardContent>
              {updateRequests.length === 0 ? (
                <div className="text-center py-8">
                  <div className="bg-green-100 inline-flex rounded-full p-3 mb-4">
                    <CheckCircle className="h-6 w-6 text-green-500" />
                  </div>
                  <p className="text-muted-foreground">אין בקשות עדכון ממתינות כרגע</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {updateRequests.map(request => (
                    <div key={request.id} className="border-b pb-3 flex items-center justify-between">
                      <div>
                        <p className="font-medium">בקשה מאת: {request.user_id}</p>
                        <div className="flex flex-col sm:flex-row sm:items-center mt-1 text-sm text-gray-500">
                          <span>{request.update_type === 'personal_details' ? 'עדכון פרטים אישיים' : 'עדכון פרטי מקצוע'}</span>
                          <span className="hidden sm:block mx-2">•</span>
                          <span>נשלח: {formatDate(request.created_date)}</span>
                        </div>
                      </div>
                      <Button size="sm" asChild>
                        <Link to={createPageUrl(`AdminReviewRequest?id=${request.id}`)}>
                          בדוק בקשה
                        </Link>
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
            {updateRequests.length > 0 && (
              <CardFooter>
                <Button variant="outline" className="w-full" asChild>
                  <Link to={createPageUrl('AdminUserRequests')}>
                    צפה בכל הבקשות
                  </Link>
                </Button>
              </CardFooter>
            )}
          </Card>
        </TabsContent>

        <TabsContent value="projects">
          <Card>
            <CardHeader>
              <CardTitle>פרויקטים אחרונים</CardTitle>
              <CardDescription>
                הפרויקטים האחרונים שנוצרו במערכת
              </CardDescription>
            </CardHeader>
            <CardContent>
              {recentProjects.length === 0 ? (
                <div className="text-center py-8">
                  <div className="bg-gray-100 inline-flex rounded-full p-3 mb-4">
                    <Briefcase className="h-6 w-6 text-gray-500" />
                  </div>
                  <p className="text-muted-foreground">אין פרויקטים במערכת עדיין</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {recentProjects.map(project => (
                    <div key={project.id} className="border-b pb-3">
                      <div className="flex justify-between">
                        <p className="font-medium">{project.title}</p>
                        {getProjectStatusBadge(project.status)}
                      </div>
                      <div className="flex flex-col sm:flex-row sm:items-center mt-1 text-sm text-gray-500">
                        <span>לקוח: {project.client_id}</span>
                        <span className="hidden sm:block mx-2">•</span>
                        <span>נוצר: {formatDate(project.created_date)}</span>
                      </div>
                      <div className="mt-2">
                        <Button size="sm" variant="outline" asChild>
                          <Link to={createPageUrl(`AdminProjectDetails?id=${project.id}`)}>
                            פרטים
                          </Link>
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
            {recentProjects.length > 0 && (
              <CardFooter>
                <Button variant="outline" className="w-full" asChild>
                  <Link to={createPageUrl('AdminProjects')}>
                    צפה בכל הפרויקטים
                  </Link>
                </Button>
              </CardFooter>
            )}
          </Card>
        </TabsContent>
      </Tabs>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="col-span-1 md:col-span-3">
          <CardHeader>
            <CardTitle>פעולות מהירות</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
              <Button variant="outline" className="h-auto flex-col px-4 py-6 space-y-3" asChild>
                <Link to={createPageUrl('AdminApprovals')}>
                  <UserCheck className="h-8 w-8 text-blue-600" />
                  <span>אשר פרילנסרים</span>
                </Link>
              </Button>
              <Button variant="outline" className="h-auto flex-col px-4 py-6 space-y-3" asChild>
                <Link to={createPageUrl('AdminUsers')}>
                  <Users className="h-8 w-8 text-purple-600" />
                  <span>נהל משתמשים</span>
                </Link>
              </Button>
              <Button variant="outline" className="h-auto flex-col px-4 py-6 space-y-3" asChild>
                <Link to={createPageUrl('AdminProjects')}>
                  <Briefcase className="h-8 w-8 text-amber-600" />
                  <span>נהל פרויקטים</span>
                </Link>
              </Button>
              <Button variant="outline" className="h-auto flex-col px-4 py-6 space-y-3" asChild>
                <Link to={createPageUrl('AdminCategories')}>
                  <ListChecks className="h-8 w-8 text-green-600" />
                  <span>נהל קטגוריות</span>
                </Link>
              </Button>
              <Button variant="outline" className="h-auto flex-col px-4 py-6 space-y-3" asChild>
                <Link to={createPageUrl('AdminSettings')}>
                  <Settings className="h-8 w-8 text-gray-600" />
                  <span>הגדרות מערכת</span>
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}