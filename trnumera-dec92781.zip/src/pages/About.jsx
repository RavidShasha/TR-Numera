import React from 'react';

export default function AboutPage() {
  return (
    <div className="max-w-3xl mx-auto py-8 px-4 sm:px-6 lg:px-8 bg-white shadow-xl rounded-lg">
      <h1 className="text-3xl font-bold text-center text-gray-800 mb-8">אודות [שם האתר שלך]</h1>
      
      <div className="space-y-6 text-gray-700 leading-relaxed">
        <p>
          ברוכים הבאים ל-[שם האתר שלך] - הפלטפורמה המובילה בישראל המחברת בין פרילנסרים מקצועיים בתחומי החשבונאות והשכר לבין לקוחות עסקיים ופרטיים הזקוקים לשירותיהם. 
          המשימה שלנו היא ליצור שוק דינמי, יעיל ושקוף, המאפשר לשני הצדדים למצוא את ההתאמה המושלמת בקלות ובמהירות.
        </p>

        <section>
          <h2 className="text-2xl font-semibold text-gray-800 mb-3">החזון שלנו</h2>
          <p>
            אנו שואפים להיות הכתובת הראשונה והמועדפת לכל מי שמחפש או מציע שירותי חשבונאות ושכר בישראל. 
            אנו מאמינים בכוחה של קהילה מקצועית חזקה ובטכנולוגיה ככלי המאפשר צמיחה והצלחה הדדית. 
            מטרתנו היא לפשט את תהליך מציאת אנשי מקצוע מוסמכים ואמינים, ובמקביל לספק לפרילנסרים פלטפורמה להרחבת מעגל הלקוחות שלהם ולהגדלת הכנסותיהם.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-gray-800 mb-3">מה אנחנו מציעים?</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="text-xl font-medium text-blue-600 mb-2">ללקוחות:</h3>
              <ul className="list-disc list-inside space-y-1">
                <li>גישה למאגר רחב של פרילנסרים מאומתים ומוכשרים.</li>
                <li>פרסום פרויקטים בקלות וקבלת הצעות מותאמות.</li>
                <li>כלים לניהול תקשורת, שיתוף קבצים ומעקב אחר התקדמות.</li>
                <li>סביבת תשלום מאובטחת ושקופה.</li>
                <li>חסכון בזמן ובמשאבים הכרוכים באיתור אנשי מקצוע.</li>
              </ul>
            </div>
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="text-xl font-medium text-green-600 mb-2">לפרילנסרים:</h3>
              <ul className="list-disc list-inside space-y-1">
                <li>חשיפה למגוון רחב של פרויקטים מלקוחות ברחבי הארץ.</li>
                <li>הזדמנות להגדיל הכנסות ולבנות מוניטין מקצועי.</li>
                <li>פלטפורמה נוחה לניהול הצעות, פרויקטים ותקשורת עם לקוחות.</li>
                <li>גמישות בעבודה ובחירת הפרויקטים המתאימים.</li>
                <li>קהילה מקצועית תומכת.</li>
              </ul>
            </div>
          </div>
        </section>

        <section>
          <h2 className="text-2xl font-semibold text-gray-800 mb-3">הערכים שלנו</h2>
          <ul className="space-y-2">
            <li className="flex items-start"><strong className="text-indigo-600 min-w-[80px]">מקצועיות:</strong> אנו מחויבים לשמירה על סטנדרטים גבוהים של מקצועיות ואמינות.</li>
            <li className="flex items-start"><strong className="text-indigo-600 min-w-[80px]">שקיפות:</strong> אנו מאמינים בתהליכים פתוחים והוגנים לכל המשתמשים.</li>
            <li className="flex items-start"><strong className="text-indigo-600 min-w-[80px]">חדשנות:</strong> אנו משקיעים בפיתוח טכנולוגי מתמיד לשיפור חווית המשתמש.</li>
            <li className="flex items-start"><strong className="text-indigo-600 min-w-[80px]">קהילה:</strong> אנו מטפחים קהילה של אנשי מקצוע ולקוחות התומכים זה בזה.</li>
            <li className="flex items-start"><strong className="text-indigo-600 min-w-[80px]">אבטחה:</strong> אנו לוקחים ברצינות את פרטיות ואבטחת המידע של משתמשינו.</li>
          </ul>
        </section>
        
        <p className="mt-8 text-center">
          אנו מזמינים אתכם להצטרף אלינו למסע ולהיות חלק מקהילת [שם האתר שלך]!
        </p>
      </div>
    </div>
  );
}