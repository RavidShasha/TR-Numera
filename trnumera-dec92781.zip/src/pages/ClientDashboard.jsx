import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { User } from '@/api/entities';
import { Project } from '@/api/entities';
import { Proposal } from '@/api/entities';
import { MessageSquare, Briefcase, Clock, PlusCircle, TrendingUp, AlertCircle, UserCheck, AlertTriangle, Loader2 } from 'lucide-react';

export default function ClientDashboardPage() {
  const [user, setUser] = useState(null);
  const [projects, setProjects] = useState([]);
  const [proposals, setProposals] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [stats, setStats] = useState({
    activeProjects: 0,
    pendingProposals: 0,
    completedProjects: 0,
    totalSpent: 0
  });

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Get current user
        const currentUser = await User.me();
        setUser(currentUser);

        if (currentUser) {
          // Load projects created by this client
          const userProjects = await Project.filter({ client_id: currentUser.id });
          setProjects(userProjects);

          // Calculate stats
          const active = userProjects.filter(p => p.status === 'in_progress').length;
          const completed = userProjects.filter(p => ['completed', 'paid'].includes(p.status)).length;

          // Gather all project ids
          const projectIds = userProjects.map(p => p.id);
          
          // If we have projects, get proposals for these projects
          let pendingProposalsCount = 0;
          if (projectIds.length > 0) {
            // We'll need to fetch proposals for each project since we can't do advanced filters
            let allProposals = [];
            for (const projectId of projectIds) {
              const projectProposals = await Proposal.filter({ project_id: projectId });
              allProposals = [...allProposals, ...projectProposals];
            }
            
            setProposals(allProposals);
            
            // Count pending proposals (submitted or viewed but not accepted/rejected)
            pendingProposalsCount = allProposals.filter(
              p => ['submitted', 'viewed_by_client'].includes(p.status)
            ).length;
          }

          setStats({
            activeProjects: active,
            pendingProposals: pendingProposalsCount,
            completedProjects: completed,
            totalSpent: 0 // We'll calculate this later when we have payment data
          });
        }
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  const getLatestProjects = () => {
    return [...projects].sort((a, b) => 
      new Date(b.created_date) - new Date(a.created_date)
    ).slice(0, 3);
  };

  const getPendingProposals = () => {
    return proposals.filter(p => 
      ['submitted', 'viewed_by_client'].includes(p.status)
    ).slice(0, 5);
  };

  const getProjectStatusBadge = (status) => {
    switch (status) {
      case 'open':
        return <Badge className="bg-blue-100 text-blue-800">פתוח להצעות</Badge>;
      case 'in_progress':
        return <Badge className="bg-green-100 text-green-800">בתהליך</Badge>;
      case 'pending_payment':
        return <Badge className="bg-amber-100 text-amber-800">ממתין לתשלום</Badge>;
      case 'completed':
        return <Badge className="bg-purple-100 text-purple-800">הושלם</Badge>;
      case 'paid':
        return <Badge className="bg-emerald-100 text-emerald-800">שולם</Badge>;
      case 'cancelled_by_client':
      case 'cancelled_by_freelancer':
      case 'cancelled_by_admin':
        return <Badge variant="destructive">בוטל</Badge>;
      default:
        return null;
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-80">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto text-blue-600" />
          <p className="mt-2">טוען נתונים...</p>
        </div>
      </div>
    );
  }

  // Show message if user profile is not complete
  const isProfileComplete = user && user.phone_number && user.id_card_number;

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">שלום, {user?.full_name || 'אורח'}</h1>
        <Button asChild>
          <Link to={createPageUrl('CreateProject')}>
            <PlusCircle className="ml-2 rtl:mr-2 rtl:ml-0 h-5 w-5" />
            פרסם פרויקט חדש
          </Link>
        </Button>
      </div>
      
      {!isProfileComplete && (
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 flex items-start">
          <AlertCircle className="h-5 w-5 text-amber-500 mr-2 rtl:ml-2 rtl:mr-0 mt-0.5" />
          <div>
            <p className="font-medium text-amber-800">פרופיל חלקי</p>
            <p className="text-amber-700 text-sm">
              השלם את פרטי הפרופיל שלך כדי להשתמש בכל תכונות המערכת.
            </p>
            <Button variant="outline" size="sm" className="mt-2" asChild>
              <Link to={createPageUrl('CompleteProfileClient')}>
                השלם פרופיל
              </Link>
            </Button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground mb-1">פרויקטים פעילים</p>
                <h3 className="text-2xl font-bold">{stats.activeProjects}</h3>
              </div>
              <div className="p-2 bg-blue-100 text-blue-700 rounded-lg">
                <Briefcase className="h-5 w-5" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground mb-1">הצעות ממתינות</p>
                <h3 className="text-2xl font-bold">{stats.pendingProposals}</h3>
              </div>
              <div className="p-2 bg-amber-100 text-amber-700 rounded-lg">
                <Clock className="h-5 w-5" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground mb-1">פרויקטים שהושלמו</p>
                <h3 className="text-2xl font-bold">{stats.completedProjects}</h3>
              </div>
              <div className="p-2 bg-green-100 text-green-700 rounded-lg">
                <UserCheck className="h-5 w-5" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground mb-1">סה"כ הוצאות</p>
                <h3 className="text-2xl font-bold">₪{stats.totalSpent.toLocaleString()}</h3>
              </div>
              <div className="p-2 bg-purple-100 text-purple-700 rounded-lg">
                <TrendingUp className="h-5 w-5" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>הפרויקטים האחרונים שלך</CardTitle>
            <CardDescription>
              סקירה מהירה של הפרויקטים האחרונים שפרסמת
            </CardDescription>
          </CardHeader>
          <CardContent>
            {getLatestProjects().length > 0 ? (
              <div className="space-y-4">
                {getLatestProjects().map(project => (
                  <div key={project.id} className="flex justify-between items-center border-b pb-3">
                    <div>
                      <Link 
                        to={createPageUrl(`Project?id=${project.id}`)} 
                        className="font-medium hover:text-blue-600 transition-colors"
                      >
                        {project.title}
                      </Link>
                      <div className="flex items-center mt-1">
                        {getProjectStatusBadge(project.status)}
                        <span className="text-xs text-gray-500 mr-2 rtl:ml-2 rtl:mr-0">
                          {new Date(project.created_date).toLocaleDateString('he-IL')}
                        </span>
                      </div>
                    </div>
                    <Button variant="outline" size="sm" asChild>
                      <Link to={createPageUrl(`Project?id=${project.id}`)}>
                        פרטים
                      </Link>
                    </Button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <div className="bg-gray-100 inline-flex rounded-full p-3 mb-4">
                  <Briefcase className="h-6 w-6 text-gray-500" />
                </div>
                <p className="text-muted-foreground">לא פרסמת פרויקטים עדיין</p>
                <Button className="mt-3" size="sm" asChild>
                  <Link to={createPageUrl('CreateProject')}>
                    <PlusCircle className="ml-2 rtl:mr-2 rtl:ml-0 h-4 w-4" />
                    פרסם פרויקט חדש
                  </Link>
                </Button>
              </div>
            )}
          </CardContent>
          {getLatestProjects().length > 0 && (
            <CardFooter>
              <Button variant="outline" className="w-full" asChild>
                <Link to={createPageUrl('MyProjectsClient')}>
                  צפה בכל הפרויקטים
                </Link>
              </Button>
            </CardFooter>
          )}
        </Card>
        
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>הצעות ממתינות</CardTitle>
            <CardDescription>
              הצעות חדשות שקיבלת עבור הפרויקטים שלך
            </CardDescription>
          </CardHeader>
          <CardContent>
            {getPendingProposals().length > 0 ? (
              <div className="space-y-4">
                {getPendingProposals().map(proposal => {
                  const project = projects.find(p => p.id === proposal.project_id);
                  return (
                    <div key={proposal.id} className="border-b pb-3">
                      <div className="flex justify-between items-center">
                        <p className="font-medium">
                          הצעה עבור: {project?.title || "פרויקט"}
                        </p>
                        <Badge className="bg-amber-100 text-amber-800">
                          {proposal.status === 'submitted' ? 'חדש' : 'נצפה'}
                        </Badge>
                      </div>
                      <p className="text-sm mt-1">
                        סכום מוצע: ₪{proposal.proposed_amount.toLocaleString()}
                      </p>
                      <div className="mt-2">
                        <Button size="sm" className="mr-2 rtl:ml-2 rtl:mr-0" asChild>
                          <Link to={createPageUrl(`Proposal?id=${proposal.id}`)}>
                            צפה בהצעה
                          </Link>
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-8">
                <div className="bg-gray-100 inline-flex rounded-full p-3 mb-4">
                  <MessageSquare className="h-6 w-6 text-gray-500" />
                </div>
                <p className="text-muted-foreground">אין הצעות חדשות</p>
              </div>
            )}
          </CardContent>
          {getPendingProposals().length > 0 && (
            <CardFooter>
              <Button variant="outline" className="w-full" asChild>
                <Link to={createPageUrl('MyProjectsClient')}>
                  צפה בכל ההצעות
                </Link>
              </Button>
            </CardFooter>
          )}
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>פעולות מהירות</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <Button variant="outline" className="h-auto flex-col px-4 py-8 space-y-3" asChild>
              <Link to={createPageUrl('CreateProject')}>
                <PlusCircle className="h-8 w-8 text-blue-600" />
                <span className="text-base">פרסם פרויקט חדש</span>
              </Link>
            </Button>
            <Button variant="outline" className="h-auto flex-col px-4 py-8 space-y-3" asChild>
              <Link to={createPageUrl('SearchFreelancers')}>
                <UserCheck className="h-8 w-8 text-green-600" />
                <span className="text-base">חפש פרילנסרים</span>
              </Link>
            </Button>
            <Button variant="outline" className="h-auto flex-col px-4 py-8 space-y-3" asChild>
              <Link to={createPageUrl('MyProjectsClient')}>
                <Briefcase className="h-8 w-8 text-purple-600" />
                <span className="text-base">נהל הפרויקטים שלך</span>
              </Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}