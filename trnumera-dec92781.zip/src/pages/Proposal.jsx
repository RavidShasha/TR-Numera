
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Link, useSearchParams, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { User } from '@/api/entities';
import { Project } from '@/api/entities';
import { Proposal as ProposalEntity } from '@/api/entities'; // Renamed to avoid conflict
import { Review } from '@/api/entities';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertCircle, Loader2, Star, MessageSquare, CheckCircle, XCircle, Edit, Trash2, Briefcase } from 'lucide-react';
import { useTitle } from '@/hooks/useTitle';

export default function ProposalPage() {
  useTitle("פיתוח דפי חיפוש ומערכת הצעות");
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const proposalId = searchParams.get('id');

  const [currentUser, setCurrentUser] = useState(null);
  const [proposal, setProposal] = useState(null);
  const [project, setProject] = useState(null);
  const [freelancer, setFreelancer] = useState(null);
  const [client, setClient] = useState(null); // For freelancer to see client details
  const [reviews, setReviews] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [actionLoading, setActionLoading] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      if (!proposalId) {
        setError('מזהה הצעה חסר.');
        setIsLoading(false);
        return;
      }
      try {
        const user = await User.me();
        setCurrentUser(user);

        const fetchedProposal = await ProposalEntity.get(proposalId);
        setProposal(fetchedProposal);

        const [fetchedProject, fetchedFreelancer] = await Promise.all([
          Project.get(fetchedProposal.project_id),
          User.get(fetchedProposal.freelancer_id)
        ]);
        setProject(fetchedProject);
        setFreelancer(fetchedFreelancer);
        
        // If current user is freelancer, fetch client details
        if (user.id === fetchedFreelancer.id) {
            const fetchedClient = await User.get(fetchedProject.client_id);
            setClient(fetchedClient);
        }

        // Fetch reviews for this freelancer
        const freelancerReviews = await Review.filter({ freelancer_id: fetchedFreelancer.id });
        setReviews(freelancerReviews);
        
        // Security Check: Ensure current user is either the client who owns the project or the freelancer who made the proposal
        if (user.id !== fetchedProject.client_id && user.id !== fetchedFreelancer.id) {
            setError('אין לך הרשאה לצפות בהצעה זו.');
            setIsLoading(false);
            return;
        }

        // If client views the proposal, mark it as viewed
        if (user.id === fetchedProject.client_id && fetchedProposal.status === 'submitted') {
            await ProposalEntity.update(proposalId, { status: 'viewed_by_client' });
            setProposal(prev => ({...prev, status: 'viewed_by_client' }));
        }


      } catch (err) {
        console.error('Error fetching data:', err);
        setError('אירעה שגיאה בטעינת פרטי ההצעה.');
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [proposalId]);

  const getFreelancerAverageRating = () => {
    if (reviews.length === 0) return 0;
    const sum = reviews.reduce((acc, review) => acc + review.rating, 0);
    return (sum / reviews.length).toFixed(1);
  };
  
  const handleClientAction = async (action) => {
    setActionLoading(true);
    try {
      if (!proposal || !project) throw new Error("נתונים חסרים");

      if (action === 'accept') {
        await ProposalEntity.update(proposal.id, { status: 'accepted' });
        await Project.update(project.id, { 
          selected_freelancer_id: proposal.freelancer_id, 
          status: 'in_progress',
          freelancer_hired_date: new Date().toISOString()
        });
        // Optionally reject other proposals
        navigate(createPageUrl(`Project?id=${project.id}&proposalAccepted=true`));
      } else if (action === 'reject') {
        await ProposalEntity.update(proposal.id, { status: 'rejected' });
        setProposal(prev => ({ ...prev, status: 'rejected' }));
      }
    } catch (err) {
      console.error(`Error ${action}ing proposal:`, err);
      setError(`שגיאה ב${action === 'accept' ? 'אישור' : 'דחיית'} ההצעה.`);
    } finally {
      setActionLoading(false);
    }
  };

  const handleFreelancerAction = async (action) => {
    setActionLoading(true);
    try {
        if (!proposal) throw new Error("הצעה לא נמצאה");
        if (action === 'withdraw') {
            await ProposalEntity.update(proposal.id, { status: 'withdrawn_by_freelancer' });
            setProposal(prev => ({ ...prev, status: 'withdrawn_by_freelancer' }));
        }
        // Add edit logic later if needed by navigating to SubmitProposal with proposalId
    } catch (err) {
        console.error(`Error ${action}ing proposal:`, err);
        setError('שגיאה בפעולה על ההצעה.');
    } finally {
        setActionLoading(false);
    }
  };


  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-80">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto py-8 px-4 text-center">
        <Alert variant="destructive" className="max-w-md mx-auto">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
        <Button onClick={() => navigate(-1)} variant="outline" className="mt-4">חזור</Button>
      </div>
    );
  }
  
  if (!proposal || !project || !freelancer) {
    return (
         <div className="container mx-auto py-8 px-4 text-center">
            <Alert variant="warning" className="max-w-md mx-auto">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>לא ניתן היה לטעון את כל פרטי ההצעה.</AlertDescription>
            </Alert>
             <Button onClick={() => navigate(-1)} variant="outline" className="mt-4">חזור</Button>
         </div>
    );
  }
  
  const isClientView = currentUser.id === project.client_id;
  const isFreelancerView = currentUser.id === freelancer.id;
  const avgRating = getFreelancerAverageRating();

  const getStatusBadge = (status) => {
    switch(status) {
        case 'submitted': return <Badge variant="warning">הוגשה (ממתינה לצפיית הלקוח)</Badge>;
        case 'viewed_by_client': return <Badge variant="info">נצפתה ע"י הלקוח</Badge>;
        case 'accepted': return <Badge variant="success">התקבלה</Badge>;
        case 'rejected': return <Badge variant="destructive">נדחתה</Badge>;
        case 'withdrawn_by_freelancer': return <Badge variant="secondary">בוטלה ע"י הפרילנסר</Badge>;
        default: return <Badge variant="outline">{status}</Badge>;
    }
  };


  return (
    <div className="container mx-auto py-8 px-4">
      <div className="mb-6">
        <Button variant="outline" onClick={() => navigate( isClientView ? createPageUrl(`ProjectProposals?id=${project.id}`) : createPageUrl(`Project?id=${project.id}`))}>
          &rarr; {isClientView ? 'חזור לרשימת ההצעות' : 'חזור לפרויקט'}
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Freelancer/Client Info Column */}
        <div className="md:col-span-1 space-y-6">
          {isClientView && freelancer && (
            <Card>
              <CardHeader>
                <CardTitle>פרטי הפרילנסר</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <Avatar className="w-24 h-24 mx-auto mb-3 border-2 border-blue-200">
                  <AvatarImage src={freelancer.photo_url || `https://avatar.vercel.sh/${freelancer.email}.png`} alt={freelancer.full_name} />
                  <AvatarFallback>{freelancer.full_name.substring(0, 2).toUpperCase()}</AvatarFallback>
                </Avatar>
                <h3 className="text-xl font-semibold text-blue-700">{freelancer.full_name}</h3>
                <p className="text-sm text-gray-500">
                    {freelancer.freelancer_data?.profession === 'accountant' && 'מנהל/ת חשבונות'}
                    {freelancer.freelancer_data?.profession === 'payroll_specialist' && 'חשב/ת שכר'}
                    {freelancer.freelancer_data?.profession === 'bookkeeper' && 'הנהלת חשבונות'}
                </p>
                {reviews.length > 0 && (
                  <div className="flex items-center justify-center text-sm mt-1">
                    <Star className="h-4 w-4 text-yellow-400 fill-yellow-400 mr-1 rtl:ml-1 rtl:mr-0" />
                    {avgRating} ({reviews.length} ביקורות)
                  </div>
                )}
                <p className="text-xs text-gray-500 mt-1">
                  ניסיון: {freelancer.freelancer_data?.experience_years || 'לא צוין'} שנים
                </p>
                <Button size="sm" variant="outline" className="mt-4 w-full" asChild>
                    <Link to={createPageUrl(`FreelancerProfile?id=${freelancer.id}`)}>צפה בפרופיל מלא</Link>
                </Button>
              </CardContent>
            </Card>
          )}
          {isFreelancerView && client && (
             <Card>
              <CardHeader>
                <CardTitle>פרטי הלקוח</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                 <Avatar className="w-20 h-20 mx-auto mb-3">
                  <AvatarImage src={client.photo_url || `https://avatar.vercel.sh/${client.email}.png`} alt={client.full_name} />
                  <AvatarFallback>{client.full_name.substring(0, 2).toUpperCase()}</AvatarFallback>
                </Avatar>
                <h3 className="text-lg font-semibold">{client.full_name}</h3>
                {client.client_data?.company_name && <p className="text-sm text-gray-500">{client.client_data.company_name}</p>}
                {/* Add more client details if needed, e.g., link to client profile */}
              </CardContent>
            </Card>
          )}
          <Card>
            <CardHeader>
                <CardTitle>סיכום הפרויקט</CardTitle>
            </CardHeader>
            <CardContent className="text-sm space-y-1">
                <p><strong>כותרת:</strong> {project.title}</p>
                <p><strong>תקציב לקוח:</strong> 
                {project.budget_min && project.budget_max ? ` ₪${project.budget_min} - ₪${project.budget_max}` 
                  : project.budget_min ? ` החל מ-₪${project.budget_min}` 
                  : project.budget_max ? ` עד ₪${project.budget_max}` 
                  : ' לא צוין'}
                </p>
                <p><strong>סוג:</strong> {project.project_type === 'one_time' ? 'חד פעמי' : 'מתמשך'}</p>
                {project.is_urgent && <Badge className="bg-red-100 text-red-700">דחוף</Badge>}
                <Button size="sm" variant="link" className="p-0 h-auto mt-2" asChild>
                    <Link to={createPageUrl(`Project?id=${project.id}`)}>צפה בפרטי הפרויקט המלאים</Link>
                </Button>
            </CardContent>
          </Card>
        </div>

        {/* Proposal Details Column */}
        <div className="md:col-span-2">
          <Card className="shadow-lg">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="text-2xl font-bold">פרטי ההצעה</CardTitle>
                {getStatusBadge(proposal.status)}
              </div>
              <CardDescription>
                הוגשה בתאריך: {new Date(proposal.created_date).toLocaleDateString('he-IL')}
                {isFreelancerView && ` | על ידי: אתה`}
                {isClientView && ` | על ידי: ${freelancer.full_name}`}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h4 className="text-lg font-semibold mb-1">סכום מוצע:</h4>
                <p className="text-2xl font-bold text-blue-600">₪{proposal.proposed_amount.toLocaleString()}</p>
              </div>
              {proposal.estimated_days_to_complete && (
                <div>
                  <h4 className="text-lg font-semibold mb-1">זמן מוערך לסיום:</h4>
                  <p>{proposal.estimated_days_to_complete} ימים</p>
                </div>
              )}
              <div>
                <h4 className="text-lg font-semibold mb-1">מכתב מקדים:</h4>
                <div className="bg-gray-50 p-4 rounded-md border whitespace-pre-wrap">
                  {proposal.cover_letter}
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex flex-col sm:flex-row justify-end gap-3 border-t pt-6">
              {isClientView && project.status === 'open' && ['submitted', 'viewed_by_client'].includes(proposal.status) && (
                <>
                  <Button 
                    variant="destructiveOutline"
                    onClick={() => handleClientAction('reject')}
                    disabled={actionLoading}
                  >
                    <XCircle className="h-4 w-4 mr-1 rtl:ml-1 rtl:mr-0" /> דחה הצעה
                    {actionLoading && <Loader2 className="ml-2 rtl:mr-2 rtl:ml-0 h-4 w-4 animate-spin" />}
                  </Button>
                  <Button 
                    variant="success"
                    onClick={() => handleClientAction('accept')}
                    disabled={actionLoading}
                  >
                    <CheckCircle className="h-4 w-4 mr-1 rtl:ml-1 rtl:mr-0" /> קבל הצעה והתחל פרויקט
                    {actionLoading && <Loader2 className="ml-2 rtl:mr-2 rtl:ml-0 h-4 w-4 animate-spin" />}
                  </Button>
                </>
              )}
              {isFreelancerView && ['submitted', 'viewed_by_client'].includes(proposal.status) && (
                <>
                    {/* <Button variant="outline" disabled={actionLoading} onClick={() => alert("Edit functionality to be implemented")}>
                        <Edit className="h-4 w-4 mr-1 rtl:ml-1 rtl:mr-0" /> ערוך הצעה
                    </Button> */}
                    <Button 
                        variant="destructiveOutline" 
                        onClick={() => handleFreelancerAction('withdraw')}
                        disabled={actionLoading}
                    >
                        <Trash2 className="h-4 w-4 mr-1 rtl:ml-1 rtl:mr-0" /> משוך הצעה
                        {actionLoading && <Loader2 className="ml-2 rtl:mr-2 rtl:ml-0 h-4 w-4 animate-spin" />}
                    </Button>
                </>
              )}
              {project.status !== 'open' && isClientView && (
                <p className="text-sm text-gray-500">
                    {project.selected_freelancer_id === proposal.freelancer_id && proposal.status === 'accepted' 
                        ? 'הצעה זו התקבלה והפרויקט בתהליך.' 
                        : project.selected_freelancer_id 
                        ? 'פרילנסר אחר נבחר לפרויקט זה.'
                        : 'לא ניתן לבצע פעולות נוספות על הצעה זו כרגע.'}
                </p>
              )}
               {proposal.status === 'withdrawn_by_freelancer' && isFreelancerView && (
                  <p className="text-sm text-orange-600">משכת הצעה זו.</p>
               )}
               {proposal.status === 'rejected' && isFreelancerView && (
                  <p className="text-sm text-red-600">הצעה זו נדחתה על ידי הלקוח.</p>
               )}
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
}
