
import React, { useState, useEffect } from 'react';
import { ServiceCategory } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger } from '@/components/ui/dialog';
import { Loader2, ListChecks, PlusCircle, Edit3, Trash2, Search } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Textarea } from '@/components/ui/textarea';


export default function AdminCategoriesPage() {
  const [categories, setCategories] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [currentCategory, setCurrentCategory] = useState(null); // For editing
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    is_active: true,
    recommended_price_min: '',
    recommended_price_max: '',
    required_documents_description: ''
  });

  const [categoryToDelete, setCategoryToDelete] = useState(null);
  const [isDeleteAlertOpen, setIsDeleteAlertOpen] = useState(false);

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    setIsLoading(true);
    try {
      const allCategories = await ServiceCategory.list('-created_date');
      setCategories(allCategories);
    } catch (error) {
      console.error("Error fetching categories:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };
  
  const handleNumberInputChange = (e) => {
    const { name, value } = e.target;
    if (value === '' || /^\d*\.?\d*$/.test(value)) {
        setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const openFormModal = (category = null) => {
    setCurrentCategory(category);
    if (category) {
      setFormData({
        name: category.name || '',
        description: category.description || '',
        is_active: category.is_active !== undefined ? category.is_active : true,
        recommended_price_min: category.recommended_price_min?.toString() || '',
        recommended_price_max: category.recommended_price_max?.toString() || '',
        required_documents_description: category.required_documents_description || ''
      });
    } else {
      setFormData({
        name: '',
        description: '',
        is_active: true,
        recommended_price_min: '',
        recommended_price_max: '',
        required_documents_description: ''
      });
    }
    setIsFormModalOpen(true);
  };

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      alert("שם קטגוריה הוא שדה חובה.");
      return;
    }

    const dataToSave = {
      ...formData,
      recommended_price_min: formData.recommended_price_min ? parseFloat(formData.recommended_price_min) : null,
      recommended_price_max: formData.recommended_price_max ? parseFloat(formData.recommended_price_max) : null,
    };
    
    // Remove empty strings so they become null in DB if not provided (for optional fields)
    Object.keys(dataToSave).forEach(key => {
        if (dataToSave[key] === '') {
            dataToSave[key] = null;
        }
    });


    try {
      if (currentCategory) {
        await ServiceCategory.update(currentCategory.id, dataToSave);
      } else {
        await ServiceCategory.create(dataToSave);
      }
      setIsFormModalOpen(false);
      fetchCategories();
    } catch (error) {
      console.error("Error saving category:", error);
      alert("שגיאה בשמירת הקטגוריה: " + error.message);
    }
  };

  const openDeleteAlert = (category) => {
    setCategoryToDelete(category);
    setIsDeleteAlertOpen(true);
  };

  const handleDeleteCategory = async () => {
    if (!categoryToDelete) return;
    try {
      await ServiceCategory.delete(categoryToDelete.id);
      setIsDeleteAlertOpen(false);
      setCategoryToDelete(null);
      fetchCategories();
    } catch (error)
    {
      console.error("Error deleting category:", error);
      alert("שגיאה במחיקת הקטגוריה. ודא שאין פרויקטים או פרילנסרים המקושרים לקטגוריה זו.");
      setIsDeleteAlertOpen(false); // Still close the dialog on error
    }
  };

  const filteredCategories = categories.filter(category => 
    category.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    category.description?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-80">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <CardTitle className="text-2xl flex items-center">
              <ListChecks className="h-6 w-6 mr-2 rtl:ml-2 rtl:mr-0 text-blue-600" />
              ניהול תחומי שירות
            </CardTitle>
            <CardDescription>הוספה, עריכה ומחיקה של תחומי שירות (קטגוריות) במערכת.</CardDescription>
          </div>
          <Button onClick={() => openFormModal()}>
            <PlusCircle className="h-4 w-4 mr-2 rtl:ml-2 rtl:mr-0" />
            הוסף תחום שירות חדש
          </Button>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 rtl:right-2.5 rtl:left-auto top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="חפש לפי שם או תיאור"
                className="pl-8 rtl:pr-8 rtl:pl-4"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>שם תחום השירות</TableHead>
                <TableHead>תיאור</TableHead>
                <TableHead>פעיל?</TableHead>
                <TableHead>מחיר מומלץ (מינימום)</TableHead>
                <TableHead>מחיר מומלץ (מקסימום)</TableHead>
                <TableHead className="text-right">פעולות</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredCategories.map(category => (
                <TableRow key={category.id}>
                  <TableCell className="font-medium">{category.name}</TableCell>
                  <TableCell className="max-w-sm truncate" title={category.description}>{category.description || '-'}</TableCell>
                  <TableCell>
                    <Checkbox checked={category.is_active} disabled className="opacity-100" />
                  </TableCell>
                  <TableCell>{category.recommended_price_min !== null ? `₪${category.recommended_price_min}` : '-'}</TableCell>
                  <TableCell>{category.recommended_price_max !== null ? `₪${category.recommended_price_max}` : '-'}</TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon" onClick={() => openFormModal(category)} className="mr-2 rtl:ml-2 rtl:mr-0">
                      <Edit3 className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="text-red-600 hover:text-red-700" onClick={() => openDeleteAlert(category)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          {filteredCategories.length === 0 && (
            <div className="text-center py-10 text-gray-500">
              לא נמצאו תחומי שירות התואמים את החיפוש.
            </div>
          )}
        </CardContent>
      </Card>

      {/* Add/Edit Category Modal */}
      <Dialog open={isFormModalOpen} onOpenChange={setIsFormModalOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{currentCategory ? 'עריכת תחום שירות' : 'הוספת תחום שירות חדש'}</DialogTitle>
            <DialogDescription>
              {currentCategory ? 'עדכן את פרטי תחום השירות.' : 'מלא את הפרטים ליצירת תחום שירות חדש.'}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleFormSubmit} className="py-4 space-y-4">
            <div>
              <Label htmlFor="name">שם תחום השירות <span className="text-red-500">*</span></Label>
              <Input id="name" name="name" value={formData.name} onChange={handleInputChange} required />
            </div>
            <div>
              <Label htmlFor="description">תיאור</Label>
              <Textarea id="description" name="description" value={formData.description} onChange={handleInputChange} />
            </div>
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <Label htmlFor="recommended_price_min">מחיר מומלץ (מינימום)</Label>
                    <Input id="recommended_price_min" name="recommended_price_min" type="text" inputMode="decimal" value={formData.recommended_price_min} onChange={handleNumberInputChange} placeholder="לדוגמה: 100" />
                </div>
                <div>
                    <Label htmlFor="recommended_price_max">מחיר מומלץ (מקסימום)</Label>
                    <Input id="recommended_price_max" name="recommended_price_max" type="text" inputMode="decimal" value={formData.recommended_price_max} onChange={handleNumberInputChange} placeholder="לדוגמה: 500" />
                </div>
            </div>
            <div>
              <Label htmlFor="required_documents_description">תיאור מסמכים נדרשים מפרילנסר</Label>
              <Textarea id="required_documents_description" name="required_documents_description" value={formData.required_documents_description} onChange={handleInputChange} placeholder="למשל: תעודת מנהל חשבונות סוג 3, תעודת חשב שכר" />
            </div>
            <div className="flex items-center space-x-2 rtl:space-x-reverse">
              <Checkbox id="is_active" name="is_active" checked={formData.is_active} onCheckedChange={(checked) => setFormData(prev => ({...prev, is_active: checked}))} />
              <Label htmlFor="is_active">תחום שירות פעיל</Label>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsFormModalOpen(false)}>ביטול</Button>
              <Button type="submit">{currentCategory ? 'שמור שינויים' : 'הוסף תחום שירות'}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Category Confirmation */}
      <AlertDialog open={isDeleteAlertOpen} onOpenChange={setIsDeleteAlertOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>אישור מחיקת תחום שירות</AlertDialogTitle>
            <AlertDialogDescription>
              האם אתה בטוח שברצונך למחוק את תחום השירות "{categoryToDelete?.name}"? 
              פעולה זו אינה ניתנת לשחזור. 
              שים לב: לא ניתן למחוק תחום שירות אם יש פרויקטים או פרילנסרים המקושרים אליו.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setCategoryToDelete(null)}>ביטול</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteCategory} className="bg-red-600 hover:bg-red-700">
              מחק
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
