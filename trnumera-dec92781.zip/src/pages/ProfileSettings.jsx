import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { User } from '@/api/entities';
import { ProfileUpdateRequest } from '@/api/entities';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Loader2, User as UserIcon, Lock, FileText, Bell, Eye } from 'lucide-react';

import UpdateProfileRequest from '../components/profile/UpdateProfileRequest';

export default function ProfileSettingsPage() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [requests, setRequests] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('profile');

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Get current user
        const currentUser = await User.me();
        setUser(currentUser);

        // Get user's update requests
        if (currentUser) {
          const userRequests = await ProfileUpdateRequest.filter({ user_id: currentUser.id });
          setRequests(userRequests);
        }
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleUpdateUser = () => {
    // Redirect to the appropriate complete profile page based on user role
    if (user.role === 'freelancer') {
      navigate(createPageUrl('CompleteProfileFreelancer'));
    } else if (user.role === 'client') {
      navigate(createPageUrl('CompleteProfileClient'));
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto text-blue-600" />
          <p className="mt-2">טוען נתונים...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center py-10 px-4">
      <Card className="w-full max-w-4xl shadow-lg">
        <CardHeader className="pb-2">
          <CardTitle className="text-2xl font-bold">הגדרות פרופיל</CardTitle>
          <CardDescription>
            צפה ונהל את פרטי החשבון שלך
          </CardDescription>
        </CardHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-3 mx-6 my-4">
            <TabsTrigger value="profile">פרופיל</TabsTrigger>
            <TabsTrigger value="requests">בקשות עדכון</TabsTrigger>
            <TabsTrigger value="notifications">העדפות התראות</TabsTrigger>
          </TabsList>

          <TabsContent value="profile" className="mt-0">
            <CardContent className="space-y-6 pt-4">
              <div className="flex items-center">
                <div className="h-20 w-20 rounded-full bg-blue-100 flex items-center justify-center">
                  {user?.photo_url ? (
                    <img 
                      src={user.photo_url} 
                      alt={`תמונת פרופיל של ${user.full_name}`} 
                      className="h-full w-full rounded-full object-cover" 
                    />
                  ) : (
                    <UserIcon className="h-10 w-10 text-blue-500" />
                  )}
                </div>
                <div className="mr-4 rtl:ml-4 rtl:mr-0">
                  <h2 className="text-xl font-semibold">{user?.full_name || 'משתמש'}</h2>
                  <p className="text-gray-500">{user?.email}</p>
                  <p className="text-sm text-gray-600">
                    {user?.role === 'freelancer' && 'פרילנסר'}
                    {user?.role === 'client' && 'לקוח'}
                    {user?.role === 'admin' && 'מנהל'}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">פרטים אישיים</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-500">שם מלא</span>
                      <span className="font-medium">{user?.full_name || 'לא הוגדר'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-500">דואר אלקטרוני</span>
                      <span className="font-medium">{user?.email}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-500">טלפון</span>
                      <span className="font-medium">{user?.phone_number || 'לא הוגדר'}</span>
                    </div>
                    {user?.role === 'freelancer' && (
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-500">סטטוס אישור</span>
                        <span className={`font-medium ${user?.freelancer_data?.is_approved ? 'text-green-600' : 'text-orange-600'}`}>
                          {user?.freelancer_data?.is_approved ? 'מאושר' : 'ממתין לאישור'}
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                {user?.role === 'client' && user?.client_data && (
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">פרטי עסק</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-500">שם העסק</span>
                        <span className="font-medium">{user.client_data.company_name || 'לא הוגדר'}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-500">מספר עוסק/ח.פ.</span>
                        <span className="font-medium">{user.client_data.business_id_number || 'לא הוגדר'}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-500">ענף</span>
                        <span className="font-medium">{user.client_data.industry_type || 'לא הוגדר'}</span>
                      </div>
                    </div>
                  </div>
                )}

                {user?.role === 'freelancer' && user?.freelancer_data && (
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">פרטים מקצועיים</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-500">תחום</span>
                        <span className="font-medium">
                          {user.freelancer_data.profession === 'accountant' && 'מנהל חשבונות'}
                          {user.freelancer_data.profession === 'payroll_specialist' && 'חשב שכר'}
                          {user.freelancer_data.profession === 'bookkeeper' && 'הנהלת חשבונות'}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-500">שנות ניסיון</span>
                        <span className="font-medium">{user.freelancer_data.experience_years || 'לא הוגדר'}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-500">דרגה</span>
                        <span className="font-medium">{user.freelancer_data.profession_level || 'לא הוגדר'}</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div className="mt-6">
                <Button onClick={handleUpdateUser} className="bg-blue-600 hover:bg-blue-700">
                  עדכן פרטים
                </Button>
              </div>
            </CardContent>
          </TabsContent>

          <TabsContent value="requests" className="mt-0">
            <CardContent className="space-y-6 pt-4">
              <h3 className="text-lg font-medium flex items-center">
                <FileText className="h-5 w-5 mr-2 rtl:ml-2 rtl:mr-0 text-blue-600" />
                בקשות עדכון פרטים
              </h3>

              {requests.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-gray-500">אין לך בקשות עדכון בהמתנה</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {requests.map(request => (
                    <div 
                      key={request.id} 
                      className="border rounded-lg p-4 bg-white hover:bg-gray-50 transition-colors"
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <h4 className="font-medium">בקשת עדכון פרטים</h4>
                          <p className="text-sm text-gray-500">
                            נשלח בתאריך: {new Date(request.created_date).toLocaleDateString('he-IL')}
                          </p>
                        </div>
                        <span className={`px-2 py-1 text-xs rounded-full ${
                          request.status === 'pending_approval' ? 'bg-yellow-100 text-yellow-800' :
                          request.status === 'approved' ? 'bg-green-100 text-green-800' :
                          request.status === 'rejected' ? 'bg-red-100 text-red-800' :
                          'bg-blue-100 text-blue-800'
                        }`}>
                          {request.status === 'pending_approval' && 'ממתין לאישור'}
                          {request.status === 'approved' && 'אושר'}
                          {request.status === 'rejected' && 'נדחה'}
                          {request.status === 'more_info_required' && 'נדרש מידע נוסף'}
                        </span>
                      </div>
                      <p className="mt-2 text-sm">
                        {request.reason}
                      </p>
                      {request.status === 'rejected' && request.admin_notes && (
                        <p className="mt-2 text-sm text-red-600">
                          הערת מנהל: {request.admin_notes}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              )}

              <div className="mt-6">
                <UpdateProfileRequest />
              </div>
            </CardContent>
          </TabsContent>

          <TabsContent value="notifications" className="mt-0">
            <CardContent className="space-y-6 pt-4">
              <h3 className="text-lg font-medium flex items-center">
                <Bell className="h-5 w-5 mr-2 rtl:ml-2 rtl:mr-0 text-blue-600" />
                העדפות התראות
              </h3>

              <p className="text-gray-500">
                הגדר אילו התראות תרצה לקבל במייל ובתוך המערכת
              </p>

              <div className="mt-6 text-center">
                <p className="text-gray-500">תכונה זו תהיה זמינה בקרוב</p>
              </div>
            </CardContent>
          </TabsContent>
        </Tabs>
      </Card>
    </div>
  );
}