import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { User } from '@/api/entities';
import { Project } from '@/api/entities';
import { Proposal } from '@/api/entities';
import { Message } from '@/api/entities';
import { ProjectFile } from '@/api/entities';
import { ServiceCategory } from '@/api/entities';
import { useSearchParams } from 'react-router-dom';
import { Separator } from '@/components/ui/separator';
import FileUploader from '@/components/projects/FileUploader';

import { 
  ClipboardList, Clock, FileText, MessageSquare, Loader2, PlusCircle, 
  Calendar, Check, X, AlertCircle, Upload, Download, Info, CheckCircle
} from 'lucide-react';

export default function ProjectPage() {
  const [searchParams] = useSearchParams();
  const projectId = searchParams.get('id');
  const navigate = useNavigate();
  
  const [user, setUser] = useState(null);
  const [project, setProject] = useState(null);
  const [selectedFreelancer, setSelectedFreelancer] = useState(null);
  const [proposals, setProposals] = useState([]);
  const [messages, setMessages] = useState([]);
  const [files, setFiles] = useState([]);
  const [categories, setCategories] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  
  // For clients to update status
  const [isUpdatingStatus, setIsUpdatingStatus] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      if (!projectId) {
        setError('מזהה פרויקט חסר');
        setIsLoading(false);
        return;
      }

      try {
        // Get current user
        const currentUser = await User.me();
        setUser(currentUser);

        // Load project
        const fetchedProject = await Project.filter({ id: projectId });
        if (!fetchedProject || fetchedProject.length === 0) {
          throw new Error('פרויקט לא נמצא');
        }
        
        const projectData = fetchedProject[0];
        setProject(projectData);
        
        // Check if user has access to this project
        if (currentUser.role !== 'admin' && 
            currentUser.id !== projectData.client_id && 
            currentUser.id !== projectData.selected_freelancer_id) {
          throw new Error('אין לך הרשאה לצפות בפרויקט זה');
        }

        // Load related data
        const projectProposals = await Proposal.filter({ project_id: projectId });
        setProposals(projectProposals);
        
        const projectMessages = await Message.filter({ project_id: projectId });
        setMessages(projectMessages);
        
        const projectFiles = await ProjectFile.filter({ project_id: projectId });
        setFiles(projectFiles);
        
        // Load service categories
        const serviceCategories = await ServiceCategory.list();
        setCategories(serviceCategories);
        
        // If project has a selected freelancer, load their details
        if (projectData.selected_freelancer_id) {
          const freelancerData = await User.filter({ id: projectData.selected_freelancer_id });
          if (freelancerData.length > 0) {
            setSelectedFreelancer(freelancerData[0]);
          }
        }

      } catch (error) {
        console.error('Error fetching project data:', error);
        setError(error.message || 'אירעה שגיאה בטעינת הפרויקט');
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [projectId]);

  const handleUpdateStatus = async (newStatus) => {
    if (!project) return;
    
    setIsUpdatingStatus(true);
    try {
      // Update project status
      const updatedProject = await Project.update(project.id, { status: newStatus });
      setProject(updatedProject);
    } catch (error) {
      console.error('Error updating project status:', error);
      setError('אירעה שגיאה בעדכון סטטוס הפרויקט');
    } finally {
      setIsUpdatingStatus(false);
    }
  };

  const getCategoryNames = (categoryIds) => {
    if (!categoryIds || !categories.length) return [];
    return categoryIds.map(id => {
      const category = categories.find(c => c.id === id);
      return category ? category.name : '';
    }).filter(Boolean);
  };

  const getStatusDescription = (status) => {
    switch(status) {
      case 'open': return 'הפרויקט פתוח להצעות מפרילנסרים';
      case 'in_progress': return 'הפרויקט בתהליך עבודה עם פרילנסר';
      case 'pending_payment': return 'העבודה הושלמה וממתינה לתשלום';
      case 'completed': return 'הפרויקט הושלם בהצלחה';
      case 'paid': return 'הפרויקט הושלם והתשלום בוצע';
      case 'cancelled_by_client': return 'הפרויקט בוטל על ידי הלקוח';
      case 'cancelled_by_freelancer': return 'הפרויקט בוטל על ידי הפרילנסר';
      case 'cancelled_by_admin': return 'הפרויקט בוטל על ידי מנהל המערכת';
      default: return '';
    }
  };
  
  const getStatusColor = (status) => {
    switch(status) {
      case 'open': return 'bg-blue-100 text-blue-800';
      case 'in_progress': return 'bg-green-100 text-green-800';
      case 'pending_payment': return 'bg-amber-100 text-amber-800';
      case 'completed': 
      case 'paid': return 'bg-purple-100 text-purple-800';
      case 'cancelled_by_client': 
      case 'cancelled_by_freelancer': 
      case 'cancelled_by_admin': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const isClient = user && project && user.id === project.client_id;
  const isFreelancer = user && project && user.id === project.selected_freelancer_id;
  const isAdmin = user && user.role === 'admin';

  const canClientMarkAsCompleted = project && project.status === 'in_progress' && isClient;
  const canFreelancerRequestPayment = project && project.status === 'in_progress' && isFreelancer;
  const canClientCancelProject = project && ['open', 'in_progress'].includes(project.status) && isClient;
  
  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-80">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto text-blue-600" />
          <p className="mt-2">טוען פרטי פרויקט...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <Alert variant="destructive" className="my-8">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>{error}</AlertDescription>
        <Button variant="outline" className="mt-4" onClick={() => navigate(-1)}>
          חזור
        </Button>
      </Alert>
    );
  }

  if (!project) {
    return (
      <Alert variant="destructive" className="my-8">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>הפרויקט לא נמצא</AlertDescription>
        <Button variant="outline" className="mt-4" onClick={() => navigate(-1)}>
          חזור
        </Button>
      </Alert>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-bold">{project.title}</h1>
            <Badge className={getStatusColor(project.status)}>
              {project.status === 'open' && 'פתוח להצעות'}
              {project.status === 'in_progress' && 'בתהליך'}
              {project.status === 'pending_payment' && 'ממתין לתשלום'}
              {project.status === 'completed' && 'הושלם'}
              {project.status === 'paid' && 'שולם'}
              {project.status === 'cancelled_by_client' && 'בוטל ע"י לקוח'}
              {project.status === 'cancelled_by_freelancer' && 'בוטל ע"י פרילנסר'}
              {project.status === 'cancelled_by_admin' && 'בוטל ע"י מנהל'}
            </Badge>
            {project.is_urgent && (
              <Badge variant="destructive">דחוף</Badge>
            )}
          </div>
          <p className="text-sm text-gray-500 mt-1">{getStatusDescription(project.status)}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          {isClient && proposals.filter(p => ['submitted', 'viewed_by_client'].includes(p.status)).length > 0 && (
            <Button asChild>
              <Link to={createPageUrl(`ProjectProposals?id=${project.id}`)}>
                צפה בהצעות ({proposals.filter(p => ['submitted', 'viewed_by_client'].includes(p.status)).length})
              </Link>
            </Button>
          )}
          
          {isFreelancer && project.status === 'open' && !proposals.some(p => p.freelancer_id === user.id) && (
            <Button asChild>
              <Link to={createPageUrl(`SubmitProposal?project_id=${project.id}`)}>
                <PlusCircle className="ml-2 rtl:mr-2 rtl:ml-0 h-4 w-4" />
                הגש הצעה
              </Link>
            </Button>
          )}

          {isClient && project.status === 'open' && (
            <Button variant="outline" asChild>
              <Link to={createPageUrl(`EditProject?id=${project.id}`)}>
                ערוך פרויקט
              </Link>
            </Button>
          )}

          {isClient && canClientMarkAsCompleted && (
            <Button 
              variant="default" 
              className="bg-green-600 hover:bg-green-700"
              disabled={isUpdatingStatus}
              onClick={() => handleUpdateStatus('completed')}
            >
              {isUpdatingStatus && <Loader2 className="mr-2 rtl:ml-2 rtl:mr-0 h-4 w-4 animate-spin" />}
              <CheckCircle className="mr-2 rtl:ml-2 rtl:mr-0 h-4 w-4" />
              אשר השלמת פרויקט
            </Button>
          )}

          {isFreelancer && canFreelancerRequestPayment && (
            <Button 
              variant="default"
              disabled={isUpdatingStatus}
              onClick={() => handleUpdateStatus('pending_payment')}
            >
              {isUpdatingStatus && <Loader2 className="mr-2 rtl:ml-2 rtl:mr-0 h-4 w-4 animate-spin" />}
              <CheckCircle className="mr-2 rtl:ml-2 rtl:mr-0 h-4 w-4" />
              בקש תשלום
            </Button>
          )}

          {isClient && canClientCancelProject && (
            <Button 
              variant="destructive" 
              disabled={isUpdatingStatus}
              onClick={() => handleUpdateStatus('cancelled_by_client')}
            >
              {isUpdatingStatus && <Loader2 className="mr-2 rtl:ml-2 rtl:mr-0 h-4 w-4 animate-spin" />}
              <X className="mr-2 rtl:ml-2 rtl:mr-0 h-4 w-4" />
              בטל פרויקט
            </Button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <ClipboardList className="mr-2 rtl:ml-2 rtl:mr-0 h-5 w-5" />
                פרטי הפרויקט
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="text-lg font-medium mb-2">תיאור</h3>
                <p className="whitespace-pre-wrap">{project.description}</p>
              </div>

              <div>
                <h3 className="text-lg font-medium mb-2">תחומי שירות</h3>
                <div className="flex flex-wrap gap-2">
                  {getCategoryNames(project.service_category_ids).map((name, index) => (
                    <Badge key={index} variant="secondary">{name}</Badge>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-4">
                <div>
                  <h3 className="font-medium text-gray-700">סוג פרויקט</h3>
                  <p>{project.project_type === 'one_time' ? 'חד פעמי' : 'מתמשך'}</p>
                </div>
                
                <div>
                  <h3 className="font-medium text-gray-700">תקציב</h3>
                  <p>
                    {project.budget_min && project.budget_max 
                      ? `₪${project.budget_min.toLocaleString()} - ₪${project.budget_max.toLocaleString()}`
                      : project.budget_min 
                        ? `החל מ-₪${project.budget_min.toLocaleString()}` 
                        : project.budget_max 
                          ? `עד ₪${project.budget_max.toLocaleString()}`
                          : 'לא צוין'
                    }
                  </p>
                </div>
                
                <div>
                  <h3 className="font-medium text-gray-700">תאריך פרסום</h3>
                  <p>{new Date(project.created_date).toLocaleDateString('he-IL')}</p>
                </div>
                
                {project.selected_freelancer_id && (
                  <div>
                    <h3 className="font-medium text-gray-700">תאריך תחילת עבודה</h3>
                    <p>{project.freelancer_hired_date 
                      ? new Date(project.freelancer_hired_date).toLocaleDateString('he-IL')
                      : 'לא צוין'}</p>
                  </div>
                )}
                
                {project.expected_delivery_date && (
                  <div>
                    <h3 className="font-medium text-gray-700">תאריך יעד לסיום</h3>
                    <p>{new Date(project.expected_delivery_date).toLocaleDateString('he-IL')}</p>
                  </div>
                )}
                
                {project.actual_completion_date && (
                  <div>
                    <h3 className="font-medium text-gray-700">תאריך סיום בפועל</h3>
                    <p>{new Date(project.actual_completion_date).toLocaleDateString('he-IL')}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {project.status !== 'open' && selectedFreelancer && (
            <Card className="mt-6">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <MessageSquare className="mr-2 rtl:ml-2 rtl:mr-0 h-5 w-5" />
                  תקשורת
                </CardTitle>
                <CardDescription>
                  שיחות והודעות בינך לבין {isClient ? 'הפרילנסר' : 'הלקוח'}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {messages.length > 0 ? (
                  <div className="space-y-4">
                    {/* Message display would go here */}
                    <Alert className="bg-blue-50 border-blue-200">
                      <Info className="h-4 w-4 text-blue-500" />
                      <AlertDescription className="text-blue-700">
                        תקשורת עם {isClient ? selectedFreelancer.full_name : 'הלקוח'} תוצג כאן.
                      </AlertDescription>
                    </Alert>
                  </div>
                ) : (
                  <div className="text-center p-6">
                    <p className="text-gray-500 mb-4">אין הודעות עדיין</p>
                    <Button asChild>
                      <Link to={createPageUrl(`Chat?project_id=${project.id}`)}>
                        <MessageSquare className="mr-2 rtl:ml-2 rtl:mr-0 h-4 w-4" />
                        התחל שיחה
                      </Link>
                    </Button>
                  </div>
                )}
              </CardContent>
              {messages.length > 0 && (
                <CardFooter>
                  <Button className="w-full" asChild>
                    <Link to={createPageUrl(`Chat?project_id=${project.id}`)}>
                      צפה בכל ההודעות
                    </Link>
                  </Button>
                </CardFooter>
              )}
            </Card>
          )}

          {/* Files section */}
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="flex items-center">
                <FileText className="mr-2 rtl:ml-2 rtl:mr-0 h-5 w-5" />
                קבצים
              </CardTitle>
              <CardDescription>
                קבצים משותפים לפרויקט
              </CardDescription>
            </CardHeader>
            <CardContent>
              {(selectedFreelancer || project.status === 'open') && (
                <FileUploader 
                  projectId={project.id} 
                  onFileUploaded={(newFile) => setFiles([...files, newFile])}
                />
              )}
              
              {files.length > 0 ? (
                <div className="mt-6 divide-y">
                  {files.map(file => (
                    <div key={file.id} className="py-3 flex items-center justify-between">
                      <div className="flex items-center">
                        <Download className="h-4 w-4 text-gray-500 mr-2 rtl:ml-2 rtl:mr-0" />
                        <div>
                          <p className="font-medium">{file.filename}</p>
                          <p className="text-sm text-gray-500">
                            הועלה ע"י {file.uploaded_by_id === user.id ? 'אתה' : 'משתמש אחר'} • {new Date(file.created_date).toLocaleDateString('he-IL')}
                          </p>
                        </div>
                      </div>
                      <Button variant="outline" size="sm" asChild>
                        <a href={file.file_url} target="_blank" rel="noopener noreferrer">
                          הורד
                        </a>
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center p-6">
                  <p className="text-gray-500">אין קבצים לפרויקט זה</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          {/* Status card */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">סטטוס</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Badge className={`${getStatusColor(project.status)} py-1 px-3 text-sm w-full justify-center`}>
                  {project.status === 'open' && 'פתוח להצעות'}
                  {project.status === 'in_progress' && 'בתהליך'}
                  {project.status === 'pending_payment' && 'ממתין לתשלום'}
                  {project.status === 'completed' && 'הושלם'}
                  {project.status === 'paid' && 'שולם'}
                  {project.status === 'cancelled_by_client' && 'בוטל ע"י לקוח'}
                  {project.status === 'cancelled_by_freelancer' && 'בוטל ע"י פרילנסר'}
                  {project.status === 'cancelled_by_admin' && 'בוטל ע"י מנהל'}
                </Badge>

                <div>
                  <p className="text-sm text-gray-600">{getStatusDescription(project.status)}</p>
                </div>
                
                {project.status === 'open' && proposals.length > 0 && isClient && (
                  <div className="mt-4">
                    <Button className="w-full" asChild>
                      <Link to={createPageUrl(`ProjectProposals?id=${project.id}`)}>
                        <Clock className="mr-2 rtl:ml-2 rtl:mr-0 h-4 w-4" />
                        צפה ב-{proposals.length} הצעות
                      </Link>
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Freelancer card if project is in progress or completed */}
          {project.selected_freelancer_id && selectedFreelancer && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">
                  {isClient ? 'פרילנסר נבחר' : 'פרטי לקוח'}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4 rtl:space-x-reverse">
                  <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-medium">
                    {selectedFreelancer.full_name?.charAt(0).toUpperCase() || 'U'}
                  </div>
                  <div>
                    <p className="font-medium">{selectedFreelancer.full_name}</p>
                    <p className="text-sm text-gray-500">
                      {selectedFreelancer.freelancer_data?.profession === 'accountant' && 'רואה חשבון'}
                      {selectedFreelancer.freelancer_data?.profession === 'bookkeeper' && 'מנהל חשבונות'}
                      {selectedFreelancer.freelancer_data?.profession === 'payroll_specialist' && 'חשב שכר'}
                    </p>
                  </div>
                </div>

                <Button variant="outline" className="w-full mt-4" asChild>
                  <Link to={createPageUrl(`Chat?project_id=${project.id}`)}>
                    <MessageSquare className="mr-2 rtl:ml-2 rtl:mr-0 h-4 w-4" />
                    שלח הודעה
                  </Link>
                </Button>
              </CardContent>
            </Card>
          )}
          
          {/* Client Actions */}
          {isClient && project.status === 'pending_payment' && (
            <Card className="border-amber-200 bg-amber-50">
              <CardHeader>
                <CardTitle className="text-lg text-amber-800">נדרש תשלום</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-amber-700 mb-4">
                  הפרילנסר סיים את העבודה ומבקש את התשלום. אנא בדוק את העבודה שבוצעה וסמן כי קיבלת אותה.
                </p>
                <Button 
                  className="w-full bg-amber-600 hover:bg-amber-700"
                  disabled={isUpdatingStatus}
                  onClick={() => handleUpdateStatus('paid')}
                >
                  {isUpdatingStatus && <Loader2 className="mr-2 rtl:ml-2 rtl:mr-0 h-4 w-4 animate-spin" />}
                  אשר תשלום ושלם
                </Button>
              </CardContent>
            </Card>
          )}
          
          {/* Proposal Info for freelancer */}
          {isFreelancer && proposals.find(p => p.freelancer_id === user.id) && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">ההצעה שלך</CardTitle>
              </CardHeader>
              <CardContent>
                {(() => {
                  const myProposal = proposals.find(p => p.freelancer_id === user.id);
                  if (!myProposal) return null;
                  
                  return (
                    <div className="space-y-3">
                      <div>
                        <p className="text-sm font-medium text-gray-500">סכום מוצע</p>
                        <p className="font-semibold">₪{myProposal.proposed_amount.toLocaleString()}</p>
                      </div>
                      
                      {myProposal.estimated_days_to_complete && (
                        <div>
                          <p className="text-sm font-medium text-gray-500">זמן ביצוע מוערך</p>
                          <p>{myProposal.estimated_days_to_complete} ימים</p>
                        </div>
                      )}
                      
                      <div>
                        <p className="text-sm font-medium text-gray-500">סטטוס הצעה</p>
                        <Badge className={
                          myProposal.status === 'accepted' ? 'bg-green-100 text-green-800' :
                          myProposal.status === 'rejected' ? 'bg-red-100 text-red-800' :
                          'bg-amber-100 text-amber-800'
                        }>
                          {myProposal.status === 'accepted' && 'התקבלה'}
                          {myProposal.status === 'rejected' && 'נדחתה'}
                          {myProposal.status === 'submitted' && 'הוגשה'}
                          {myProposal.status === 'viewed_by_client' && 'נצפתה'}
                          {myProposal.status === 'withdrawn_by_freelancer' && 'נמשכה'}
                        </Badge>
                      </div>
                      
                      <Separator />
                      
                      <div>
                        <p className="text-sm font-medium text-gray-500 mb-2">פרטים</p>
                        <p className="text-sm">{myProposal.cover_letter}</p>
                      </div>

                      {project.status === 'open' && ['submitted', 'viewed_by_client'].includes(myProposal.status) && (
                        <Button 
                          variant="destructive" 
                          size="sm"
                          className="w-full mt-2"
                          onClick={async () => {
                            try {
                              await Proposal.update(myProposal.id, { status: 'withdrawn_by_freelancer' });
                              // Update local state
                              const updatedProposals = proposals.map(p => 
                                p.id === myProposal.id ? { ...p, status: 'withdrawn_by_freelancer' } : p
                              );
                              setProposals(updatedProposals);
                            } catch (error) {
                              console.error('Error withdrawing proposal:', error);
                              setError('אירעה שגיאה במשיכת ההצעה');
                            }
                          }}
                        >
                          <X className="mr-2 rtl:ml-2 rtl:mr-0 h-4 w-4" />
                          משוך הצעה
                        </Button>
                      )}
                    </div>
                  );
                })()}
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}