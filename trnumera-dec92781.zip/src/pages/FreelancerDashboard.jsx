import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { User } from '@/api/entities';
import { Project } from '@/api/entities';
import { Proposal } from '@/api/entities';
import { ServiceCategory } from '@/api/entities';
import { Review } from '@/api/entities';
import { Briefcase, Clock, Search, Star, AlertCircle, Loader2, CheckCircle, DollarSign, UserCheck, TrendingUp } from 'lucide-react';

export default function FreelancerDashboardPage() {
  const [user, setUser] = useState(null);
  const [projects, setProjects] = useState([]);
  const [proposals, setProposals] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [categories, setCategories] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [stats, setStats] = useState({
    activeProjects: 0,
    pendingProposals: 0,
    completedProjects: 0,
    totalEarned: 0,
    averageRating: 0
  });

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Get current user
        const currentUser = await User.me();
        setUser(currentUser);

        // Load service categories for reference
        const serviceCategories = await ServiceCategory.list();
        setCategories(serviceCategories);

        if (currentUser) {
          // Load projects where this freelancer was selected
          const userProjects = await Project.filter({ selected_freelancer_id: currentUser.id });
          setProjects(userProjects);

          // Load all proposals submitted by this freelancer
          const userProposals = await Proposal.filter({ freelancer_id: currentUser.id });
          setProposals(userProposals);

          // Load reviews for this freelancer
          const userReviews = await Review.filter({ freelancer_id: currentUser.id });
          setReviews(userReviews);

          // Calculate stats
          const active = userProjects.filter(p => p.status === 'in_progress').length;
          const completed = userProjects.filter(p => ['completed', 'paid'].includes(p.status)).length;
          const pending = userProposals.filter(p => ['submitted', 'viewed_by_client'].includes(p.status)).length;
          
          // Calculate average rating
          let avgRating = 0;
          if (userReviews.length > 0) {
            avgRating = userReviews.reduce((sum, review) => sum + review.rating, 0) / userReviews.length;
          }

          setStats({
            activeProjects: active,
            pendingProposals: pending,
            completedProjects: completed,
            totalEarned: 0, // Will calculate from payment logs when available
            averageRating: avgRating
          });
        }
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  const getActiveProjects = () => {
    return projects.filter(p => p.status === 'in_progress')
      .sort((a, b) => new Date(b.freelancer_hired_date) - new Date(a.freelancer_hired_date))
      .slice(0, 3);
  };

  const getPendingProposals = () => {
    return proposals.filter(p => ['submitted', 'viewed_by_client'].includes(p.status))
      .sort((a, b) => new Date(b.created_date) - new Date(a.created_date))
      .slice(0, 3);
  };

  const getRelevantCategories = () => {
    if (!user?.freelancer_data?.expertise_area_ids || !categories) return [];
    
    return categories.filter(cat => 
      user.freelancer_data.expertise_area_ids.includes(cat.id)
    );
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-80">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto text-blue-600" />
          <p className="mt-2">טוען נתונים...</p>
        </div>
      </div>
    );
  }

  const isProfileComplete = user && user.freelancer_data && user.phone_number && user.id_card_number;
  const isProfileApproved = user?.freelancer_data?.is_approved === true;

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">שלום, {user?.full_name || 'אורח'}</h1>
          {isProfileApproved && (
            <div className="flex items-center mt-1 text-green-700">
              <CheckCircle className="h-4 w-4 mr-1 rtl:ml-1 rtl:mr-0" />
              <span className="text-sm">הפרופיל שלך מאושר</span>
            </div>
          )}
        </div>
        <Button asChild>
          <Link to={createPageUrl('SearchProjects')}>
            <Search className="ml-2 rtl:mr-2 rtl:ml-0 h-5 w-5" />
            חפש פרויקטים
          </Link>
        </Button>
      </div>
      
      {!isProfileComplete && (
        <Alert variant="warning">
          <AlertCircle className="h-5 w-5" />
          <AlertDescription>
            השלם את פרטי הפרופיל שלך כדי להתחיל להגיש הצעות לפרויקטים.
            <Button variant="outline" size="sm" className="mr-2 rtl:ml-2 rtl:mr-0 mt-2" asChild>
              <Link to={createPageUrl('CompleteProfileFreelancer')}>
                השלם פרופיל
              </Link>
            </Button>
          </AlertDescription>
        </Alert>
      )}
      
      {isProfileComplete && !isProfileApproved && (
        <Alert className="bg-amber-50 border-amber-200">
          <AlertCircle className="h-5 w-5 text-amber-500" />
          <AlertDescription className="text-amber-800">
            הפרופיל שלך נשלח לאישור מנהל המערכת. תקבל הודעה לאחר האישור.
          </AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground mb-1">פרויקטים פעילים</p>
                <h3 className="text-2xl font-bold">{stats.activeProjects}</h3>
              </div>
              <div className="p-2 bg-blue-100 text-blue-700 rounded-lg">
                <Briefcase className="h-5 w-5" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground mb-1">הצעות ממתינות</p>
                <h3 className="text-2xl font-bold">{stats.pendingProposals}</h3>
              </div>
              <div className="p-2 bg-amber-100 text-amber-700 rounded-lg">
                <Clock className="h-5 w-5" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground mb-1">דירוג ממוצע</p>
                <div className="flex items-center">
                  <h3 className="text-2xl font-bold mr-1 rtl:ml-1 rtl:mr-0">
                    {stats.averageRating.toFixed(1)}
                  </h3>
                  <Star className="h-5 w-5 text-yellow-500 fill-yellow-500" />
                </div>
              </div>
              <div className="p-2 bg-yellow-100 text-yellow-700 rounded-lg">
                <Star className="h-5 w-5" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground mb-1">סה"כ הכנסות</p>
                <h3 className="text-2xl font-bold">₪{stats.totalEarned.toLocaleString()}</h3>
              </div>
              <div className="p-2 bg-green-100 text-green-700 rounded-lg">
                <DollarSign className="h-5 w-5" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>פרויקטים פעילים</CardTitle>
            <CardDescription>הפרויקטים שאתה עובד עליהם כרגע</CardDescription>
          </CardHeader>
          <CardContent>
            {getActiveProjects().length > 0 ? (
              <div className="space-y-4">
                {getActiveProjects().map(project => (
                  <div key={project.id} className="border-b pb-3">
                    <Link 
                      to={createPageUrl(`Project?id=${project.id}`)} 
                      className="font-medium hover:text-blue-600 transition-colors"
                    >
                      {project.title}
                    </Link>
                    <div className="flex items-center justify-between mt-2">
                      <Badge className="bg-blue-100 text-blue-800">בתהליך</Badge>
                      <Button size="sm" variant="outline" asChild>
                        <Link to={createPageUrl(`Project?id=${project.id}`)}>
                          צפה בפרויקט
                        </Link>
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <div className="bg-gray-100 inline-flex rounded-full p-3 mb-4">
                  <Briefcase className="h-6 w-6 text-gray-500" />
                </div>
                <p className="text-muted-foreground">אין פרויקטים פעילים כרגע</p>
                <Button className="mt-3" size="sm" asChild>
                  <Link to={createPageUrl('SearchProjects')}>
                    <Search className="ml-2 rtl:mr-2 rtl:ml-0 h-4 w-4" />
                    חפש פרויקטים
                  </Link>
                </Button>
              </div>
            )}
          </CardContent>
          {getActiveProjects().length > 0 && (
            <CardFooter>
              <Button variant="outline" className="w-full" asChild>
                <Link to={createPageUrl('MyProjectsFreelancer')}>
                  צפה בכל הפרויקטים
                </Link>
              </Button>
            </CardFooter>
          )}
        </Card>
        
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>הצעות שהגשת</CardTitle>
            <CardDescription>הצעות אחרונות שהגשת ללקוחות</CardDescription>
          </CardHeader>
          <CardContent>
            {getPendingProposals().length > 0 ? (
              <div className="space-y-4">
                {getPendingProposals().map(proposal => (
                  <div key={proposal.id} className="border-b pb-3">
                    <p className="font-medium">הצעה עבור פרויקט: {proposal.project_id}</p>
                    <div className="flex justify-between mt-2">
                      <div className="flex items-center">
                        <Badge className={
                          proposal.status === 'submitted' ? 'bg-amber-100 text-amber-800' : 'bg-blue-100 text-blue-800'
                        }>
                          {proposal.status === 'submitted' ? 'ממתין לתגובה' : 'נצפה'}
                        </Badge>
                        <span className="text-xs text-gray-500 mr-2 rtl:ml-2 rtl:mr-0">
                          {new Date(proposal.created_date).toLocaleDateString('he-IL')}
                        </span>
                      </div>
                      <Button size="sm" variant="outline" asChild>
                        <Link to={createPageUrl(`Proposal?id=${proposal.id}`)}>
                          צפה בהצעה
                        </Link>
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <div className="bg-gray-100 inline-flex rounded-full p-3 mb-4">
                  <Clock className="h-6 w-6 text-gray-500" />
                </div>
                <p className="text-muted-foreground">לא הגשת הצעות עדיין</p>
                <Button className="mt-3" size="sm" asChild>
                  <Link to={createPageUrl('SearchProjects')}>
                    <Search className="ml-2 rtl:mr-2 rtl:ml-0 h-4 w-4" />
                    חפש פרויקטים
                  </Link>
                </Button>
              </div>
            )}
          </CardContent>
          {getPendingProposals().length > 0 && (
            <CardFooter>
              <Button variant="outline" className="w-full" asChild>
                <Link to={createPageUrl('MyProposals')}>
                  צפה בכל ההצעות
                </Link>
              </Button>
            </CardFooter>
          )}
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>תחומי התמחות</CardTitle>
          <CardDescription>
            התחומים בהם אתה מתמחה
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            {getRelevantCategories().length > 0 ? (
              getRelevantCategories().map(category => (
                <Badge key={category.id} className="bg-blue-100 text-blue-800 text-sm py-1 px-3">
                  {category.name}
                </Badge>
              ))
            ) : (
              <div className="text-sm text-muted-foreground">
                לא הוגדרו תחומי התמחות. 
                <Link to={createPageUrl('ProfileSettings')} className="text-blue-600 hover:underline mr-1 rtl:ml-1 rtl:mr-0">
                  עדכן את הפרופיל שלך
                </Link> 
                כדי להוסיף תחומי התמחות.
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>פעולות מהירות</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <Button variant="outline" className="h-auto flex-col px-4 py-8 space-y-3" asChild>
              <Link to={createPageUrl('SearchProjects')}>
                <Search className="h-8 w-8 text-blue-600" />
                <span className="text-base">חפש פרויקטים</span>
              </Link>
            </Button>
            <Button variant="outline" className="h-auto flex-col px-4 py-8 space-y-3" asChild>
              <Link to={createPageUrl('ProfileSettings')}>
                <UserCheck className="h-8 w-8 text-green-600" />
                <span className="text-base">עדכן פרופיל</span>
              </Link>
            </Button>
            <Button variant="outline" className="h-auto flex-col px-4 py-8 space-y-3" asChild>
              <Link to={createPageUrl('MyProjectsFreelancer')}>
                <Briefcase className="h-8 w-8 text-purple-600" />
                <span className="text-base">נהל הפרויקטים שלך</span>
              </Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}