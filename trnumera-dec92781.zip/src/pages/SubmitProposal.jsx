
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge'; // Added Badge
import { useNavigate, useSearchParams } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { User } from '@/api/entities';
import { Project } from '@/api/entities';
import { Proposal } from '@/api/entities';
import { AlertCircle, Loader2, Send } from 'lucide-react';

export default function SubmitProposalPage() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const projectId = searchParams.get('projectId');

  const [user, setUser] = useState(null);
  const [project, setProject] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [formState, setFormState] = useState({
    cover_letter: '',
    proposed_amount: '',
    estimated_days_to_complete: ''
  });

  useEffect(() => {
    const fetchData = async () => {
      if (!projectId) {
        setError('מזהה פרויקט חסר. לא ניתן להגיש הצעה.');
        setIsLoading(false);
        return;
      }
      try {
        const currentUser = await User.me();
        setUser(currentUser);

        if (currentUser.role !== 'freelancer') {
          setError('רק פרילנסרים יכולים להגיש הצעות.');
          setIsLoading(false);
          // Optionally redirect or show a more prominent message
          return;
        }
        
        // Check if freelancer profile is complete and approved
        if (!currentUser.freelancer_data?.is_approved) {
             setError('הפרופיל שלך עדיין לא אושר. לא ניתן להגיש הצעות עד לאישור הפרופיל.');
             setIsLoading(false);
             return;
        }


        const fetchedProject = await Project.get(projectId);
        setProject(fetchedProject);

      } catch (err) {
        console.error('Error fetching data:', err);
        setError('אירעה שגיאה בטעינת נתוני הפרויקט.');
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [projectId]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormState({ ...formState, [name]: value });
  };
  
  const handleNumberChange = (e) => {
    const { name, value } = e.target;
    // Only allow numbers
    if (value === '' || /^\d+$/.test(value)) {
      setFormState({ ...formState, [name]: value });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError('');

    try {
      if (!user) throw new Error('משתמש לא מחובר');
      if (!project) throw new Error('פרטי הפרויקט לא נטענו');

      if (!formState.cover_letter.trim()) throw new Error('נא למלא מכתב מקדים');
      if (!formState.proposed_amount.trim()) throw new Error('נא להזין סכום מוצע');
      
      const proposalData = {
        project_id: project.id,
        freelancer_id: user.id,
        cover_letter: formState.cover_letter,
        proposed_amount: Number(formState.proposed_amount),
        estimated_days_to_complete: formState.estimated_days_to_complete 
                                      ? Number(formState.estimated_days_to_complete) 
                                      : undefined
      };

      await Proposal.create(proposalData);
      
      // Redirect to project page or a success page
      navigate(createPageUrl(`Project?id=${project.id}&proposalSubmitted=true`));

    } catch (err) {
      console.error('Error submitting proposal:', err);
      setError(err.message || 'אירעה שגיאה בהגשת ההצעה.');
      setIsSubmitting(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-80">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto text-blue-600" />
          <p className="mt-2">טוען...</p>
        </div>
      </div>
    );
  }

  if (error && !project) { // Show critical errors prominently if project data couldn't load
     return (
       <div className="container mx-auto py-8 px-4 text-center">
         <Alert variant="destructive" className="max-w-md mx-auto">
           <AlertCircle className="h-4 w-4" />
           <AlertDescription>{error}</AlertDescription>
         </Alert>
         <Button onClick={() => navigate(-1)} variant="outline" className="mt-4">חזור</Button>
       </div>
     );
  }
  
  return (
    <div className="container mx-auto max-w-2xl py-8 px-4">
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-2xl font-bold">הגשת הצעה לפרויקט</CardTitle>
          {project && <CardDescription>עבור: {project.title}</CardDescription>}
        </CardHeader>
        
        <form onSubmit={handleSubmit}>
          <CardContent className="space-y-6">
            {error && ( // Show non-critical errors within the form
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
            
            {!project && !isLoading && ( // Case where project data failed but form should still show (less critical error)
                <Alert variant="warning">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>לא ניתן היה לטעון את פרטי הפרויקט במלואם, אך עדיין ניתן לנסות להגיש הצעה.</AlertDescription>
                </Alert>
            )}

            <div>
              <Label htmlFor="cover_letter">מכתב מקדים / הסבר</Label>
              <Textarea
                id="cover_letter"
                name="cover_letter"
                value={formState.cover_letter}
                onChange={handleChange}
                placeholder="ספר ללקוח למה אתה מתאים לפרויקט, מה הניסיון שלך ואיך תוכל לעזור."
                className="h-40"
                required
              />
              <p className="text-xs text-gray-500 mt-1">
                זהו המקום לשכנע את הלקוח לבחור בך. היה ברור, מקצועי וממוקד.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="proposed_amount">הסכום המוצע שלך (₪)</Label>
                <Input
                  id="proposed_amount"
                  name="proposed_amount"
                  type="text" // Keep as text to use custom number validation
                  value={formState.proposed_amount}
                  onChange={handleNumberChange}
                  placeholder="לדוגמה: 1500"
                  required
                />
              </div>
              <div>
                <Label htmlFor="estimated_days_to_complete">זמן מוערך לסיום (ימים)</Label>
                <Input
                  id="estimated_days_to_complete"
                  name="estimated_days_to_complete"
                  type="text" // Keep as text to use custom number validation
                  value={formState.estimated_days_to_complete}
                  onChange={handleNumberChange}
                  placeholder="לדוגמה: 7 (אופציונלי)"
                />
              </div>
            </div>
            
            {project && (
              <div className="bg-gray-50 p-4 rounded-md border">
                <h4 className="font-semibold mb-2">תזכורת: פרטי הפרויקט</h4>
                <p className="text-sm"><strong>תקציב הלקוח:</strong> 
                  {project.budget_min && project.budget_max ? ` ₪${project.budget_min} - ₪${project.budget_max}` 
                  : project.budget_min ? ` החל מ-₪${project.budget_min}` 
                  : project.budget_max ? ` עד ₪${project.budget_max}` 
                  : ' לא צוין'}
                </p>
                <p className="text-sm"><strong>סוג פרויקט:</strong> {project.project_type === 'one_time' ? 'חד פעמי' : 'מתמשך'}</p>
                {project.is_urgent && <Badge className="mt-1 bg-red-100 text-red-700">דחוף</Badge>}
              </div>
            )}
          </CardContent>
          
          <CardFooter className="flex justify-between">
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => navigate(createPageUrl(`Project?id=${projectId}`))}
              disabled={isSubmitting}
            >
              ביטול וחזרה לפרויקט
            </Button>
            <Button type="submit" disabled={isSubmitting || !project || (user && !user.freelancer_data?.is_approved)}>
              {isSubmitting && <Loader2 className="mr-2 rtl:ml-2 rtl:mr-0 h-4 w-4 animate-spin" />}
              <Send className="mr-2 rtl:ml-2 rtl:mr-0 h-4 w-4" />
              הגש הצעה
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  );
}
