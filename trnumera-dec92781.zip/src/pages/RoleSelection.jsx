import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { User } from '@/api/entities';
import { useNavigate } from 'react-router-dom';
import { Briefcase, Building, UserPlus, ArrowLeft } from 'lucide-react';
import { createPageUrl } from '@/utils'; // For back button to Home

export default function RoleSelectionPage() {
  const navigate = useNavigate();
  const [isLoadingClient, setIsLoadingClient] = useState(false);
  const [isLoadingFreelancer, setIsLoadingFreelancer] = useState(false);
  const [error, setError] = useState('');

  const handleRoleSelection = async (role) => {
    if (role === 'client') setIsLoadingClient(true);
    if (role === 'freelancer') setIsLoadingFreelancer(true);
    setError('');

    try {
      localStorage.setItem('preferredRole', role);
      // Optional: if you were collecting name/email on a previous custom form:
      // localStorage.setItem('preferredName', 'Some Name'); // Example if collected elsewhere
      await User.login(); // This will redirect to Google OAuth
      // After successful Google login, user is redirected back.
      // Layout.js will handle checking localStorage and updating user data.
    } catch (loginError) {
      console.error(`Error during Google login after selecting ${role}:`, loginError);
      setError("שגיאה בתהליך ההתחברות עם גוגל: " + loginError.message);
      if (role === 'client') setIsLoadingClient(false);
      if (role === 'freelancer') setIsLoadingFreelancer(false);
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-slate-900 to-slate-700 p-4" dir="rtl">
      <Card className="w-full max-w-lg shadow-2xl bg-white">
        <CardHeader className="text-center">
          <UserPlus className="h-12 w-12 text-blue-600 mx-auto mb-4" />
          <CardTitle className="text-3xl font-bold text-gray-800">הצטרפות לפלטפורמה</CardTitle>
          <CardDescription className="text-lg text-gray-600 mt-2">
            אנא בחר/י את סוג החשבון המתאים לך כדי שנוכל להתאים עבורך את החוויה הטובה ביותר.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6 p-8">
          {error && (
            <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4" role="alert">
              <p className="font-bold">שגיאה</p>
              <p>{error}</p>
            </div>
          )}
          <Button
            onClick={() => handleRoleSelection('client')}
            className="w-full py-8 text-xl bg-blue-600 hover:bg-blue-700 text-white transition-all duration-300 ease-in-out transform hover:scale-105"
            disabled={isLoadingClient || isLoadingFreelancer}
          >
            <Building className="ml-3 h-7 w-7 rtl:mr-3 rtl:ml-0" />
            {isLoadingClient ? "מעבד..." : "אני לקוח/ה (מחפש/ת שירות)"}
          </Button>
          <Button
            onClick={() => handleRoleSelection('freelancer')}
            className="w-full py-8 text-xl bg-green-600 hover:bg-green-700 text-white transition-all duration-300 ease-in-out transform hover:scale-105"
            disabled={isLoadingClient || isLoadingFreelancer}
          >
            <Briefcase className="ml-3 h-7 w-7 rtl:mr-3 rtl:ml-0" />
            {isLoadingFreelancer ? "מעבד..." : "אני פרילנסר/ית (מציע/ה שירות)"}
          </Button>
           <Button variant="link" onClick={() => navigate(createPageUrl('Home'))} className="w-full text-gray-600 hover:text-gray-800 mt-4">
            <ArrowLeft className="ml-2 h-4 w-4 rtl:mr-2 rtl:ml-0" />
            חזרה לדף הבית
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}