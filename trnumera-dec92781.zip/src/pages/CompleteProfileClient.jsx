import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { User } from '@/api/entities';
import { UploadFile } from '@/api/integrations';
import { useNavigate, Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { AlertCircle, Upload, Loader2, UserCircle, Building2, CheckCircle, FileText, HelpCircle } from 'lucide-react';
import { Separator } from '@/components/ui/separator';

export default function CompleteProfileClientPage() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [formState, setFormState] = useState({
    phone_number: '',
    id_card_number: '',
    company_name: '',
    business_id_number: '',
    industry_type: '',
    address_street: '',
    address_city: '',
    address_zip_code: '',
    contact_person_role: '',
    is_terms_agreed: false,
  });
  
  const [idCardFile, setIdCardFile] = useState(null);
  const [idCardPreview, setIdCardPreview] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [activeTab, setActiveTab] = useState('personal');
  const fileInputRef = useRef(null);
  
  // Fetch current user
  useEffect(() => {
    const fetchData = async () => {
      try {
        // Get current user
        const currentUser = await User.me();
        setUser(currentUser);
        
        // Pre-fill form with existing user data if available
        if (currentUser) {
          setFormState(prev => ({
            ...prev,
            phone_number: currentUser.phone_number || '',
            id_card_number: currentUser.id_card_number || '',
            address_street: currentUser.address_street || '',
            address_city: currentUser.address_city || '',
            address_zip_code: currentUser.address_zip_code || '',
            is_terms_agreed: currentUser.is_terms_agreed || false,
            // If user has client_data, use those values
            ...(currentUser.client_data && {
              company_name: currentUser.client_data.company_name || '',
              business_id_number: currentUser.client_data.business_id_number || '',
              industry_type: currentUser.client_data.industry_type || '',
              contact_person_role: currentUser.client_data.contact_person_role || '',
            })
          }));
          
          // Set preview if file exists
          if (currentUser.id_card_url) {
            setIdCardPreview(currentUser.id_card_url);
          }
        }
      } catch (error) {
        console.error('Error fetching data:', error);
        setError('אירעה שגיאה בטעינת הנתונים. אנא רענן את העמוד.');
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchData();
  }, []);
  
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormState((prev) => ({ ...prev, [name]: value }));
  };
  
  const handleCheckboxChange = (name, checked) => {
    setFormState((prev) => ({ ...prev, [name]: checked }));
  };
  
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setIdCardFile(file);
      const reader = new FileReader();
      reader.onload = (e) => {
        setIdCardPreview(e.target.result);
      };
      reader.readAsDataURL(file);
    }
  };
  
  const triggerFileInput = () => {
    fileInputRef.current.click();
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Basic client-side validation
    if (activeTab === 'personal') {
      if (!formState.phone_number || !formState.id_card_number || 
          (!idCardFile && !idCardPreview)) {
        setError('אנא מלא את כל שדות החובה בדף זה');
        return;
      }
    } else if (activeTab === 'company') {
      if (!formState.company_name || !formState.business_id_number) {
        setError('אנא מלא את כל שדות החובה בדף זה');
        return;
      }
    } else if (activeTab === 'terms') {
      if (!formState.is_terms_agreed) {
        setError('עליך להסכים לתנאי השימוש כדי להמשיך');
        return;
      }
    }
    
    // If this is the final tab, submit the whole form
    if (activeTab === 'terms') {
      setIsSubmitting(true);
      setError('');
      
      try {
        let userData = {
          phone_number: formState.phone_number,
          id_card_number: formState.id_card_number,
          address_street: formState.address_street,
          address_city: formState.address_city,
          address_zip_code: formState.address_zip_code,
          is_terms_agreed: formState.is_terms_agreed,
          client_data: {
            company_name: formState.company_name,
            business_id_number: formState.business_id_number,
            industry_type: formState.industry_type,
            contact_person_role: formState.contact_person_role,
          }
        };
        
        // Upload ID card if a new file was selected
        if (idCardFile) {
          const { file_url: idCardUrl } = await UploadFile({ file: idCardFile });
          userData.id_card_url = idCardUrl;
        }
        
        // Update user data
        await User.updateMyUserData(userData);
        
        setSuccessMessage('הפרופיל שלך עודכן בהצלחה!');
        
        // Optionally redirect after a delay
        setTimeout(() => {
          navigate(createPageUrl('ClientDashboard'));
        }, 3000);
      } catch (error) {
        console.error('Error updating profile:', error);
        setError('אירעה שגיאה בעדכון הפרופיל. אנא נסה שוב מאוחר יותר.');
      } finally {
        setIsSubmitting(false);
      }
    } else {
      // Otherwise, just move to the next tab
      if (activeTab === 'personal') {
        setActiveTab('company');
      } else if (activeTab === 'company') {
        setActiveTab('terms');
      }
    }
  };
  
  const renderFileUploadBox = (filePreview, triggerFunction, title, description, formats) => (
    <div 
      className={`border-2 border-dashed rounded-md p-4 text-center cursor-pointer hover:bg-gray-50 transition-colors ${
        filePreview ? 'border-green-300 bg-green-50' : 'border-gray-300'
      }`}
      onClick={triggerFunction}
    >
      {filePreview ? (
        <div className="space-y-2">
          <div className="flex items-center justify-center">
            {filePreview.startsWith('data:image') ? (
              <img src={filePreview} alt="תצוגה מקדימה של הקובץ" className="max-h-32 max-w-full" />
            ) : (
              <div className="bg-green-100 text-green-700 p-2 rounded-full">
                <FileText className="h-6 w-6" />
              </div>
            )}
          </div>
          <p className="text-sm text-green-700">הקובץ הועלה בהצלחה. לחץ כאן להחלפת הקובץ.</p>
        </div>
      ) : (
        <div className="space-y-2">
          <div className="flex items-center justify-center">
            <Upload className="h-6 w-6 text-gray-400" />
          </div>
          <p className="text-sm">{title}</p>
          <p className="text-xs text-gray-500">{description}</p>
          <p className="text-xs text-gray-400">{formats}</p>
        </div>
      )}
    </div>
  );
  
  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto text-blue-600" />
          <p className="mt-2">טוען נתונים...</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="flex flex-col items-center justify-center py-10 px-4">
      <Card className="w-full max-w-2xl shadow-lg">
        <CardHeader className="pb-2">
          <CardTitle className="text-2xl font-bold">השלמת פרטי לקוח</CardTitle>
          <CardDescription>
            אנא השלם את הפרטים הבאים כדי להשלים את תהליך ההרשמה
          </CardDescription>
        </CardHeader>
        
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-3 mx-6 my-4">
            <TabsTrigger value="personal">פרטים אישיים</TabsTrigger>
            <TabsTrigger value="company">פרטי עסק</TabsTrigger>
            <TabsTrigger value="terms">אישור תנאים</TabsTrigger>
          </TabsList>
          
          <form onSubmit={handleSubmit}>
            {successMessage && (
              <Alert className="mx-6 my-4 bg-green-50 border-green-200">
                <CheckCircle className="h-5 w-5 text-green-600" />
                <AlertDescription className="text-green-700">{successMessage}</AlertDescription>
              </Alert>
            )}
            
            {error && (
              <Alert variant="destructive" className="mx-6 my-4">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
            
            <TabsContent value="personal" className="mt-0">
              <CardContent className="space-y-6 pt-4">
                <div className="space-y-2">
                  <h3 className="text-lg font-medium flex items-center">
                    <UserCircle className="h-5 w-5 mr-2 rtl:ml-2 rtl:mr-0 text-blue-600" />
                    פרטי איש קשר
                  </h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <Label htmlFor="phone_number">מספר טלפון נייד <span className="text-red-500">*</span></Label>
                      <Input
                        id="phone_number"
                        name="phone_number"
                        value={formState.phone_number}
                        onChange={handleInputChange}
                        placeholder="05X-XXXXXXX"
                      />
                    </div>
                    
                    <div className="space-y-1">
                      <Label htmlFor="id_card_number">מספר תעודת זהות <span className="text-red-500">*</span></Label>
                      <Input
                        id="id_card_number"
                        name="id_card_number"
                        value={formState.id_card_number}
                        onChange={handleInputChange}
                        placeholder="הזן מספר תעודת זהות"
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-1">
                    <Label htmlFor="contact_person_role">תפקיד</Label>
                    <Input
                      id="contact_person_role"
                      name="contact_person_role"
                      value={formState.contact_person_role}
                      onChange={handleInputChange}
                      placeholder="תפקידך בארגון"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>צילום תעודת זהות <span className="text-red-500">*</span></Label>
                    <input
                      type="file"
                      ref={fileInputRef}
                      onChange={handleFileChange}
                      accept="image/*,.pdf"
                      className="hidden"
                    />
                    
                    {renderFileUploadBox(
                      idCardPreview, 
                      triggerFileInput, 
                      "לחץ להעלאת צילום תעודת זהות",
                      "יש להעלות צילום ברור של תעודת הזהות כולל ספח",
                      "(פורמטים נתמכים: תמונה או PDF)"
                    )}
                  </div>
                </div>
              </CardContent>
            </TabsContent>
            
            <TabsContent value="company" className="mt-0">
              <CardContent className="space-y-6 pt-4">
                <div className="space-y-2">
                  <h3 className="text-lg font-medium flex items-center">
                    <Building2 className="h-5 w-5 mr-2 rtl:ml-2 rtl:mr-0 text-blue-600" />
                    פרטי העסק
                  </h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <Label htmlFor="company_name">שם העסק / החברה <span className="text-red-500">*</span></Label>
                      <Input
                        id="company_name"
                        name="company_name"
                        value={formState.company_name}
                        onChange={handleInputChange}
                        placeholder="שם העסק או החברה"
                      />
                    </div>
                    
                    <div className="space-y-1">
                      <Label htmlFor="business_id_number">מספר עוסק / ח.פ. <span className="text-red-500">*</span></Label>
                      <Input
                        id="business_id_number"
                        name="business_id_number"
                        value={formState.business_id_number}
                        onChange={handleInputChange}
                        placeholder="הזן מספר עוסק / ח.פ."
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-1">
                    <Label htmlFor="industry_type">ענף עיסוק</Label>
                    <Input
                      id="industry_type"
                      name="industry_type"
                      value={formState.industry_type}
                      onChange={handleInputChange}
                      placeholder="תחום העיסוק העיקרי של העסק"
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <div className="space-y-1 col-span-2">
                      <Label htmlFor="address_street">כתובת העסק</Label>
                      <Input
                        id="address_street"
                        name="address_street"
                        value={formState.address_street}
                        onChange={handleInputChange}
                        placeholder="רחוב ומספר"
                      />
                    </div>
                    
                    <div className="space-y-1">
                      <Label htmlFor="address_zip_code">מיקוד</Label>
                      <Input
                        id="address_zip_code"
                        name="address_zip_code"
                        value={formState.address_zip_code}
                        onChange={handleInputChange}
                        placeholder="מיקוד"
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-1">
                    <Label htmlFor="address_city">עיר</Label>
                    <Input
                      id="address_city"
                      name="address_city"
                      value={formState.address_city}
                      onChange={handleInputChange}
                      placeholder="עיר"
                    />
                  </div>
                </div>
              </CardContent>
            </TabsContent>
            
            <TabsContent value="terms" className="mt-0">
              <CardContent className="space-y-6 pt-4">
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <HelpCircle className="h-5 w-5 text-blue-600" />
                    <h3 className="text-lg font-medium">חשוב לדעת</h3>
                  </div>
                  
                  <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                    <p className="text-sm text-gray-700">
                      כלקוח רשום במערכת תוכל:
                    </p>
                    <ul className="list-disc list-inside text-sm text-gray-700 mt-2 space-y-1">
                      <li>לפרסם פרויקטים עבור פרילנסרים</li>
                      <li>לבחור את הפרילנסר המתאים לך מבין המגישים הצעות</li>
                      <li>לנהל את הפרויקט בצורה נוחה ובטוחה</li>
                      <li>לנהל קשר ישיר עם הפרילנסר במערכת</li>
                    </ul>
                  </div>
                  
                  <Separator />
                  
                  <div className="flex items-start space-x-2 rtl:space-x-reverse">
                    <Checkbox 
                      id="terms" 
                      checked={formState.is_terms_agreed}
                      onCheckedChange={(checked) => handleCheckboxChange('is_terms_agreed', checked)}
                    />
                    <div className="grid gap-1.5 leading-none">
                      <label
                        htmlFor="terms"
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        <span className="text-red-500 mr-1 rtl:ml-1 rtl:mr-0">*</span>
                        אני מסכים/ה ל
                        <Link to={createPageUrl('TermsOfService')} className="text-blue-600 hover:underline mx-1">תנאי השימוש</Link>
                        ול
                        <Link to={createPageUrl('PrivacyPolicy')} className="text-blue-600 hover:underline mx-1">מדיניות הפרטיות</Link>
                      </label>
                      <p className="text-sm text-gray-500">
                        אני מאשר/ת שכל המידע שמסרתי הוא אמיתי ומדויק ושאני מוסמך/ת לייצג את העסק הנ"ל
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </TabsContent>
            
            <CardFooter className="flex justify-between flex-col sm:flex-row gap-4 border-t pt-6">
              {activeTab !== 'personal' && (
                <Button 
                  type="button" 
                  variant="outline"
                  onClick={() => setActiveTab(activeTab === 'company' ? 'personal' : 'company')}
                >
                  הקודם
                </Button>
              )}
              
              <Button 
                type="submit" 
                className="ml-auto rtl:mr-auto rtl:ml-0 bg-blue-600 hover:bg-blue-700"
                disabled={isSubmitting}
              >
                {isSubmitting && <Loader2 className="mr-2 rtl:ml-2 rtl:mr-0 h-4 w-4 animate-spin" />}
                {activeTab === 'terms' ? 
                  (isSubmitting ? 'מעבד...' : 'סיים הרשמה') : 
                  'הבא'
                }
              </Button>
            </CardFooter>
          </form>
        </Tabs>
      </Card>
    </div>
  );
}