
import React, { useState, useEffect } from 'react';
import { Project } from '@/api/entities';
import { User } from '@/api/entities';
import { ServiceCategory } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Loader2, Briefcase, Search, Filter, Eye, Edit3, Trash2, MoreHorizontal } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function AdminProjectsPage() {
  const [projects, setProjects] = useState([]);
  const [users, setUsers] = useState([]); // To map client/freelancer IDs to names
  const [categories, setCategories] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [projectTypeFilter, setProjectTypeFilter] = useState('all');

  const [selectedProject, setSelectedProject] = useState(null);
  const [isDeleteAlertOpen, setIsDeleteAlertOpen] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setIsLoading(true);
    try {
      const [allProjects, allUsers, allCategories] = await Promise.all([
        Project.list('-created_date'),
        User.list(),
        ServiceCategory.list()
      ]);
      setProjects(allProjects);
      setUsers(allUsers);
      setCategories(allCategories);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const getUserName = (userId) => {
    const user = users.find(u => u.id === userId);
    return user ? user.full_name : (userId ? `משתמש (${userId.slice(0,6)}...)` : 'לא הוקצה / לא ידוע');
  };

  const getCategoryNames = (categoryIds) => {
    if (!categoryIds || !categories.length) return "לא צוינו";
    return categoryIds.map(id => {
      const category = categories.find(c => c.id === id);
      return category ? category.name : '';
    }).filter(Boolean).join(', ') || "לא צוינו";
  };

  const getProjectStatusBadge = (status) => {
    switch (status) {
      case 'open': return <Badge className="bg-blue-100 text-blue-800">פתוח</Badge>;
      case 'in_progress': return <Badge className="bg-green-100 text-green-800">בתהליך</Badge>;
      case 'pending_payment': return <Badge className="bg-yellow-100 text-yellow-700">ממתין לתשלום</Badge>;
      case 'completed': return <Badge className="bg-purple-100 text-purple-700">הושלם</Badge>;
      case 'paid': return <Badge className="bg-emerald-100 text-emerald-700">שולם</Badge>;
      case 'cancelled_by_client':
      case 'cancelled_by_freelancer':
      case 'cancelled_by_admin':
        return <Badge variant="destructive">בוטל</Badge>;
      default: return <Badge variant="outline">{status}</Badge>;
    }
  };

  const handleDeleteProject = async () => {
    if (!selectedProject) return;
    console.warn(`Attempting to delete project ${selectedProject.id} - This should be a soft delete or careful operation.`);
    // For now, just close and refresh
    setIsDeleteAlertOpen(false);
    // fetchData(); // If actual delete happens
  };

  const filteredProjects = projects.filter(project => {
    const searchMatch = searchTerm.trim() === '' || 
                        project.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        project.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        getUserName(project.client_id)?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        getUserName(project.selected_freelancer_id)?.toLowerCase().includes(searchTerm.toLowerCase());
    const statusMatch = statusFilter === 'all' || project.status === statusFilter;
    const typeMatch = projectTypeFilter === 'all' || project.project_type === projectTypeFilter;
    
    return searchMatch && statusMatch && typeMatch;
  });

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-80">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <CardTitle className="text-2xl flex items-center">
              <Briefcase className="h-6 w-6 mr-2 rtl:ml-2 rtl:mr-0 text-blue-600" />
              ניהול פרויקטים
            </CardTitle>
            <CardDescription>צפייה וניהול של כל הפרויקטים במערכת.</CardDescription>
          </div>
          {/* <Button>צור פרויקט חדש (כמנהל)</Button> // Future functionality */}
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 rtl:right-2.5 rtl:left-auto top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="חפש לפי כותרת, תיאור, לקוח או פרילנסר"
                className="pl-8 rtl:pr-8 rtl:pl-4"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <SelectValue placeholder="סנן לפי סטטוס" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">כל הסטטוסים</SelectItem>
                <SelectItem value="open">פתוח</SelectItem>
                <SelectItem value="in_progress">בתהליך</SelectItem>
                <SelectItem value="pending_payment">ממתין לתשלום</SelectItem>
                <SelectItem value="completed">הושלם</SelectItem>
                <SelectItem value="paid">שולם</SelectItem>
                <SelectItem value="cancelled_by_client">בוטל (לקוח)</SelectItem>
                <SelectItem value="cancelled_by_freelancer">בוטל (פרילנסר)</SelectItem>
                <SelectItem value="cancelled_by_admin">בוטל (מנהל)</SelectItem>
              </SelectContent>
            </Select>
            <Select value={projectTypeFilter} onValueChange={setProjectTypeFilter}>
              <SelectTrigger className="w-full sm:w-[150px]">
                <SelectValue placeholder="סנן לפי סוג" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">כל הסוגים</SelectItem>
                <SelectItem value="one_time">חד פעמי</SelectItem>
                <SelectItem value="ongoing">מתמשך</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>כותרת</TableHead>
                <TableHead>לקוח</TableHead>
                <TableHead>פרילנסר</TableHead>
                <TableHead>סטטוס</TableHead>
                <TableHead>קטגוריות</TableHead>
                <TableHead>תאריך יצירה</TableHead>
                <TableHead className="text-right">פעולות</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredProjects.map(project => (
                <TableRow key={project.id}>
                  <TableCell className="font-medium max-w-xs truncate">
                    <Link to={createPageUrl(`Project?id=${project.id}`)} className="hover:underline" title={project.title}>
                        {project.title}
                    </Link>
                  </TableCell>
                  <TableCell>{getUserName(project.client_id)}</TableCell>
                  <TableCell>{getUserName(project.selected_freelancer_id)}</TableCell>
                  <TableCell>{getProjectStatusBadge(project.status)}</TableCell>
                  <TableCell className="max-w-xs truncate" title={getCategoryNames(project.service_category_ids)}>
                    {getCategoryNames(project.service_category_ids)}
                  </TableCell>
                  <TableCell>{new Date(project.created_date).toLocaleDateString('he-IL')}</TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>פעולות</DropdownMenuLabel>
                        <DropdownMenuItem asChild>
                           <Link to={createPageUrl(`Project?id=${project.id}`)}>
                                <Eye className="h-4 w-4 mr-2 rtl:ml-2 rtl:mr-0" />
                                צפה בפרויקט
                           </Link>
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => { /* Implement edit project functionality */ }}>
                          <Edit3 className="h-4 w-4 mr-2 rtl:ml-2 rtl:mr-0" />
                          ערוך פרויקט
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem 
                            className="text-red-600 focus:text-red-700 focus:bg-red-50"
                            onClick={() => { setSelectedProject(project); setIsDeleteAlertOpen(true); }}
                        >
                          <Trash2 className="h-4 w-4 mr-2 rtl:ml-2 rtl:mr-0" />
                          מחק פרויקט (לא פעיל)
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          {filteredProjects.length === 0 && (
            <div className="text-center py-10 text-gray-500">
              לא נמצאו פרויקטים התואמים את החיפוש או הסינון.
            </div>
          )}
        </CardContent>
      </Card>

      {/* Delete Project Confirmation */}
      <AlertDialog open={isDeleteAlertOpen} onOpenChange={setIsDeleteAlertOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>אישור מחיקת פרויקט</AlertDialogTitle>
            <AlertDialogDescription>
              האם אתה בטוח שברצונך למחוק את הפרויקט "{selectedProject?.title}"? 
              פעולה זו (כרגע) אינה מוחקת בפועל.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>ביטול</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteProject} className="bg-red-600 hover:bg-red-700">
              מחק (דמה)
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
