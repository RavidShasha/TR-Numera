
import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { Project } from '@/api/entities'; // To get project context for chats
import { Message } from '@/api/entities';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Send, User as UserIcon, MessageSquare, Loader2, ArrowLeft, Search } from 'lucide-react';

// This is a simplified global chat page showing recent conversations
// A more detailed ProjectChat page would handle chat within a specific project context

export default function ChatPage() {
  const [user, setUser] = useState(null);
  const [conversations, setConversations] = useState([]); // Stores { otherUser, lastMessage, projectTitle, projectId }
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchInitialData = async () => {
      try {
        const currentUser = await User.me();
        setUser(currentUser);

        if (currentUser) {
          // Fetch messages where the current user is either sender or receiver
          const sentMessages = await Message.filter({ sender_id: currentUser.id }, '-created_date', 50);
          const receivedMessages = await Message.filter({ receiver_id: currentUser.id }, '-created_date', 50);
          const allUserMessages = [...sentMessages, ...receivedMessages].sort((a,b) => new Date(b.created_date) - new Date(a.created_date));
          
          // Group messages by project and then by other user to form conversations
          const groupedConversations = {};

          for (const message of allUserMessages) {
            const otherUserId = message.sender_id === currentUser.id ? message.receiver_id : message.sender_id;
            const conversationKey = `${message.project_id}-${otherUserId}`; // Key by project and other user

            if (!groupedConversations[conversationKey]) {
              const [otherUserData, projectData] = await Promise.all([
                User.get(otherUserId).catch(() => null),
                Project.get(message.project_id).catch(() => null)
              ]);

              if (otherUserData && projectData) {
                groupedConversations[conversationKey] = {
                  otherUser: otherUserData,
                  projectTitle: projectData.title,
                  projectId: projectData.id,
                  lastMessage: message,
                  unreadCount: 0 // Basic unread count logic can be added here
                };
              }
            }
            // Update last message if this one is newer
            if (groupedConversations[conversationKey] && new Date(message.created_date) > new Date(groupedConversations[conversationKey].lastMessage.created_date)) {
                groupedConversations[conversationKey].lastMessage = message;
            }
            // Increment unread count (simplified)
            if (groupedConversations[conversationKey] && message.receiver_id === currentUser.id && !message.is_read) {
                 // groupedConversations[conversationKey].unreadCount++; // This needs Message schema to have is_read
            }
          }
          setConversations(Object.values(groupedConversations).sort((a,b) => new Date(b.lastMessage.created_date) - new Date(a.lastMessage.created_date)));
        }
      } catch (error) {
        console.error("Error fetching chat data:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchInitialData();
  }, []);

  const handleConversationClick = (projectId, otherUserId) => {
    // Navigate to a specific project chat page
    // For now, this page is a placeholder and doesn't implement full chat functionality
    navigate(createPageUrl(`ProjectChat?project_id=${projectId}&participant_id=${otherUserId}`));
  };
  
  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Loader2 className="h-12 w-12 animate-spin text-blue-600" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="text-center py-10">
        <p>עליך להתחבר כדי לצפות בהודעות.</p>
        <Button asChild className="mt-4">
          <Link to={createPageUrl('Login')}>התחבר</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 px-2 sm:px-4 h-[calc(100vh-150px)] flex flex-col">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-800">הודעות</h1>
        {/* Search/Filter can be added here */}
      </div>

      {conversations.length === 0 ? (
        <div className="flex-grow flex flex-col items-center justify-center text-center bg-gray-50 p-8 rounded-lg">
          <MessageSquare className="h-16 w-16 text-gray-300 mb-6" />
          <h2 className="text-xl font-semibold text-gray-700 mb-2">אין הודעות עדיין</h2>
          <p className="text-gray-500">
            כאשר תתחיל פרויקטים ותתקשר עם משתמשים אחרים, ההודעות שלך יופיעו כאן.
          </p>
        </div>
      ) : (
        <Card className="flex-grow flex flex-col overflow-hidden">
          <CardHeader className="border-b">
            <CardTitle>שיחות אחרונות</CardTitle>
          </CardHeader>
          <CardContent className="p-0 flex-grow overflow-hidden">
            <ScrollArea className="h-full">
              <div className="divide-y">
                {conversations.map((conv) => (
                  <div
                    key={`${conv.projectId}-${conv.otherUser.id}`}
                    className="p-4 hover:bg-gray-50 cursor-pointer transition-colors"
                    onClick={() => handleConversationClick(conv.projectId, conv.otherUser.id)}
                  >
                    <div className="flex items-center gap-3">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={conv.otherUser.photo_url || `https://avatar.vercel.sh/${conv.otherUser.email}.png`} alt={conv.otherUser.full_name} />
                        <AvatarFallback>{conv.otherUser.full_name ? conv.otherUser.full_name.substring(0, 2).toUpperCase() : '??'}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex justify-between items-center">
                          <h3 className="font-semibold text-sm">{conv.otherUser.full_name}</h3>
                          <span className="text-xs text-gray-400">
                            {new Date(conv.lastMessage.created_date).toLocaleTimeString('he-IL', { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                        <p className="text-xs text-gray-500 truncate">
                          <span className="font-medium">פרויקט:</span> {conv.projectTitle}
                        </p>
                        <p className={`text-xs truncate ${conv.lastMessage.sender_id === user.id ? 'text-gray-500' : 'text-gray-700 font-medium'}`}>
                          {conv.lastMessage.sender_id === user.id ? 'אתה: ' : ''}
                          {conv.lastMessage.content}
                        </p>
                      </div>
                      {/*conv.unreadCount > 0 && (
                        <Badge className="bg-blue-500 text-white text-xs px-1.5 py-0.5">{conv.unreadCount}</Badge>
                      )*/}
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
