import React from 'react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { CheckCircle, TrendingUp, DollarSign, Users, ArrowLeft, Briefcase as BriefcaseIcon, ShieldCheck as ShieldCheckIcon } from 'lucide-react'; // Added BriefcaseIcon and ShieldCheckIcon imports

export default function ForFreelancersPage() {
  return (
    <div className="space-y-12">
      <section className="text-center py-16 bg-gradient-to-r from-teal-500 to-cyan-500 text-white rounded-xl shadow-xl">
        <h1 className="text-4xl md:text-5xl font-bold mb-6">הזדמנויות חדשות מחכות לך</h1>
        <p className="text-lg md:text-xl mb-10 max-w-2xl mx-auto">
          הצטרף לפלטפורמה המובילה לפרילנסרים בתחומי החשבונאות והשכר בישראל. הרחב את מעגל הלקוחות שלך ומצא פרויקטים מרתקים.
        </p>
        <Button size="lg" className="bg-white text-teal-600 hover:bg-gray-100 shadow-md" asChild>
          <Link to={createPageUrl('Register', { role: 'freelancer' })}>
            הירשם כפרילנסר <ArrowLeft className="mr-2 rtl:ml-2 rtl:mr-0 h-5 w-5" />
          </Link>
        </Button>
      </section>

      <section>
        <h2 className="text-3xl font-semibold text-center mb-10 text-gray-800">למה כדאי להצטרף אלינו כפרילנסר?</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          <FeatureCard
            icon={<TrendingUp className="w-8 h-8 text-blue-500" />}
            title="גישה לפרויקטים חדשים"
            description="קבל גישה למגוון רחב של פרויקטים מלקוחות בכל רחבי הארץ, קטנים כגדולים."
          />
          <FeatureCard
            icon={<DollarSign className="w-8 h-8 text-green-500" />}
            title="הגדל את ההכנסות שלך"
            description="קבע תעריפים משלך, הגש הצעות תחרותיות והרווח יותר על בסיס הכישורים והניסיון שלך."
          />
          <FeatureCard
            icon={<Users className="w-8 h-8 text-purple-500" />}
            title="בנה מוניטין מקצועי"
            description="קבל דירוגים ומשוב מלקוחות, הצג את תיק העבודות שלך ובנה מותג אישי חזק."
          />
          <FeatureCard
            icon={<CheckCircle className="w-8 h-8 text-orange-500" />}
            title="תהליך עבודה פשוט"
            description="נהל את כל הפרויקטים, התקשורת והתשלומים במקום אחד, בצורה נוחה ומאובטחת."
          />
           <FeatureCard
            icon={<BriefcaseIcon className="w-8 h-8 text-red-500" />} {/* Used BriefcaseIcon */}
            title="גמישות מלאה"
            description="עבוד מתי שנוח לך, מאיפה שנוח לך. בחר את הפרויקטים שמתאימים לך."
          />
           <FeatureCard
            icon={<ShieldCheckIcon className="w-8 h-8 text-indigo-500" />} {/* Used ShieldCheckIcon */}
            title="סביבה מאובטחת"
            description="אנו דואגים לאימות לקוחות ולתהליכי תשלום בטוחים כדי שתוכל להתמקד בעבודה."
          />
        </div>
      </section>
      
      <section className="bg-gray-100 p-8 rounded-xl">
        <h2 className="text-3xl font-semibold text-center mb-8 text-gray-800">איך מתחילים?</h2>
        <ol className="relative border-r border-gray-300 dark:border-gray-700 space-y-8 mr-4 rtl:border-l rtl:border-r-0 rtl:ml-4 rtl:mr-0">
          <StepItem number="1" title="הרשמה מהירה">
            מלא את פרטי הפרופיל שלך, העלה תעודות רלוונטיות וספר על הניסיון וההתמחויות שלך.
          </StepItem>
          <StepItem number="2" title="אישור פרופיל">
            צוות האתר יבדוק את פרטיך ויאשר את הפרופיל שלך תוך זמן קצר.
          </StepItem>
          <StepItem number="3" title="התחל לחפש פרויקטים">
            סנן פרויקטים לפי תחום, תקציב או דחיפות, והגש הצעות לפרויקטים שמעניינים אותך.
          </StepItem>
           <StepItem number="4" title="התחל לעבוד">
            לאחר שהצעתך התקבלה, צור קשר עם הלקוח, בצע את העבודה ובסיומה קבל תשלום מאובטח.
          </StepItem>
        </ol>
      </section>

      <section className="text-center py-12">
        <h2 className="text-3xl font-semibold mb-6 text-gray-800">יש לך שאלות?</h2>
        <p className="text-lg text-gray-600 mb-8 max-w-xl mx-auto">
          צוות התמיכה שלנו זמין לענות על כל שאלה ולסייע לך בכל שלב.
        </p>
        {/* Replace with a link to a contact page or FAQ */}
        <Button size="lg" variant="outline" asChild>
          <Link to={createPageUrl('ContactUs')}>צור קשר</Link>
        </Button>
      </section>
    </div>
  );
}

const FeatureCard = ({ icon, title, description }) => (
  <div className="p-6 bg-white rounded-lg shadow-lg hover:shadow-xl transition-shadow">
    <div className="flex justify-center items-center mb-4">
      {icon}
    </div>
    <h3 className="text-xl font-semibold mb-2 text-center">{title}</h3>
    <p className="text-gray-600 text-center">{description}</p>
  </div>
);

const StepItem = ({ number, title, children }) => (
  <li className="mb-10 mr-6 rtl:ml-6 rtl:mr-0">
    <span className="absolute flex items-center justify-center w-8 h-8 bg-blue-100 rounded-full -right-4 ring-4 ring-white dark:ring-gray-900 dark:bg-blue-900 rtl:-left-4 rtl:-right-auto">
      <span className="font-bold text-blue-600">{number}</span>
    </span>
    <h3 className="flex items-center mb-1 text-lg font-semibold text-gray-900 dark:text-white">
      {title}
    </h3>
    <p className="block mb-2 text-sm font-normal leading-none text-gray-500 dark:text-gray-500">
      {children}
    </p>
  </li>
);