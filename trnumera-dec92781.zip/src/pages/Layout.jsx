
import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { User } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger, SheetHeader } from '@/components/ui/sheet';
import { 
    Menu, 
    Briefcase as BriefcaseIcon,
    Users, 
    LogIn, 
    UserPlus, 
    Search, 
    Building as BuildingIcon,
    LogOut, 
    LayoutDashboard, 
    FileText, 
    ShieldCheck, 
    Info as InfoIcon,
    MessageSquare, 
    Bell, 
    Settings, 
    Home as HomeIcon, 
    ListChecks, 
    PlusCircle, 
    Shapes, 
    Loader2 
} from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { Notification } from '@/api/entities';


// Placeholder for logo - replace with actual image path when available
// const LogoPlaceholder = () => (
//   <div className="flex items-center font-bold text-xl text-blue-600">
//     <BriefcaseIcon className="w-7 h-7 mr-2 rtl:ml-2 rtl:mr-0" />
//     <span>שם האתר</span> {/* Replace with your site name/logo component */}
//   </div>
// );

const isAuthPage = (pageName) => {
  return ['Login', 'Register', 'RoleSelection'].includes(pageName);
};

export default function Layout({ children, currentPageName }) {
  const [user, setUser] = useState(null);
  const [isLoadingUser, setIsLoadingUser] = useState(true);
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);

  const fetchUserData = async () => {
    setIsLoadingUser(true);
    try {
      const currentUser = await User.me();
      setUser(currentUser);

      if (currentUser) {
        let roleToSet = localStorage.getItem('preferredRole');
        let nameToSet = localStorage.getItem('preferredName'); 

        if (roleToSet && (!currentUser.role || currentUser.role === '')) { 
          try {
            const updateData = { role: roleToSet };
            if (nameToSet) {
              updateData.full_name = nameToSet;
            }
            await User.updateMyUserData(updateData);
            const updatedUser = { ...currentUser, role: roleToSet }; // Create a new object for state update
            if (nameToSet && !updatedUser.full_name) updatedUser.full_name = nameToSet;
            setUser(updatedUser); // Set the new user object to trigger re-render

            localStorage.removeItem('preferredRole');
            if (nameToSet) localStorage.removeItem('preferredName');
            
            if (updatedUser.role === 'freelancer') {
              navigate(createPageUrl('CompleteProfileFreelancer'));
              return; 
            } else if (updatedUser.role === 'client') {
              navigate(createPageUrl('CompleteProfileClient'));
              return; 
            }
          } catch (updateError) {
            console.error("Error setting initial role/name:", updateError);
          }
        }
        
        // Profile completion check
        if (currentUser.is_profile_complete === false && 
            !isAuthPage(currentPageName) && 
            !isCompleteProfilePage(currentPageName, currentUser.role)) {
          if (currentUser.role === 'freelancer') {
            navigate(createPageUrl('CompleteProfileFreelancer'));
          } else if (currentUser.role === 'client') {
            navigate(createPageUrl('CompleteProfileClient'));
          }
        }
        
        const userNotifications = await Notification.filter({ user_id: currentUser.id, is_read: false }, '-created_date');
        setNotifications(userNotifications);
        setUnreadCount(userNotifications.length);
      }
    } catch (error) {
      setUser(null);
      if (error.message !== "User not authenticated") { // Avoid logging for non-logged in users
        console.log('Error fetching user data or not logged in:', error.message);
      }
    } finally {
      setIsLoadingUser(false);
    }
  };

  useEffect(() => {
    fetchUserData();
  }, [currentPageName, navigate]);

  const handleLogout = async () => {
    await User.logout();
    setUser(null);
    setNotifications([]);
    setUnreadCount(0);
    navigate(createPageUrl('Home')); // Ensure 'Home' with capital H
  };
  
  const isCompleteProfilePage = (pageName, role) => {
    if (role === 'freelancer' && pageName === 'CompleteProfileFreelancer') return true;
    if (role === 'client' && pageName === 'CompleteProfileClient') return true;
    return false;
  };

  const navItems = [
    { name: 'דף הבית', href: createPageUrl('Home'), icon: HomeIcon, roles: ['all'] }, // Ensure 'Home'
    { name: 'אודות', href: createPageUrl('About'), icon: InfoIcon, roles: ['all'] },
    { name: 'עבור פרילנסרים', href: createPageUrl('ForFreelancers'), icon: BriefcaseIcon, roles: ['all'] },
    { name: 'עבור לקוחות', href: createPageUrl('ForClients'), icon: BuildingIcon, roles: ['all'] },
  ];

  const clientNavItems = [
    { name: 'דשבורד', href: createPageUrl('ClientDashboard'), icon: LayoutDashboard },
    { name: 'פרויקטים שלי', href: createPageUrl('MyProjectsClient'), icon: ListChecks },
    { name: 'צור פרויקט', href: createPageUrl('CreateProject'), icon: PlusCircle },
    { name: 'חפש פרילנסרים', href: createPageUrl('SearchFreelancers'), icon: Users },
  ];

  const freelancerNavItems = [
    { name: 'דשבורד', href: createPageUrl('FreelancerDashboard'), icon: LayoutDashboard },
    { name: 'הפרויקטים שלי', href: createPageUrl('MyProjectsFreelancer'), icon: ListChecks },
    { name: 'ההצעות שלי', href: createPageUrl('MyProposals'), icon: FileText },
    { name: 'חפש פרויקטים', href: createPageUrl('SearchProjects'), icon: Search },
  ];

  const adminNavItems = [
    { name: 'דשבורד ניהול', href: createPageUrl('AdminDashboard'), icon: ShieldCheck },
    { name: 'ניהול משתמשים', href: createPageUrl('AdminUsers'), icon: Users },
    { name: 'ניהול פרויקטים', href: createPageUrl('AdminProjects'), icon: ListChecks },
    { name: 'ניהול קטגוריות', href: createPageUrl('AdminCategories'), icon: Shapes },
  ];
  
  const UserMenu = () => (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="relative h-10 w-10 rounded-full">
          <Avatar className="h-9 w-9">
            <AvatarImage src={user?.profile_picture_url || undefined} alt={user?.full_name || 'User'} />
            <AvatarFallback>{user?.full_name ? user.full_name.substring(0, 1).toUpperCase() : 'U'}</AvatarFallback>
          </Avatar>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-56" align="end" forceMount dir="rtl">
        <DropdownMenuLabel className="font-normal">
          <div className="flex flex-col space-y-1">
            <p className="text-sm font-medium leading-none">{user?.full_name}</p>
            <p className="text-xs leading-none text-muted-foreground">{user?.email}</p>
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        {user?.role === 'client' && clientNavItems.map(item => (
          <DropdownMenuItem key={item.name} asChild>
            <Link to={item.href} className="flex items-center">
              <item.icon className="mr-2 h-4 w-4 rtl:ml-2 rtl:mr-0" />{item.name}
            </Link>
          </DropdownMenuItem>
        ))}
        {user?.role === 'freelancer' && freelancerNavItems.map(item => (
          <DropdownMenuItem key={item.name} asChild>
            <Link to={item.href} className="flex items-center">
              <item.icon className="mr-2 h-4 w-4 rtl:ml-2 rtl:mr-0" />{item.name}
            </Link>
          </DropdownMenuItem>
        ))}
         {user?.role === 'admin' && adminNavItems.map(item => (
          <DropdownMenuItem key={item.name} asChild>
            <Link to={item.href} className="flex items-center">
              <item.icon className="mr-2 h-4 w-4 rtl:ml-2 rtl:mr-0" />{item.name}
            </Link>
          </DropdownMenuItem>
        ))}
        <DropdownMenuSeparator />
        <DropdownMenuItem asChild>
          <Link to={createPageUrl('ProfileSettings')} className="flex items-center">
            <Settings className="mr-2 h-4 w-4 rtl:ml-2 rtl:mr-0" />הגדרות חשבון
          </Link>
        </DropdownMenuItem>
         <DropdownMenuItem asChild>
           <Link to={createPageUrl('Notifications')} className="flex items-center">
             <Bell className="mr-2 h-4 w-4 rtl:ml-2 rtl:mr-0" />התראות {unreadCount > 0 && <Badge className="mr-2 rtl:ml-2 rtl:mr-0">{unreadCount}</Badge>}
           </Link>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={handleLogout} className="text-red-600 hover:!text-red-700 cursor-pointer flex items-center">
          <LogOut className="mr-2 h-4 w-4 rtl:ml-2 rtl:mr-0" />התנתקות
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );

  if (isLoadingUser && !isAuthPage(currentPageName)) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Loader2 className="h-12 w-12 animate-spin text-blue-600" />
      </div>
    );
  }
  
  if (currentPageName === 'RoleSelection') {
    return <main>{children}</main>;
  }

  return (
    <div className="min-h-screen flex flex-col bg-gray-50" dir="rtl">
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <Link to={createPageUrl('Home')} className="flex items-center space-x-2 rtl:space-x-reverse"> {/* Ensure 'Home' */}
                <img src="/logo.png" alt="TaxMatch Logo" className="h-8 w-auto" onError={(e) => e.currentTarget.style.display='none'} />
                <span className="font-bold text-xl text-gray-800">TaxMatch</span>
              </Link>
            </div>
            <nav className="hidden md:flex space-x-6 rtl:space-x-reverse items-center">
              {navItems.map((item) => (
                <Link
                  key={item.name}
                  to={item.href}
                  className={`text-sm font-medium ${currentPageName === item.href.substring(item.href.indexOf('/') + 1).split('?')[0] ? 'text-blue-600' : 'text-gray-500 hover:text-gray-700'}`}
                >
                  {item.name}
                </Link>
              ))}
            </nav>
            <div className="flex items-center space-x-2 rtl:space-x-reverse">
              {isLoadingUser ? (
                <Loader2 className="h-5 w-5 animate-spin text-gray-500" />
              ) : user ? (
                <UserMenu />
              ) : (
                <>
                  <Button variant="outline" onClick={async () => await User.login()}>
                    התחברות
                  </Button>
                  <Button asChild>
                    <Link to={createPageUrl('RoleSelection')}>הרשמה</Link>
                  </Button>
                </>
              )}
            </div>
            <div className="md:hidden">
               <Sheet>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <Menu className="h-6 w-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="w-full max-w-xs p-6" dir="rtl">
                  <SheetHeader className="mb-6">
                     <Link to={createPageUrl('Home')} className="flex items-center space-x-2 rtl:space-x-reverse mb-4"> {/* Ensure 'Home' */}
                        <img src="/logo.png" alt="TaxMatch Logo" className="h-8 w-auto" onError={(e) => e.currentTarget.style.display='none'} />
                        <span className="font-bold text-xl text-gray-800">TaxMatch</span>
                     </Link>
                  </SheetHeader>
                  <nav className="flex flex-col space-y-3">
                    {[...navItems, ...(user && user.role === 'client' ? clientNavItems : []), ...(user && user.role === 'freelancer' ? freelancerNavItems : []), ...(user && user.role === 'admin' ? adminNavItems : [])]
                      .filter((value, index, self) => 
                        index === self.findIndex((t) => (t.name === value.name && t.href === value.href))
                      )
                      .map((item) => (
                      <Link
                        key={item.name + "-mobile"}
                        to={item.href}
                        className={`flex items-center py-2 px-3 rounded-md text-base font-medium ${currentPageName === item.href.substring(item.href.indexOf('/') + 1).split('?')[0] ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-100 hover:text-gray-900'}`}
                      >
                        {item.icon && <item.icon className="mr-3 h-5 w-5 rtl:ml-3 rtl:mr-0 text-gray-500 group-hover:text-gray-600" />}
                        {item.name}
                      </Link>
                    ))}
                    {user && (
                        <>
                          <Link to={createPageUrl('ProfileSettings')}  className={`flex items-center py-2 px-3 rounded-md text-base font-medium ${currentPageName === 'ProfileSettings' ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-100 hover:text-gray-900'}`}>
                            <Settings className="mr-3 h-5 w-5 rtl:ml-3 rtl:mr-0 text-gray-500 group-hover:text-gray-600" />
                            הגדרות חשבון
                          </Link>
                          <Link to={createPageUrl('Notifications')} className={`flex items-center py-2 px-3 rounded-md text-base font-medium ${currentPageName === 'Notifications' ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-100 hover:text-gray-900'}`}>
                             <Bell className="mr-3 h-5 w-5 rtl:ml-3 rtl:mr-0 text-gray-500 group-hover:text-gray-600" />
                             התראות {unreadCount > 0 && <Badge className="mr-auto rtl:ml-auto rtl:mr-0">{unreadCount}</Badge>}
                           </Link>
                        </>
                    )}
                  </nav>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </div>
      </header>
      <main className="flex-grow container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {children}
      </main>
      <footer className="bg-gray-800 text-white py-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-6">
            <div>
              <h3 className="text-lg font-semibold mb-2">TaxMatch</h3>
              <p className="text-sm text-gray-400">מחברים בין עסקים ליועצי מס ורואי חשבון.</p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-2">קישורים שימושיים</h3>
              <ul className="space-y-1 text-sm">
                <li><Link to={createPageUrl('About')} className="hover:text-blue-300">אודות</Link></li>
                <li><Link to={createPageUrl('TermsOfService')} className="hover:text-blue-300">תנאי שימוש</Link></li>
                <li><Link to={createPageUrl('PrivacyPolicy')} className="hover:text-blue-300">מדיניות פרטיות</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-2">יצירת קשר</h3>
              <p className="text-sm text-gray-400">support@taxmatch.example.com</p> {/* Placeholder email */}
            </div>
          </div>
          <p className="text-sm text-gray-400">&copy; {new Date().getFullYear()} TaxMatch. כל הזכויות שמורות.</p>
        </div>
      </footer>
    </div>
  );
}
