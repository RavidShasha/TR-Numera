import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { User } from '@/api/entities';
import { ServiceCategory } from '@/api/entities';
import { UploadFile } from '@/api/integrations';
import { useNavigate, Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { AlertCircle, Upload, Loader2, UserCircle, X, Calendar, CheckCircle, FileText, HelpCircle } from 'lucide-react';
import { Separator } from '@/components/ui/separator';

export default function CompleteProfileFreelancerPage() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [formState, setFormState] = useState({
    phone_number: '',
    id_card_number: '',
    address_street: '',
    address_city: '',
    address_zip_code: '',
    profession: 'accountant',
    profession_level: '',
    experience_years: '',
    expertise_area_ids: [],
    is_terms_agreed: false,
  });
  
  const [serviceCategories, setServiceCategories] = useState([]);
  const [idCardFile, setIdCardFile] = useState(null);
  const [idCardPreview, setIdCardPreview] = useState('');
  const [certificateFile, setCertificateFile] = useState(null);
  const [certificatePreview, setCertificatePreview] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [activeTab, setActiveTab] = useState('personal');
  const idCardFileInputRef = useRef(null);
  const certificateFileInputRef = useRef(null);
  
  // Fetch current user and service categories
  useEffect(() => {
    const fetchData = async () => {
      try {
        // Get current user
        const currentUser = await User.me();
        setUser(currentUser);
        
        // Pre-fill form with existing user data if available
        if (currentUser) {
          setFormState(prev => ({
            ...prev,
            phone_number: currentUser.phone_number || '',
            id_card_number: currentUser.id_card_number || '',
            address_street: currentUser.address_street || '',
            address_city: currentUser.address_city || '',
            address_zip_code: currentUser.address_zip_code || '',
            is_terms_agreed: currentUser.is_terms_agreed || false,
            // If user has freelancer_data, use those values
            ...(currentUser.freelancer_data && {
              profession: currentUser.freelancer_data.profession || 'accountant',
              profession_level: currentUser.freelancer_data.profession_level || '',
              experience_years: currentUser.freelancer_data.experience_years?.toString() || '',
              expertise_area_ids: currentUser.freelancer_data.expertise_area_ids || [],
            })
          }));
          
          // Set previews if files exist
          if (currentUser.id_card_url) {
            setIdCardPreview(currentUser.id_card_url);
          }
          if (currentUser.freelancer_data?.professional_certificate_url) {
            setCertificatePreview(currentUser.freelancer_data.professional_certificate_url);
          }
        }
        
        // Fetch service categories
        const categories = await ServiceCategory.list();
        setServiceCategories(categories);
        
        // If no categories exist, create some default ones for testing
        if (categories.length === 0) {
          // Create sample categories if none exist
          const sampleCategories = [
            { name: "התאמות בנקים", description: "התאמות מול חשבונות בנק" },
            { name: "הנהלת חשבונות שוטפת", description: "טיפול בהנהלת חשבונות שוטפת" },
            { name: "דוחות מע\"מ", description: "הכנת דוחות מע\"מ תקופתיים" },
            { name: "הכנת משכורות", description: "הכנת תלושי שכר ומשכורות" },
            { name: "דוחות 126", description: "הכנת והגשת טופס 126" },
            { name: "דוחות 856", description: "הכנת והגשת טופס 856" },
            { name: "הכנת דוחות מס", description: "הכנת דוחות מס שנתיים" },
            { name: "ביקורת חשבונות", description: "ביקורת פנימית או חיצונית" }
          ];
          
          for (const category of sampleCategories) {
            await ServiceCategory.create(category);
          }
          
          const createdCategories = await ServiceCategory.list();
          setServiceCategories(createdCategories);
        }
      } catch (error) {
        console.error('Error fetching data:', error);
        setError('אירעה שגיאה בטעינת הנתונים. אנא רענן את העמוד.');
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchData();
  }, []);
  
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormState((prev) => ({ ...prev, [name]: value }));
  };
  
  const handleCheckboxChange = (name, checked) => {
    setFormState((prev) => ({ ...prev, [name]: checked }));
  };
  
  const handleRadioChange = (name, value) => {
    setFormState((prev) => ({ ...prev, [name]: value }));
  };
  
  const handleSelectChange = (name, value) => {
    setFormState((prev) => ({ ...prev, [name]: value }));
  };
  
  const handleIdCardFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setIdCardFile(file);
      const reader = new FileReader();
      reader.onload = (e) => {
        setIdCardPreview(e.target.result);
      };
      reader.readAsDataURL(file);
    }
  };
  
  const handleCertificateFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setCertificateFile(file);
      const reader = new FileReader();
      reader.onload = (e) => {
        setCertificatePreview(e.target.result);
      };
      reader.readAsDataURL(file);
    }
  };
  
  const triggerIdCardFileInput = () => {
    idCardFileInputRef.current.click();
  };
  
  const triggerCertificateFileInput = () => {
    certificateFileInputRef.current.click();
  };
  
  const toggleExpertiseArea = (categoryId) => {
    setFormState((prev) => {
      const currentExpertise = [...prev.expertise_area_ids];
      const index = currentExpertise.indexOf(categoryId);
      
      if (index === -1) {
        // Add if not present
        return {
          ...prev,
          expertise_area_ids: [...currentExpertise, categoryId],
        };
      } else {
        // Remove if already selected
        currentExpertise.splice(index, 1);
        return {
          ...prev,
          expertise_area_ids: currentExpertise,
        };
      }
    });
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Basic client-side validation
    if (activeTab === 'personal') {
      if (!formState.phone_number || !formState.id_card_number || 
          (!idCardFile && !idCardPreview)) {
        setError('אנא מלא את כל שדות החובה בדף זה');
        return;
      }
    } else if (activeTab === 'professional') {
      if (!formState.profession || !formState.profession_level || 
          !formState.experience_years || formState.expertise_area_ids.length < 3 || 
          (!certificateFile && !certificatePreview)) {
        setError('אנא מלא את כל שדות החובה, בחר לפחות 3 תחומי התמחות והעלה תעודת מקצוע');
        return;
      }
    } else if (activeTab === 'terms') {
      if (!formState.is_terms_agreed) {
        setError('עליך להסכים לתנאי השימוש כדי להמשיך');
        return;
      }
    }
    
    // If this is the final tab, submit the whole form
    if (activeTab === 'terms') {
      setIsSubmitting(true);
      setError('');
      
      try {
        let userData = {
          phone_number: formState.phone_number,
          id_card_number: formState.id_card_number,
          address_street: formState.address_street,
          address_city: formState.address_city,
          address_zip_code: formState.address_zip_code,
          is_terms_agreed: formState.is_terms_agreed,
          freelancer_data: {
            profession: formState.profession,
            profession_level: formState.profession_level,
            experience_years: parseInt(formState.experience_years),
            expertise_area_ids: formState.expertise_area_ids,
          }
        };
        
        // Upload ID card if a new file was selected
        if (idCardFile) {
          const { file_url: idCardUrl } = await UploadFile({ file: idCardFile });
          userData.id_card_url = idCardUrl;
        }
        
        // Upload certificate if a new file was selected
        if (certificateFile) {
          const { file_url: certificateUrl } = await UploadFile({ file: certificateFile });
          userData.freelancer_data.professional_certificate_url = certificateUrl;
        }
        
        // Update user data
        await User.updateMyUserData(userData);
        
        setSuccessMessage('הפרופיל שלך עודכן בהצלחה! הנתונים שלך יבדקו על ידי מנהל המערכת ותקבל אישור בהקדם.');
        
        // Optionally redirect after a delay
        setTimeout(() => {
          navigate(createPageUrl('FreelancerDashboard'));
        }, 3000);
      } catch (error) {
        console.error('Error updating profile:', error);
        setError('אירעה שגיאה בעדכון הפרופיל. אנא נסה שוב מאוחר יותר.');
      } finally {
        setIsSubmitting(false);
      }
    } else {
      // Otherwise, just move to the next tab
      if (activeTab === 'personal') {
        setActiveTab('professional');
      } else if (activeTab === 'professional') {
        setActiveTab('terms');
      }
    }
  };
  
  // Helper function to get appropriate profession level options based on selected profession
  const getProfessionLevelOptions = () => {
    if (formState.profession === 'accountant') {
      return [
        { value: 'level_1', label: 'סוג 1' },
        { value: 'level_2', label: 'סוג 2' },
        { value: 'level_2_advanced', label: 'סוג 2 מתקדם (הנה"ח)' },
        { value: 'level_3', label: 'סוג 3' }
      ];
    } else if (formState.profession === 'payroll_specialist') {
      return [
        { value: 'ministry_of_labor', label: 'תעודה מטעם משרד הכלכלה' },
        { value: 'cpa_chamber', label: 'תעודה מטעם לשכת רואי החשבון' }
      ];
    } else if (formState.profession === 'bookkeeper') {
      return [
        { value: 'junior', label: 'מנהל חשבונות זוטר' },
        { value: 'senior', label: 'מנהל חשבונות בכיר' }
      ];
    }
    return [];
  };
  
  const renderFileUploadBox = (filePreview, triggerFunction, title, description, formats) => (
    <div 
      className={`border-2 border-dashed rounded-md p-4 text-center cursor-pointer hover:bg-gray-50 transition-colors ${
        filePreview ? 'border-green-300 bg-green-50' : 'border-gray-300'
      }`}
      onClick={triggerFunction}
    >
      {filePreview ? (
        <div className="space-y-2">
          <div className="flex items-center justify-center">
            {filePreview.startsWith('data:image') ? (
              <img src={filePreview} alt="File Preview" className="max-h-32 max-w-full" />
            ) : (
              <div className="bg-green-100 text-green-700 p-2 rounded-full">
                <FileText className="h-6 w-6" />
              </div>
            )}
          </div>
          <p className="text-sm text-green-700">הקובץ הועלה בהצלחה. לחץ כאן להחלפת הקובץ.</p>
        </div>
      ) : (
        <div className="space-y-2">
          <div className="flex items-center justify-center">
            <Upload className="h-6 w-6 text-gray-400" />
          </div>
          <p className="text-sm">{title}</p>
          <p className="text-xs text-gray-500">{description}</p>
          <p className="text-xs text-gray-400">{formats}</p>
        </div>
      )}
    </div>
  );
  
  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto text-blue-600" />
          <p className="mt-2">טוען נתונים...</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="flex flex-col items-center justify-center py-10 px-4">
      <Card className="w-full max-w-2xl shadow-lg">
        <CardHeader className="pb-2">
          <div className="flex items-center mb-2">
            <CardTitle className="text-2xl font-bold">השלמת פרטי פרילנסר</CardTitle>
          </div>
          <CardDescription>
            אנא השלם את הפרטים הבאים כדי להשלים את תהליך ההרשמה
          </CardDescription>
        </CardHeader>
        
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-3 mx-6 my-4">
            <TabsTrigger value="personal">פרטים אישיים</TabsTrigger>
            <TabsTrigger value="professional">מידע מקצועי</TabsTrigger>
            <TabsTrigger value="terms">אישור תנאים</TabsTrigger>
          </TabsList>
          
          <form onSubmit={handleSubmit}>
            {successMessage && (
              <Alert className="mx-6 my-4 bg-green-50 border-green-200">
                <CheckCircle className="h-5 w-5 text-green-600" />
                <AlertDescription className="text-green-700">{successMessage}</AlertDescription>
              </Alert>
            )}
            
            {error && (
              <Alert variant="destructive" className="mx-6 my-4">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
            
            <TabsContent value="personal" className="mt-0">
              <CardContent className="space-y-6 pt-4">
                <div className="space-y-2">
                  <h3 className="text-lg font-medium flex items-center">
                    <UserCircle className="h-5 w-5 mr-2 rtl:ml-2 rtl:mr-0 text-blue-600" />
                    פרטים אישיים
                  </h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <Label htmlFor="phone_number">מספר טלפון נייד <span className="text-red-500">*</span></Label>
                      <Input
                        id="phone_number"
                        name="phone_number"
                        value={formState.phone_number}
                        onChange={handleInputChange}
                        placeholder="05X-XXXXXXX"
                      />
                    </div>
                    
                    <div className="space-y-1">
                      <Label htmlFor="id_card_number">מספר תעודת זהות <span className="text-red-500">*</span></Label>
                      <Input
                        id="id_card_number"
                        name="id_card_number"
                        value={formState.id_card_number}
                        onChange={handleInputChange}
                        placeholder="הזן מספר תעודת זהות"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <div className="space-y-1 col-span-2">
                      <Label htmlFor="address_street">כתובת</Label>
                      <Input
                        id="address_street"
                        name="address_street"
                        value={formState.address_street}
                        onChange={handleInputChange}
                        placeholder="רחוב ומספר"
                      />
                    </div>
                    
                    <div className="space-y-1">
                      <Label htmlFor="address_zip_code">מיקוד</Label>
                      <Input
                        id="address_zip_code"
                        name="address_zip_code"
                        value={formState.address_zip_code}
                        onChange={handleInputChange}
                        placeholder="מיקוד"
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-1">
                    <Label htmlFor="address_city">עיר</Label>
                    <Input
                      id="address_city"
                      name="address_city"
                      value={formState.address_city}
                      onChange={handleInputChange}
                      placeholder="עיר"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>צילום תעודת זהות <span className="text-red-500">*</span></Label>
                    <input
                      type="file"
                      ref={idCardFileInputRef}
                      onChange={handleIdCardFileChange}
                      accept="image/*,.pdf"
                      className="hidden"
                    />
                    
                    {renderFileUploadBox(
                      idCardPreview, 
                      triggerIdCardFileInput, 
                      "לחץ להעלאת צילום תעודת זהות",
                      "יש להעלות צילום ברור של תעודת הזהות כולל ספח",
                      "(פורמטים נתמכים: תמונה או PDF)"
                    )}
                  </div>
                </div>
              </CardContent>
            </TabsContent>
            
            <TabsContent value="professional" className="mt-0">
              <CardContent className="space-y-6 pt-4">
                <div className="space-y-4">
                  <h3 className="text-lg font-medium flex items-center">
                    <Calendar className="h-5 w-5 mr-2 rtl:ml-2 rtl:mr-0 text-blue-600" />
                    פרטי מקצוע וניסיון
                  </h3>
                  
                  <div className="space-y-2">
                    <Label>תחום מקצועי <span className="text-red-500">*</span></Label>
                    <RadioGroup 
                      value={formState.profession} 
                      onValueChange={(value) => handleRadioChange('profession', value)}
                      className="flex flex-col sm:flex-row gap-4"
                    >
                      <div className="flex items-center space-x-2 rtl:space-x-reverse">
                        <RadioGroupItem value="accountant" id="accountant" />
                        <Label htmlFor="accountant" className="cursor-pointer">מנהל חשבונות</Label>
                      </div>
                      <div className="flex items-center space-x-2 rtl:space-x-reverse">
                        <RadioGroupItem value="payroll_specialist" id="payroll_specialist" />
                        <Label htmlFor="payroll_specialist" className="cursor-pointer">חשב שכר</Label>
                      </div>
                      <div className="flex items-center space-x-2 rtl:space-x-reverse">
                        <RadioGroupItem value="bookkeeper" id="bookkeeper" />
                        <Label htmlFor="bookkeeper" className="cursor-pointer">הנהלת חשבונות</Label>
                      </div>
                    </RadioGroup>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <Label htmlFor="profession_level">דרגה מקצועית <span className="text-red-500">*</span></Label>
                      <Select 
                        value={formState.profession_level} 
                        onValueChange={(value) => handleSelectChange('profession_level', value)}
                      >
                        <SelectTrigger id="profession_level">
                          <SelectValue placeholder="בחר דרגה מקצועית" />
                        </SelectTrigger>
                        <SelectContent>
                          {getProfessionLevelOptions().map(option => (
                            <SelectItem key={option.value} value={option.value}>
                              {option.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-1">
                      <Label htmlFor="experience_years">שנות ניסיון <span className="text-red-500">*</span></Label>
                      <Select 
                        value={formState.experience_years} 
                        onValueChange={(value) => handleSelectChange('experience_years', value)}
                      >
                        <SelectTrigger id="experience_years">
                          <SelectValue placeholder="בחר שנות ניסיון" />
                        </SelectTrigger>
                        <SelectContent>
                          {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 15, 20].map(year => (
                            <SelectItem key={year} value={year.toString()}>
                              {year === 0 ? "פחות משנה" : `${year} שנים`}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label>תעודת מקצוע <span className="text-red-500">*</span></Label>
                    <input
                      type="file"
                      ref={certificateFileInputRef}
                      onChange={handleCertificateFileChange}
                      accept="image/*,.pdf"
                      className="hidden"
                    />
                    
                    {renderFileUploadBox(
                      certificatePreview, 
                      triggerCertificateFileInput, 
                      "לחץ להעלאת תעודת המקצוע",
                      "יש להעלות צילום תעודת מקצוע (הנה\"ח, חשבות שכר וכו')",
                      "(פורמטים נתמכים: תמונה או PDF)"
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label>תחומי התמחות <span className="text-red-500">*</span></Label>
                      <span className="text-xs text-gray-500">יש לבחור לפחות 3</span>
                    </div>
                    
                    <div className="flex flex-wrap gap-2">
                      {serviceCategories.map(category => {
                        const isSelected = formState.expertise_area_ids.includes(category.id);
                        return (
                          <Badge
                            key={category.id}
                            variant={isSelected ? "default" : "outline"}
                            className={`cursor-pointer ${isSelected ? "bg-blue-500 hover:bg-blue-600" : "hover:bg-blue-100"}`}
                            onClick={() => toggleExpertiseArea(category.id)}
                          >
                            {category.name}
                            {isSelected && (
                              <X className="h-3 w-3 ml-1 rtl:mr-1 rtl:ml-0" />
                            )}
                          </Badge>
                        );
                      })}
                    </div>
                    <p className="text-xs text-gray-500">
                      בחרת {formState.expertise_area_ids.length} תחומים {formState.expertise_area_ids.length < 3 && "(נדרש מינימום 3)"}
                    </p>
                  </div>
                </div>
              </CardContent>
            </TabsContent>
            
            <TabsContent value="terms" className="mt-0">
              <CardContent className="space-y-6 pt-4">
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <HelpCircle className="h-5 w-5 text-blue-600" />
                    <h3 className="text-lg font-medium">חשוב לדעת</h3>
                  </div>
                  
                  <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                    <p className="text-sm text-gray-700">
                      לאחר השלמת פרטיך, הפרופיל שלך יועבר לבדיקה על ידי מנהל המערכת.
                      תקבל התראה ברגע שהפרופיל יאושר, ורק לאחר מכן תוכל להגיש הצעות לפרויקטים.
                    </p>
                    <p className="text-sm text-gray-700 mt-2">
                      תהליך האישור בדרך כלל לוקח עד 48 שעות.
                    </p>
                  </div>
                  
                  <Separator />
                  
                  <div className="flex items-start space-x-2 rtl:space-x-reverse">
                    <Checkbox 
                      id="terms" 
                      checked={formState.is_terms_agreed}
                      onCheckedChange={(checked) => handleCheckboxChange('is_terms_agreed', checked)}
                    />
                    <div className="grid gap-1.5 leading-none">
                      <label
                        htmlFor="terms"
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        <span className="text-red-500 mr-1 rtl:ml-1 rtl:mr-0">*</span>
                        אני מסכים/ה ל
                        <Link to={createPageUrl('TermsOfService')} className="text-blue-600 hover:underline mx-1">תנאי השימוש</Link>
                        ול
                        <Link to={createPageUrl('PrivacyPolicy')} className="text-blue-600 hover:underline mx-1">מדיניות הפרטיות</Link>
                      </label>
                      <p className="text-sm text-gray-500">
                        אני מאשר/ת שכל המידע שמסרתי הוא אמיתי ומדויק
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </TabsContent>
            
            <CardFooter className="flex justify-between flex-col sm:flex-row gap-4 border-t pt-6">
              {activeTab !== 'personal' && (
                <Button 
                  type="button" 
                  variant="outline"
                  onClick={() => setActiveTab(activeTab === 'professional' ? 'personal' : 'professional')}
                >
                  הקודם
                </Button>
              )}
              
              <Button 
                type="submit" 
                className="ml-auto rtl:mr-auto rtl:ml-0 bg-blue-600 hover:bg-blue-700"
                disabled={isSubmitting}
              >
                {isSubmitting && <Loader2 className="mr-2 rtl:ml-2 rtl:mr-0 h-4 w-4 animate-spin" />}
                {activeTab === 'terms' ? 
                  (isSubmitting ? 'מעבד...' : 'שלח לאישור') : 
                  'הבא'
                }
              </Button>
            </CardFooter>
          </form>
        </Tabs>
      </Card>
    </div>
  );
}