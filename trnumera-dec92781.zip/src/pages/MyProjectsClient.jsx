import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { User } from '@/api/entities';
import { Project } from '@/api/entities';
import { Proposal } from '@/api/entities';
import { ServiceCategory } from '@/api/entities';
import { Briefcase, PlusCircle, Search, Clock, FileText, Loader2 } from 'lucide-react';

export default function MyProjectsClientPage() {
  const [user, setUser] = useState(null);
  const [projects, setProjects] = useState([]);
  const [categories, setCategories] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredProjects, setFilteredProjects] = useState([]);
  const [proposalCounts, setProposalCounts] = useState({});

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Get current user
        const currentUser = await User.me();
        setUser(currentUser);

        if (currentUser) {
          // Load projects created by this client
          const userProjects = await Project.filter({ client_id: currentUser.id });
          setProjects(userProjects);
          setFilteredProjects(userProjects);

          // Fetch service categories for reference
          const serviceCategories = await ServiceCategory.list();
          setCategories(serviceCategories);

          // For each project, count pending proposals
          const counts = {};
          for (const project of userProjects) {
            const projectProposals = await Proposal.filter({ project_id: project.id });
            const pendingCount = projectProposals.filter(
              p => ['submitted', 'viewed_by_client'].includes(p.status)
            ).length;
            counts[project.id] = pendingCount;
          }
          setProposalCounts(counts);
        }
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    if (searchTerm.trim() === '') {
      setFilteredProjects(projects);
    } else {
      const searchLower = searchTerm.toLowerCase();
      const filtered = projects.filter(project => 
        project.title.toLowerCase().includes(searchLower) || 
        project.description.toLowerCase().includes(searchLower)
      );
      setFilteredProjects(filtered);
    }
  }, [searchTerm, projects]);

  const filterProjectsByStatus = (status) => {
    if (status === 'all') {
      return filteredProjects;
    } else {
      return filteredProjects.filter(project => {
        if (status === 'open') {
          return project.status === 'open';
        } else if (status === 'active') {
          return project.status === 'in_progress';
        } else if (status === 'completed') {
          return ['completed', 'paid'].includes(project.status);
        } else {
          return ['cancelled_by_client', 'cancelled_by_freelancer', 'cancelled_by_admin'].includes(project.status);
        }
      });
    }
  };

  const getProjectStatusBadge = (status) => {
    switch (status) {
      case 'open':
        return <Badge className="bg-blue-100 text-blue-800">פתוח להצעות</Badge>;
      case 'in_progress':
        return <Badge className="bg-green-100 text-green-800">בתהליך</Badge>;
      case 'pending_payment':
        return <Badge className="bg-amber-100 text-amber-800">ממתין לתשלום</Badge>;
      case 'completed':
        return <Badge className="bg-purple-100 text-purple-800">הושלם</Badge>;
      case 'paid':
        return <Badge className="bg-emerald-100 text-emerald-800">שולם</Badge>;
      case 'cancelled_by_client':
      case 'cancelled_by_freelancer':
      case 'cancelled_by_admin':
        return <Badge variant="destructive">בוטל</Badge>;
      default:
        return null;
    }
  };

  const getCategoryNames = (categoryIds) => {
    if (!categoryIds || !categories.length) return [];
    return categoryIds.map(id => {
      const category = categories.find(c => c.id === id);
      return category ? category.name : '';
    }).filter(Boolean);
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-80">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto text-blue-600" />
          <p className="mt-2">טוען פרויקטים...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">הפרויקטים שלי</h1>
        <Button asChild>
          <Link to={createPageUrl('CreateProject')}>
            <PlusCircle className="ml-2 rtl:mr-2 rtl:ml-0 h-4 w-4" />
            פרויקט חדש
          </Link>
        </Button>
      </div>
      
      <div className="flex flex-col sm:flex-row gap-4 sm:items-center justify-between">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 rtl:right-2.5 rtl:left-auto top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="חפש פרויקטים לפי כותרת או תיאור"
            className="pl-8 rtl:pr-8 rtl:pl-4"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="sm:w-auto">
          <Badge variant="outline" className="text-sm px-2 py-1 bg-gray-100">
            סה"כ: {projects.length} פרויקטים
          </Badge>
        </div>
      </div>
      
      <Tabs defaultValue="all" className="w-full">
        <TabsList className="grid grid-cols-4 w-full">
          <TabsTrigger value="all">הכל</TabsTrigger>
          <TabsTrigger value="open">פתוחים</TabsTrigger>
          <TabsTrigger value="active">פעילים</TabsTrigger>
          <TabsTrigger value="completed">הושלמו</TabsTrigger>
        </TabsList>
        
        {['all', 'open', 'active', 'completed'].map(tab => (
          <TabsContent key={tab} value={tab} className="mt-6">
            {filterProjectsByStatus(tab).length > 0 ? (
              <div className="grid gap-4">
                {filterProjectsByStatus(tab).map(project => (
                  <Card key={project.id} className="overflow-hidden hover:shadow-md transition-shadow">
                    <div className="grid grid-cols-1 md:grid-cols-4">
                      <div className="md:col-span-3 p-6">
                        <div className="space-y-1">
                          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                            <h3 className="font-semibold text-lg">
                              <Link to={createPageUrl(`Project?id=${project.id}`)} className="hover:text-blue-600 transition-colors">
                                {project.title}
                              </Link>
                            </h3>
                            {getProjectStatusBadge(project.status)}
                          </div>
                          <div className="text-sm text-gray-500">
                            נוצר: {new Date(project.created_date).toLocaleDateString('he-IL')}
                          </div>
                          <p className="text-sm line-clamp-2 mt-2">
                            {project.description}
                          </p>
                          
                          <div className="flex flex-wrap gap-1.5 mt-3">
                            {getCategoryNames(project.service_category_ids).map((name, index) => (
                              <Badge key={index} variant="secondary" className="text-xs">
                                {name}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                      <div className="md:border-r rtl:md:border-l rtl:md:border-r-0 md:border-gray-100 bg-gray-50 p-4 flex flex-col justify-center items-center text-center space-y-3">
                        {project.status === 'open' && (
                          <>
                            <div className="text-amber-600">
                              <Clock className="h-5 w-5 mx-auto" />
                              <span className="block text-sm font-medium mt-1">הצעות ממתינות</span>
                              <span className="block text-xl font-bold">{proposalCounts[project.id] || 0}</span>
                            </div>
                            <Button size="sm" className="w-full" asChild>
                              <Link to={createPageUrl(`ProjectProposals?id=${project.id}`)}>
                                צפה בהצעות
                              </Link>
                            </Button>
                          </>
                        )}
                        
                        {project.status === 'in_progress' && (
                          <>
                            <div className="text-green-600">
                              <Briefcase className="h-5 w-5 mx-auto" />
                              <span className="block text-sm font-medium mt-1">בתהליך</span>
                              <span className="block text-sm">עם פרילנסר</span>
                            </div>
                            <Button size="sm" className="w-full" asChild>
                              <Link to={createPageUrl(`Project?id=${project.id}`)}>
                                צפה בפרויקט
                              </Link>
                            </Button>
                          </>
                        )}
                        
                        {['completed', 'paid'].includes(project.status) && (
                          <>
                            <div className="text-purple-600">
                              <FileText className="h-5 w-5 mx-auto" />
                              <span className="block text-sm font-medium mt-1">הושלם</span>
                              {project.status === 'paid' ? (
                                <span className="block text-sm">שולם</span>
                              ) : (
                                <span className="block text-sm">ממתין לתשלום</span>
                              )}
                            </div>
                            <Button size="sm" className="w-full" asChild>
                              <Link to={createPageUrl(`Project?id=${project.id}`)}>
                                צפה בסיכום
                              </Link>
                            </Button>
                          </>
                        )}
                        
                        {['cancelled_by_client', 'cancelled_by_freelancer', 'cancelled_by_admin'].includes(project.status) && (
                          <>
                            <div className="text-red-600">
                              <FileText className="h-5 w-5 mx-auto" />
                              <span className="block text-sm font-medium mt-1">בוטל</span>
                            </div>
                            <Button size="sm" variant="outline" className="w-full" asChild>
                              <Link to={createPageUrl(`Project?id=${project.id}`)}>
                                פרטים
                              </Link>
                            </Button>
                          </>
                        )}
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-16 bg-gray-50 rounded-lg">
                <div className="bg-gray-100 inline-flex rounded-full p-3 mb-4">
                  <Briefcase className="h-6 w-6 text-gray-500" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-1">אין פרויקטים {tab === 'all' ? '' : 'בקטגוריה זו'}</h3>
                <p className="text-gray-500 mb-4">
                  {tab === 'all' 
                    ? 'טרם יצרת פרויקטים. הגיע הזמן להתחיל!' 
                    : 'לא נמצאו פרויקטים העונים לקריטריונים.'
                  }
                </p>
                <Button asChild>
                  <Link to={createPageUrl('CreateProject')}>
                    <PlusCircle className="ml-2 rtl:mr-2 rtl:ml-0 h-4 w-4" />
                    צור פרויקט חדש
                  </Link>
                </Button>
              </div>
            )}
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}