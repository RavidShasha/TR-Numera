
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Link, useSearchParams, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { User } from '@/api/entities';
import { Project } from '@/api/entities';
import { Proposal } from '@/api/entities';
import { Review } from '@/api/entities'; // Import Review to calculate ratings
import { Alert, AlertDescription } from '@/components/ui/alert'; // Added Alert & AlertDescription
import { AlertCircle, Loader2, Star, MessageSquare, CheckCircle, XCircle, Eye } from 'lucide-react';

export default function ProjectProposalsPage() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const projectId = searchParams.get('id');

  const [currentUser, setCurrentUser] = useState(null);
  const [project, setProject] = useState(null);
  const [proposals, setProposals] = useState([]);
  const [freelancers, setFreelancers] = useState({}); // Store freelancer data by ID
  const [reviews, setReviews] = useState([]); // Store all reviews
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [actionLoading, setActionLoading] = useState({}); // For loading state of accept/reject buttons

  useEffect(() => {
    const fetchData = async () => {
      if (!projectId) {
        setError('מזהה פרויקט חסר.');
        setIsLoading(false);
        return;
      }
      try {
        const user = await User.me();
        setCurrentUser(user);

        const fetchedProject = await Project.get(projectId);
        setProject(fetchedProject);

        // Ensure only the project owner (client) can view proposals
        if (user.id !== fetchedProject.client_id) {
          setError('אין לך הרשאה לצפות בהצעות לפרויקט זה.');
          setIsLoading(false);
          return;
        }
        
        // Fetch all reviews once
        const allReviews = await Review.list();
        setReviews(allReviews);

        const projectProposals = await Proposal.filter({ project_id: projectId });
        setProposals(projectProposals.sort((a,b) => new Date(b.created_date) - new Date(a.created_date)));
        
        // Fetch details for each freelancer who submitted a proposal
        const freelancerIds = [...new Set(projectProposals.map(p => p.freelancer_id))];
        const freelancerData = {};
        for (const id of freelancerIds) {
          const freelancer = await User.get(id);
          freelancerData[id] = freelancer;
        }
        setFreelancers(freelancerData);

      } catch (err) {
        console.error('Error fetching data:', err);
        setError('אירעה שגיאה בטעינת ההצעות.');
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [projectId]);
  
  const getFreelancerAverageRating = (freelancerId) => {
    const freelancerReviews = reviews.filter(r => r.freelancer_id === freelancerId);
    if (freelancerReviews.length === 0) return 0;
    const sum = freelancerReviews.reduce((acc, review) => acc + review.rating, 0);
    return (sum / freelancerReviews.length).toFixed(1);
  };
  
  const getFreelancerReviewCount = (freelancerId) => {
    return reviews.filter(r => r.freelancer_id === freelancerId).length;
  };

  const handleProposalAction = async (proposalId, action) => {
    setActionLoading(prev => ({ ...prev, [proposalId]: true }));
    try {
      const proposal = proposals.find(p => p.id === proposalId);
      if (!proposal) throw new Error("הצעה לא נמצאה");

      if (action === 'accept') {
        // 1. Update proposal status to 'accepted'
        await Proposal.update(proposalId, { status: 'accepted' });
        
        // 2. Update project: set selected_freelancer_id and change status to 'in_progress'
        await Project.update(projectId, { 
          selected_freelancer_id: proposal.freelancer_id, 
          status: 'in_progress',
          freelancer_hired_date: new Date().toISOString()
        });
        
        // 3. (Optional) Reject other proposals for this project
        const otherProposals = proposals.filter(p => p.id !== proposalId && p.status !== 'rejected');
        for (const otherProp of otherProposals) {
          await Proposal.update(otherProp.id, { status: 'rejected' });
        }

        // Refresh data or navigate
        navigate(createPageUrl(`Project?id=${projectId}&proposalAccepted=true`));

      } else if (action === 'reject') {
        await Proposal.update(proposalId, { status: 'rejected' });
        // Refresh proposals list
        setProposals(prev => prev.map(p => p.id === proposalId ? {...p, status: 'rejected'} : p));
      }
    } catch (err) {
      console.error(`Error ${action}ing proposal:`, err);
      setError(`שגיאה ב${action === 'accept' ? 'אישור' : 'דחיית'} ההצעה.`);
    } finally {
      setActionLoading(prev => ({ ...prev, [proposalId]: false }));
    }
  };

  const markAsViewed = async (proposal) => {
    if (proposal.status === 'submitted') {
        try {
            await Proposal.update(proposal.id, { status: 'viewed_by_client' });
            setProposals(prev => prev.map(p => p.id === proposal.id ? {...p, status: 'viewed_by_client'} : p));
        } catch (err) {
            console.warn("Could not mark proposal as viewed:", err);
        }
    }
  };


  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-80">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto py-8 px-4 text-center">
        <Alert variant="destructive" className="max-w-md mx-auto">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
        <Button onClick={() => navigate(-1)} variant="outline" className="mt-4">חזור</Button>
      </div>
    );
  }
  
  const openProposals = proposals.filter(p => ['submitted', 'viewed_by_client'].includes(p.status));
  const otherProposals = proposals.filter(p => !['submitted', 'viewed_by_client'].includes(p.status));


  return (
    <div className="container mx-auto py-8 px-4">
      <div className="mb-6">
        <Button variant="outline" onClick={() => navigate(createPageUrl(`Project?id=${projectId}`))}>
          &rarr; חזור לפרויקט
        </Button>
      </div>
      
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-2xl font-bold">הצעות שהתקבלו עבור: {project?.title}</CardTitle>
          <CardDescription>
            סקור את ההצעות שהוגשו ובחר את הפרילנסר המתאים ביותר לפרויקט שלך.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {proposals.length === 0 ? (
            <div className="text-center py-12">
              <MessageSquare className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-xl text-gray-600">עדיין לא התקבלו הצעות לפרויקט זה.</p>
              <p className="text-gray-500 mt-2">בדוק שוב מאוחר יותר או שקול לשתף את הפרויקט.</p>
            </div>
          ) : (
            <div className="space-y-6">
              {project?.status === 'open' && openProposals.length > 0 && (
                <div>
                  <h3 className="text-xl font-semibold mb-4 border-b pb-2">הצעות חדשות/ממתינות ({openProposals.length})</h3>
                  {openProposals.map(proposal => {
                    const freelancer = freelancers[proposal.freelancer_id];
                    if (!freelancer) return null;
                    const avgRating = getFreelancerAverageRating(freelancer.id);
                    const reviewCount = getFreelancerReviewCount(freelancer.id);

                    return (
                      <Card key={proposal.id} className="mb-4 hover:shadow-md transition-shadow">
                        <CardContent className="p-4">
                          <div className="flex flex-col sm:flex-row gap-4">
                            <div className="flex-shrink-0 sm:w-1/4 flex flex-col items-center sm:items-start">
                              <Avatar className="w-16 h-16 mb-2">
                                <AvatarImage src={freelancer.photo_url || `https://avatar.vercel.sh/${freelancer.email}.png`} alt={freelancer.full_name} />
                                <AvatarFallback>{freelancer.full_name.substring(0,2).toUpperCase()}</AvatarFallback>
                              </Avatar>
                              <Link to={createPageUrl(`FreelancerProfile?id=${freelancer.id}`)} className="font-semibold text-blue-600 hover:underline text-center sm:text-right">
                                {freelancer.full_name}
                              </Link>
                              <div className="text-xs text-gray-500 mt-1 text-center sm:text-right">
                                {freelancer.freelancer_data?.profession === 'accountant' && 'מנהל/ת חשבונות'}
                                {freelancer.freelancer_data?.profession === 'payroll_specialist' && 'חשב/ת שכר'}
                                {freelancer.freelancer_data?.profession === 'bookkeeper' && 'הנהלת חשבונות'}
                              </div>
                              {reviewCount > 0 && (
                                <div className="flex items-center text-xs text-gray-500 mt-1">
                                  <Star className="h-3 w-3 text-yellow-400 fill-yellow-400 mr-1 rtl:ml-1 rtl:mr-0" />
                                  {avgRating} ({reviewCount} ביקורות)
                                </div>
                              )}
                            </div>
                            <div className="flex-grow">
                              <div className="flex justify-between items-start">
                                <h4 className="text-lg font-semibold">₪{proposal.proposed_amount.toLocaleString()}</h4>
                                <Badge variant={proposal.status === 'submitted' ? 'warning': 'info'}>
                                  {proposal.status === 'submitted' && 'הצעה חדשה'}
                                  {proposal.status === 'viewed_by_client' && 'הצעה נצפתה'}
                                </Badge>
                              </div>
                              {proposal.estimated_days_to_complete && (
                                <p className="text-sm text-gray-500">
                                  זמן מוערך לסיום: {proposal.estimated_days_to_complete} ימים
                                </p>
                              )}
                              <p className="mt-2 text-sm text-gray-700 whitespace-pre-wrap line-clamp-4">
                                {proposal.cover_letter}
                              </p>
                              <div className="mt-3 flex flex-wrap gap-2 items-center">
                                <Button size="sm" asChild onClick={() => markAsViewed(proposal)}>
                                  <Link to={createPageUrl(`Proposal?id=${proposal.id}`)}>
                                    <Eye className="h-4 w-4 mr-1 rtl:ml-1 rtl:mr-0" /> צפה בהצעה מלאה
                                  </Link>
                                </Button>
                                <Button 
                                  size="sm" 
                                  variant="success"
                                  onClick={() => handleProposalAction(proposal.id, 'accept')}
                                  disabled={actionLoading[proposal.id] || project?.status !== 'open'}
                                >
                                  {actionLoading[proposal.id] ? <Loader2 className="h-4 w-4 animate-spin"/> : <CheckCircle className="h-4 w-4 mr-1 rtl:ml-1 rtl:mr-0" />}
                                  קבל הצעה
                                </Button>
                                <Button 
                                  size="sm" 
                                  variant="destructiveOutline"
                                  onClick={() => handleProposalAction(proposal.id, 'reject')}
                                  disabled={actionLoading[proposal.id] || project?.status !== 'open'}
                                >
                                  {actionLoading[proposal.id] ? <Loader2 className="h-4 w-4 animate-spin"/> : <XCircle className="h-4 w-4 mr-1 rtl:ml-1 rtl:mr-0" />}
                                  דחה הצעה
                                </Button>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              )}

              {otherProposals.length > 0 && (
                 <div>
                  <h3 className="text-xl font-semibold mb-4 mt-8 border-b pb-2">הצעות קודמות ({otherProposals.length})</h3>
                    {otherProposals.map(proposal => {
                        const freelancer = freelancers[proposal.freelancer_id];
                        if (!freelancer) return null;
                        return (
                         <Card key={proposal.id} className="mb-4 opacity-70">
                            <CardContent className="p-4">
                            <div className="flex flex-col sm:flex-row gap-4">
                                <div className="flex-shrink-0 sm:w-1/4 flex flex-col items-center sm:items-start">
                                    <Avatar className="w-12 h-12 mb-1">
                                        <AvatarImage src={freelancer.photo_url || `https://avatar.vercel.sh/${freelancer.email}.png`} alt={freelancer.full_name} />
                                        <AvatarFallback>{freelancer.full_name.substring(0,2).toUpperCase()}</AvatarFallback>
                                    </Avatar>
                                    <p className="font-medium text-sm">{freelancer.full_name}</p>
                                </div>
                                <div className="flex-grow">
                                <div className="flex justify-between items-start">
                                    <h4 className="text-md font-semibold">₪{proposal.proposed_amount.toLocaleString()}</h4>
                                    <Badge variant={
                                        proposal.status === 'accepted' ? 'success' :
                                        proposal.status === 'rejected' ? 'destructive' :
                                        'secondary'
                                    }>
                                    {proposal.status === 'accepted' && 'התקבלה'}
                                    {proposal.status === 'rejected' && 'נדחתה'}
                                    {proposal.status === 'withdrawn_by_freelancer' && 'בוטלה ע"י פרילנסר'}
                                    </Badge>
                                </div>
                                <p className="mt-1 text-xs text-gray-600 whitespace-pre-wrap line-clamp-2">
                                    {proposal.cover_letter}
                                </p>
                                <Button size="xs" variant="outline" className="mt-2" asChild>
                                    <Link to={createPageUrl(`Proposal?id=${proposal.id}`)}>
                                        פרטים
                                    </Link>
                                </Button>
                                </div>
                            </div>
                            </CardContent>
                         </Card>
                        );
                    })}
                 </div>
              )}
              
              {project?.status !== 'open' && project?.selected_freelancer_id && (
                <Alert className="mt-6 bg-green-50 border-green-200">
                  <CheckCircle className="h-5 w-5 text-green-600"/>
                  <AlertDescription className="text-green-800">
                    פרויקט זה כבר בתהליך עם פרילנסר שנבחר. לא ניתן לקבל או לדחות הצעות נוספות.
                  </AlertDescription>
                </Alert>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
