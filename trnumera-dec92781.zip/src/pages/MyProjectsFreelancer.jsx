import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { User } from '@/api/entities';
import { Project } from '@/api/entities';
import { Proposal } from '@/api/entities'; // To potentially link to original proposal
import { ServiceCategory } from '@/api/entities';
import { Briefcase, Search, Clock, FileText, Loader2, CheckCircle } from 'lucide-react';

export default function MyProjectsFreelancerPage() {
  const [user, setUser] = useState(null);
  const [projects, setProjects] = useState([]); // Projects assigned to this freelancer
  const [categories, setCategories] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredProjects, setFilteredProjects] = useState([]);
  const [clientsData, setClientsData] = useState({}); // Store client data by ID

  useEffect(() => {
    const fetchData = async () => {
      try {
        const currentUser = await User.me();
        setUser(currentUser);

        if (currentUser && currentUser.role === 'freelancer') {
          // Load projects where this freelancer was selected
          const userProjects = await Project.filter({ selected_freelancer_id: currentUser.id });
          setProjects(userProjects);
          setFilteredProjects(userProjects);

          // Fetch service categories for reference
          const serviceCategories = await ServiceCategory.list();
          setCategories(serviceCategories);

          // Fetch client data for these projects
          if (userProjects.length > 0) {
            const clientIds = [...new Set(userProjects.map(p => p.client_id))];
            const clients = {};
            for (const clientId of clientIds) {
              const clientInfo = await User.get(clientId).catch(() => null);
              if (clientInfo) {
                clients[clientId] = clientInfo;
              }
            }
            setClientsData(clients);
          }
        }
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    if (searchTerm.trim() === '') {
      setFilteredProjects(projects);
    } else {
      const searchLower = searchTerm.toLowerCase();
      const filtered = projects.filter(project => 
        project.title.toLowerCase().includes(searchLower) || 
        project.description.toLowerCase().includes(searchLower) ||
        (clientsData[project.client_id]?.full_name.toLowerCase().includes(searchLower))
      );
      setFilteredProjects(filtered);
    }
  }, [searchTerm, projects, clientsData]);

  const filterProjectsByStatus = (status) => {
    if (status === 'all') {
      return filteredProjects;
    }
    return filteredProjects.filter(project => {
      if (status === 'active') return project.status === 'in_progress';
      if (status === 'pending_payment') return project.status === 'pending_payment';
      if (status === 'completed') return ['completed', 'paid'].includes(project.status);
      if (status === 'cancelled') return ['cancelled_by_client', 'cancelled_by_freelancer', 'cancelled_by_admin'].includes(project.status);
      return false;
    });
  };

  const getProjectStatusBadge = (status) => {
    switch (status) {
      case 'in_progress':
        return <Badge className="bg-green-100 text-green-800">בתהליך</Badge>;
      case 'pending_payment':
        return <Badge className="bg-amber-100 text-amber-800">ממתין לתשלום</Badge>;
      case 'completed':
        return <Badge className="bg-purple-100 text-purple-800">הושלם</Badge>;
      case 'paid':
        return <Badge className="bg-emerald-100 text-emerald-800">שולם</Badge>;
      case 'cancelled_by_client':
      case 'cancelled_by_freelancer':
      case 'cancelled_by_admin':
        return <Badge variant="destructive">בוטל</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getCategoryNames = (categoryIds) => {
    if (!categoryIds || !categories.length) return [];
    return categoryIds.map(id => {
      const category = categories.find(c => c.id === id);
      return category ? category.name : '';
    }).filter(Boolean);
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-80">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto text-blue-600" />
          <p className="mt-2">טוען פרויקטים...</p>
        </div>
      </div>
    );
  }

  if (!user || user.role !== 'freelancer') {
    return (
      <div className="text-center py-10">
        <p>דף זה זמין לפרילנסרים בלבד.</p>
      </div>
    );
  }
  
  const tabs = [
    { value: 'all', label: 'הכל' },
    { value: 'active', label: 'פעילים' },
    { value: 'pending_payment', label: 'ממתינים לתשלום' },
    { value: 'completed', label: 'הושלמו' },
    { value: 'cancelled', label: 'בוטלו' }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">הפרויקטים שלי</h1>
        {/* Future: Maybe a button to "Request Project Update" or similar */}
      </div>
      
      <div className="flex flex-col sm:flex-row gap-4 sm:items-center justify-between">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 rtl:right-2.5 rtl:left-auto top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="חפש פרויקטים לפי כותרת, תיאור או שם לקוח"
            className="pl-8 rtl:pr-8 rtl:pl-4"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="sm:w-auto">
          <Badge variant="outline" className="text-sm px-2 py-1 bg-gray-100">
            סה"כ: {projects.length} פרויקטים
          </Badge>
        </div>
      </div>
      
      <Tabs defaultValue="active" className="w-full">
        <TabsList className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 w-full">
          {tabs.map(tab => (
            <TabsTrigger key={tab.value} value={tab.value}>{tab.label}</TabsTrigger>
          ))}
        </TabsList>
        
        {tabs.map(tabInfo => (
          <TabsContent key={tabInfo.value} value={tabInfo.value} className="mt-6">
            {filterProjectsByStatus(tabInfo.value).length > 0 ? (
              <div className="grid gap-4">
                {filterProjectsByStatus(tabInfo.value).map(project => (
                  <Card key={project.id} className="overflow-hidden hover:shadow-md transition-shadow">
                    <div className="grid grid-cols-1 md:grid-cols-4">
                      <div className="md:col-span-3 p-6">
                        <div className="space-y-1">
                          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                            <h3 className="font-semibold text-lg">
                              <Link to={createPageUrl(`Project?id=${project.id}`)} className="hover:text-blue-600 transition-colors">
                                {project.title}
                              </Link>
                            </h3>
                            {getProjectStatusBadge(project.status)}
                          </div>
                          <div className="text-sm text-gray-500">
                            לקוח: {clientsData[project.client_id]?.full_name || 'לא ידוע'}
                          </div>
                          <div className="text-sm text-gray-500">
                            נשכרת בתאריך: {project.freelancer_hired_date ? new Date(project.freelancer_hired_date).toLocaleDateString('he-IL') : 'לא צוין'}
                          </div>
                          <p className="text-sm line-clamp-2 mt-2">
                            {project.description}
                          </p>
                          
                          <div className="flex flex-wrap gap-1.5 mt-3">
                            {getCategoryNames(project.service_category_ids).map((name, index) => (
                              <Badge key={index} variant="secondary" className="text-xs">
                                {name}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                      <div className="md:border-r rtl:md:border-l rtl:md:border-r-0 md:border-gray-100 bg-gray-50 p-4 flex flex-col justify-center items-center text-center space-y-3">
                         <div className="text-sm">
                           <span className="font-medium">תקציב מוסכם:</span><br/>
                           {project.budget_max ? `עד ₪${project.budget_max.toLocaleString()}` : 'לא הוגדר'}
                         </div>
                        <Button size="sm" className="w-full" asChild>
                          <Link to={createPageUrl(`Project?id=${project.id}`)}>
                            צפה בפרטי הפרויקט
                          </Link>
                        </Button>
                        <Button size="sm" variant="outline" className="w-full" asChild>
                            <Link to={createPageUrl(`ProjectChat?project_id=${project.id}&participant_id=${project.client_id}`)}>
                                צ'אט עם הלקוח
                            </Link>
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-16 bg-gray-50 rounded-lg">
                <div className="bg-gray-100 inline-flex rounded-full p-3 mb-4">
                  <Briefcase className="h-6 w-6 text-gray-500" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-1">אין פרויקטים בקטגוריה זו</h3>
                <p className="text-gray-500 mb-4">
                  לא נמצאו פרויקטים העונים לקריטריונים.
                </p>
                {tabInfo.value === 'active' && (
                   <Button asChild>
                     <Link to={createPageUrl('SearchProjects')}>
                       <Search className="ml-2 rtl:mr-2 rtl:ml-0 h-4 w-4" />
                       חפש פרויקטים חדשים
                     </Link>
                   </Button>
                )}
              </div>
            )}
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}