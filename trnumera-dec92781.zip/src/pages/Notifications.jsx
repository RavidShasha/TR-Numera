import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { Notification } from '@/api/entities';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, BellRing, BellOff, CheckCheck, Eye, Trash2 } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { he } from 'date-fns/locale'; // Import Hebrew locale for date-fns

export default function NotificationsPage() {
  const [user, setUser] = useState(null);
  const [notifications, setNotifications] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [filter, setFilter] = useState('all'); // 'all', 'unread'

  useEffect(() => {
    const fetchUserAndNotifications = async () => {
      setIsLoading(true);
      try {
        const currentUser = await User.me();
        setUser(currentUser);
        if (currentUser) {
          const userNotifications = await Notification.filter(
            { user_id: currentUser.id },
            '-created_date', // Sort by newest first
            100 // Limit to 100 notifications for performance
          );
          setNotifications(userNotifications);
        }
      } catch (error) {
        console.error("Error fetching notifications:", error);
        // Handle error (e.g., show error message to user)
      } finally {
        setIsLoading(false);
      }
    };
    fetchUserAndNotifications();
  }, []);

  const markAsRead = async (notificationId) => {
    try {
      await Notification.update(notificationId, { is_read: true, read_at: new Date().toISOString() });
      setNotifications(prevNotifications =>
        prevNotifications.map(n =>
          n.id === notificationId ? { ...n, is_read: true, read_at: new Date().toISOString() } : n
        )
      );
    } catch (error) {
      console.error("Error marking notification as read:", error);
    }
  };
  
  const markAllAsRead = async () => {
    if (!user) return;
    try {
        // The SDK might not support bulk update directly. 
        // We'll iterate, but for many notifications this could be slow.
        // A backend function for bulk update would be better for production.
        const unreadNotifications = notifications.filter(n => !n.is_read);
        for (const notification of unreadNotifications) {
            await Notification.update(notification.id, { is_read: true, read_at: new Date().toISOString() });
        }
        // Refetch or update state locally
        const updatedNotifications = await Notification.filter({ user_id: user.id },'-created_date', 100);
        setNotifications(updatedNotifications);
    } catch (error) {
        console.error("Error marking all notifications as read:", error);
    }
  };

  const deleteNotification = async (notificationId) => {
    try {
      await Notification.delete(notificationId);
      setNotifications(prevNotifications =>
        prevNotifications.filter(n => n.id !== notificationId)
      );
    } catch (error) {
      console.error("Error deleting notification:", error);
    }
  };
  
  const deleteAllReadNotifications = async () => {
    if(!user) return;
    try {
        const readNotifications = notifications.filter(n => n.is_read);
        for (const notification of readNotifications) {
            await Notification.delete(notification.id);
        }
        const remainingNotifications = await Notification.filter({ user_id: user.id },'-created_date', 100);
        setNotifications(remainingNotifications);
    } catch (error) {
        console.error("Error deleting all read notifications:", error);
    }
  };

  const getNotificationLink = (notification) => {
    // This function would generate the correct link based on notification type and related entity
    // Example:
    if (notification.type === 'new_proposal' && notification.related_entity_id) {
      // Assuming related_entity_id is proposal_id for new_proposal
      // And we need project_id to link to ProjectProposals or Proposal page
      // This part needs more thought based on what related_entity_id stores
      // For now, a placeholder or link to a generic page.
      // If related_entity_type is 'Proposal', then related_entity_id is proposal_id.
      // To link to the proposal, we might need ProjectProposals?id=PROJECT_ID or Proposal?id=PROPOSAL_ID
      // This requires the Notification entity to possibly store project_id too if type is proposal-related.
      // Let's assume related_entity_type and related_entity_id provide enough info.
      
      if (notification.related_entity_type === 'Proposal' && notification.related_entity_id) {
         return createPageUrl(`Proposal?id=${notification.related_entity_id}`);
      }
      if (notification.related_entity_type === 'Project' && notification.related_entity_id) {
         return createPageUrl(`Project?id=${notification.related_entity_id}`);
      }
      if (notification.related_entity_type === 'Message' && notification.related_entity_id){
         // For messages, related_entity_id might be project_id.
         // This is a simplification. Actual chat link might need sender/receiver.
         return createPageUrl(`ProjectChat?project_id=${notification.related_entity_id}`);
      }
    }
    if (notification.type === 'profile_update_status' || notification.type === 'new_review') {
        return createPageUrl('ProfileSettings');
    }
    return '#'; // Default or no link
  };

  const filteredNotifications = notifications.filter(n => 
    filter === 'all' || (filter === 'unread' && !n.is_read)
  );

  if (isLoading && !user) { // Show loader only if user data hasn't loaded yet.
    return (
      <div className="flex justify-center items-center h-screen">
        <Loader2 className="h-12 w-12 animate-spin text-blue-600" />
      </div>
    );
  }
  
  if (!user) {
    return (
      <div className="text-center py-10">
        <p>עליך להתחבר כדי לצפות בהתראות.</p>
        <Button asChild className="mt-4">
          <Link to={createPageUrl('Login')}>התחבר</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 px-2 sm:px-4">
      <Card className="max-w-3xl mx-auto">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-2xl flex items-center">
            <BellRing className="h-6 w-6 mr-2 rtl:ml-2 rtl:mr-0 text-blue-600" />
            התראות
          </CardTitle>
          <div className="flex gap-2">
            <Button variant={filter === 'all' ? 'default' : 'outline'} size="sm" onClick={() => setFilter('all')}>הכל</Button>
            <Button variant={filter === 'unread' ? 'default' : 'outline'} size="sm" onClick={() => setFilter('unread')}>
              לא נקראו 
              <Badge className="mr-1 rtl:ml-1 rtl:mr-0 bg-red-500 text-white px-1.5 py-0 text-xs">
                {notifications.filter(n => !n.is_read).length}
              </Badge>
            </Button>
          </div>
        </CardHeader>
        <CardContent className="pt-0">
          {notifications.filter(n => !n.is_read).length > 0 && (
            <div className="mb-4 flex flex-col sm:flex-row gap-2 justify-end">
                <Button variant="outline" size="sm" onClick={markAllAsRead}>
                    <CheckCheck className="h-4 w-4 mr-1 rtl:ml-1 rtl:mr-0"/> סמן הכל כנקרא
                </Button>
            </div>
          )}
          {notifications.filter(n => n.is_read).length > 0 && (
             <div className="mb-4 flex flex-col sm:flex-row gap-2 justify-end">
                <Button variant="outline" size="sm" onClick={deleteAllReadNotifications} className="text-red-600 border-red-300 hover:bg-red-50 hover:text-red-700">
                    <Trash2 className="h-4 w-4 mr-1 rtl:ml-1 rtl:mr-0"/> מחק התראות שנקראו
                </Button>
            </div>
          )}

          {isLoading && notifications.length === 0 ? (
             <div className="text-center py-10">
                <Loader2 className="h-8 w-8 animate-spin text-blue-500 mx-auto" />
                <p className="mt-2 text-gray-500">טוען התראות...</p>
             </div>
          ) : filteredNotifications.length === 0 ? (
            <div className="text-center py-16 bg-gray-50 rounded-lg">
              <BellOff className="h-12 w-12 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-1">אין התראות חדשות</h3>
              <p className="text-gray-500">
                {filter === 'unread' ? 'כל ההתראות שלך נקראו.' : 'אין לך התראות כרגע.'}
              </p>
            </div>
          ) : (
            <ul className="space-y-3">
              {filteredNotifications.map(notification => (
                <li 
                  key={notification.id} 
                  className={`p-4 rounded-lg border transition-colors flex items-start justify-between gap-3
                    ${notification.is_read ? 'bg-white border-gray-200' : 'bg-blue-50 border-blue-200 shadow-sm'}`
                  }
                >
                  <div className="flex-grow">
                    <div className="flex items-center justify-between mb-1">
                      <h4 className={`font-semibold ${notification.is_read ? 'text-gray-700' : 'text-blue-700'}`}>
                        {notification.title}
                      </h4>
                      <span className="text-xs text-gray-400">
                        {formatDistanceToNow(new Date(notification.created_date), { addSuffix: true, locale: he })}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">{notification.message}</p>
                    {getNotificationLink(notification) !== '#' && (
                        <Link to={getNotificationLink(notification)} className="text-xs text-blue-600 hover:underline">
                            צפה בפרטים
                        </Link>
                    )}
                  </div>
                  <div className="flex flex-col items-end gap-1.5">
                    {!notification.is_read && (
                      <Button variant="ghost" size="sm" onClick={() => markAsRead(notification.id)} className="text-blue-600 hover:text-blue-700 px-2 py-1 h-auto">
                        <Eye className="h-3.5 w-3.5 mr-1 rtl:ml-1 rtl:mr-0" /> סמן כנקרא
                      </Button>
                    )}
                    <Button variant="ghost" size="icon" onClick={() => deleteNotification(notification.id)} className="text-gray-400 hover:text-red-500 h-7 w-7">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
}