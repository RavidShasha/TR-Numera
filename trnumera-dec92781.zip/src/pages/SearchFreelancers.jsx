
import React, { useState, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card'; // Added CardFooter
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { User } from '@/api/entities';
import { ServiceCategory } from '@/api/entities';
import { Review } from '@/api/entities';
import { Users, Search, Filter, Star, Loader2, MessageSquare } from 'lucide-react';

export default function SearchFreelancersPage() {
  const [freelancers, setFreelancers] = useState([]);
  const [categories, setCategories] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [minRating, setMinRating] = useState(0);
  const [minExperience, setMinExperience] = useState('');
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch all approved freelancers, categories, and reviews
        const [allFreelancers, allCategories, allReviews] = await Promise.all([
          User.filter({ role: 'freelancer', 'freelancer_data.is_approved': true }),
          ServiceCategory.list(),
          Review.list() 
        ]);
        
        setFreelancers(allFreelancers);
        setCategories(allCategories);
        setReviews(allReviews);
        
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  const getFreelancerCategories = (freelancer) => {
    if (!freelancer.freelancer_data?.expertise_area_ids || !categories.length) return [];
    return freelancer.freelancer_data.expertise_area_ids.map(id => {
      const category = categories.find(c => c.id === id);
      return category ? category.name : '';
    }).filter(Boolean);
  };

  const getFreelancerAverageRating = (freelancerId) => {
    const freelancerReviews = reviews.filter(r => r.freelancer_id === freelancerId);
    if (freelancerReviews.length === 0) return 0;
    const sum = freelancerReviews.reduce((acc, review) => acc + review.rating, 0);
    return (sum / freelancerReviews.length).toFixed(1);
  };
  
  const getFreelancerReviewCount = (freelancerId) => {
    return reviews.filter(r => r.freelancer_id === freelancerId).length;
  };

  const handleCategoryChange = (categoryId) => {
    setSelectedCategories(prev => 
      prev.includes(categoryId) 
        ? prev.filter(id => id !== categoryId)
        : [...prev, categoryId]
    );
  };

  const filteredFreelancers = freelancers.filter(freelancer => {
    const nameMatch = freelancer.full_name.toLowerCase().includes(searchTerm.toLowerCase());
    // TODO: Add search by profession/description when these fields are available on freelancer_data
    // const professionMatch = freelancer.freelancer_data?.profession?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const categoryMatch = selectedCategories.length === 0 || 
                          (freelancer.freelancer_data?.expertise_area_ids && 
                           freelancer.freelancer_data.expertise_area_ids.some(id => selectedCategories.includes(id)));
    
    const rating = parseFloat(getFreelancerAverageRating(freelancer.id));
    const ratingMatch = rating >= minRating;
    
    const experienceMatch = minExperience === '' || 
                            (freelancer.freelancer_data?.experience_years && 
                             freelancer.freelancer_data.experience_years >= parseInt(minExperience));
    
    return (nameMatch) && categoryMatch && ratingMatch && experienceMatch;
  });

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-80">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto text-blue-600" />
          <p className="mt-2">טוען פרילנסרים...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 px-4 sm:px-6 lg:px-8">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-center text-gray-800">מצא פרילנסרים</h1>
        <p className="text-center text-gray-600 mt-2">
          חפש והשווה בין מנהלי חשבונות וחשבי שכר מומלצים
        </p>
      </header>

      <div className="flex flex-col md:flex-row gap-6">
        {/* Filters Section */}
        <aside className={`md:w-1/4 ${showFilters ? 'block' : 'hidden'} md:block`}>
          <Card className="sticky top-24">
            <CardHeader>
              <CardTitle className="text-lg flex items-center">
                <Filter className="h-5 w-5 mr-2 rtl:ml-2 rtl:mr-0 text-blue-600" />
                סנן תוצאות
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <Label className="font-semibold">תחומי התמחות</Label>
                <div className="mt-2 space-y-2 max-h-60 overflow-y-auto">
                  {categories.map(category => (
                    <div key={category.id} className="flex items-center">
                      <Checkbox 
                        id={`cat-freelancer-${category.id}`}
                        checked={selectedCategories.includes(category.id)}
                        onCheckedChange={() => handleCategoryChange(category.id)}
                      />
                      <Label htmlFor={`cat-freelancer-${category.id}`} className="ml-2 rtl:mr-2 rtl:ml-0 cursor-pointer">
                        {category.name}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <Label htmlFor="minRating" className="font-semibold">דירוג מינימלי</Label>
                <Select value={minRating.toString()} onValueChange={(val) => setMinRating(parseFloat(val))}>
                  <SelectTrigger id="minRating">
                    <SelectValue placeholder="ללא הגבלה" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0">ללא הגבלה</SelectItem>
                    <SelectItem value="1">1 כוכב ומעלה</SelectItem>
                    <SelectItem value="2">2 כוכבים ומעלה</SelectItem>
                    <SelectItem value="3">3 כוכבים ומעלה</SelectItem>
                    <SelectItem value="4">4 כוכבים ומעלה</SelectItem>
                    <SelectItem value="5">5 כוכבים</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="minExperience" className="font-semibold">שנות ניסיון (מינימום)</Label>
                <Select value={minExperience} onValueChange={setMinExperience}>
                  <SelectTrigger id="minExperience">
                    <SelectValue placeholder="ללא הגבלה" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={null}>ללא הגבלה</SelectItem>
                    <SelectItem value="1">שנה אחת</SelectItem>
                    <SelectItem value="3">3 שנים</SelectItem>
                    <SelectItem value="5">5 שנים</SelectItem>
                    <SelectItem value="10">10 שנים</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </aside>

        {/* Freelancers List Section */}
        <main className="md:w-3/4">
          <div className="mb-6 flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 rtl:right-2.5 rtl:left-auto top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="חפש לפי שם, מקצוע..."
                className="pl-8 rtl:pr-8 rtl:pl-4"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
             <Button 
              variant="outline" 
              className="md:hidden"
              onClick={() => setShowFilters(!showFilters)}
            >
              <Filter className="h-4 w-4 mr-2 rtl:ml-2 rtl:mr-0" />
              {showFilters ? 'הסתר מסננים' : 'הצג מסננים'}
            </Button>
            <div className="text-sm text-gray-500 sm:text-right">
              נמצאו {filteredFreelancers.length} פרילנסרים
            </div>
          </div>

          {filteredFreelancers.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredFreelancers.map(freelancer => (
                <Card key={freelancer.id} className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-5 text-center">
                    <Avatar className="w-20 h-20 mx-auto mb-3 border-2 border-blue-200">
                      <AvatarImage src={freelancer.photo_url || `https://avatar.vercel.sh/${freelancer.email}.png`} alt={freelancer.full_name} />
                      <AvatarFallback>{freelancer.full_name.substring(0, 2).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <h3 className="text-lg font-semibold text-blue-700">{freelancer.full_name}</h3>
                    <p className="text-sm text-gray-500 mb-1">
                       {freelancer.freelancer_data?.profession === 'accountant' && 'מנהל/ת חשבונות'}
                       {freelancer.freelancer_data?.profession === 'payroll_specialist' && 'חשב/ת שכר'}
                       {freelancer.freelancer_data?.profession === 'bookkeeper' && 'הנהלת חשבונות'}
                    </p>
                     <div className="flex items-center justify-center mb-2 text-sm">
                      <Star className="h-4 w-4 text-yellow-400 fill-yellow-400 mr-1 rtl:ml-1 rtl:mr-0" />
                      {getFreelancerAverageRating(freelancer.id)} 
                      <span className="text-gray-400 ml-1 rtl:mr-1 rtl:ml-0">({getFreelancerReviewCount(freelancer.id)} ביקורות)</span>
                    </div>
                    <div className="flex flex-wrap justify-center gap-1 mb-3">
                      {getFreelancerCategories(freelancer).slice(0,3).map((catName, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">{catName}</Badge>
                      ))}
                      {getFreelancerCategories(freelancer).length > 3 && <Badge variant="secondary" className="text-xs">...</Badge>}
                    </div>
                     <p className="text-xs text-gray-500 mb-3">
                      ניסיון: {freelancer.freelancer_data?.experience_years || 'לא צוין'} שנים
                    </p>
                  </CardContent>
                  <CardFooter className="p-3 bg-gray-50 border-t">
                     {/* Placeholder for Link to full profile page */}
                     <Button size="sm" className="w-full" variant="outline" asChild>
                      <Link to={createPageUrl(`FreelancerProfile?id=${freelancer.id}`)}>
                        צפה בפרופיל
                      </Link>
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-16 bg-gray-50 rounded-lg">
              <div className="bg-gray-100 inline-flex rounded-full p-4 mb-4">
                 <Users className="h-8 w-8 text-gray-400" />
              </div>
              <h3 className="text-xl font-medium text-gray-900 mb-2">לא נמצאו פרילנסרים</h3>
              <p className="text-gray-500">נסה לשנות את תנאי החיפוש או הרחב את מעגל החיפוש שלך.</p>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
