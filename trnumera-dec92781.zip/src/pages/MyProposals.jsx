import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { User } from '@/api/entities';
import { Project } from '@/api/entities';
import { Proposal } from '@/api/entities';
import { FileText, Search, Eye, Check, X, Loader2, Briefcase } from 'lucide-react';

export default function MyProposalsPage() {
  const [user, setUser] = useState(null);
  const [proposals, setProposals] = useState([]);
  const [projects, setProjects] = useState({}); // Store project data by ID
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredProposals, setFilteredProposals] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const currentUser = await User.me();
        setUser(currentUser);

        if (currentUser && currentUser.role === 'freelancer') {
          const userProposals = await Proposal.filter({ freelancer_id: currentUser.id });
          setProposals(userProposals.sort((a,b) => new Date(b.created_date) - new Date(a.created_date)));
          setFilteredProposals(userProposals);

          // Fetch details for each project linked to the proposals
          const projectIds = [...new Set(userProposals.map(p => p.project_id))];
          const projectData = {};
          for (const id of projectIds) {
            try {
              const project = await Project.get(id);
              projectData[id] = project;
            } catch (projectError) {
                console.warn(`Could not fetch project with ID ${id}: `, projectError);
                projectData[id] = { title: 'פרויקט לא זמין', id: id }; // Placeholder
            }
          }
          setProjects(projectData);
        } else {
            // Handle case where user is not a freelancer or not logged in
            setIsLoading(false);
            return;
        }
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    if (searchTerm.trim() === '') {
      setFilteredProposals(proposals);
    } else {
      const searchLower = searchTerm.toLowerCase();
      const filtered = proposals.filter(proposal => {
        const project = projects[proposal.project_id];
        const projectTitleMatch = project?.title?.toLowerCase().includes(searchLower);
        const coverLetterMatch = proposal.cover_letter.toLowerCase().includes(searchLower);
        return projectTitleMatch || coverLetterMatch;
      });
      setFilteredProposals(filtered);
    }
  }, [searchTerm, proposals, projects]);

  const filterProposalsByStatus = (statusTab) => {
    if (statusTab === 'all') {
      return filteredProposals;
    }
    if (statusTab === 'pending') {
      return filteredProposals.filter(p => ['submitted', 'viewed_by_client'].includes(p.status));
    }
    if (statusTab === 'active') { // 'active' means proposal accepted AND project is in_progress
      return filteredProposals.filter(p => {
        const project = projects[p.project_id];
        return p.status === 'accepted' && project?.status === 'in_progress';
      });
    }
    if (statusTab === 'archived') {
      return filteredProposals.filter(p => ['rejected', 'withdrawn_by_freelancer'].includes(p.status) || (p.status === 'accepted' && projects[p.project_id]?.status !== 'in_progress'));
    }
    return [];
  };

  const getStatusBadge = (proposalStatus, projectStatus) => {
    if (proposalStatus === 'submitted') return <Badge variant="warning">הוגשה</Badge>;
    if (proposalStatus === 'viewed_by_client') return <Badge variant="info">נצפתה ע"י לקוח</Badge>;
    if (proposalStatus === 'accepted') {
        if (projectStatus === 'in_progress') return <Badge variant="success"><Check className="h-3 w-3 mr-1 rtl:ml-1 rtl:mr-0"/>התקבלה (פרויקט פעיל)</Badge>;
        if (['completed', 'paid'].includes(projectStatus)) return <Badge className="bg-purple-100 text-purple-800"><Check className="h-3 w-3 mr-1 rtl:ml-1 rtl:mr-0"/>הושלם (פרויקט)</Badge>;
        return <Badge variant="successOutline"><Check className="h-3 w-3 mr-1 rtl:ml-1 rtl:mr-0"/>התקבלה</Badge>;
    }
    if (proposalStatus === 'rejected') return <Badge variant="destructive"><X className="h-3 w-3 mr-1 rtl:ml-1 rtl:mr-0"/>נדחתה</Badge>;
    if (proposalStatus === 'withdrawn_by_freelancer') return <Badge variant="secondary">בוטלה</Badge>;
    return <Badge variant="outline">{proposalStatus}</Badge>;
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-80">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
        <p className="mt-2 mr-2 rtl:ml-2 rtl:mr-0">טוען הצעות...</p>
      </div>
    );
  }
  
  if (!user || user.role !== 'freelancer') {
    return (
        <div className="container mx-auto py-8 px-4 text-center">
            <p>עליך להיות מחובר כפרילנסר כדי לצפות בהצעות שלך.</p>
            <Button asChild className="mt-4"><Link to={createPageUrl('Login')}>התחבר</Link></Button>
        </div>
    );
  }

  return (
    <div className="container mx-auto py-8 px-4 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">ההצעות שלי</h1>
        <Button asChild>
          <Link to={createPageUrl('SearchProjects')}>
            <Search className="ml-2 rtl:mr-2 rtl:ml-0 h-4 w-4" />
            חפש פרויקטים חדשים
          </Link>
        </Button>
      </div>
      
      <div className="flex flex-col sm:flex-row gap-4 sm:items-center justify-between">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 rtl:right-2.5 rtl:left-auto top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="חפש הצעה לפי כותרת פרויקט או תוכן..."
            className="pl-8 rtl:pr-8 rtl:pl-4"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="sm:w-auto">
          <Badge variant="outline" className="text-sm px-2 py-1 bg-gray-100">
            סה"כ: {proposals.length} הצעות
          </Badge>
        </div>
      </div>
      
      <Tabs defaultValue="all" className="w-full">
        <TabsList className="grid grid-cols-2 sm:grid-cols-4 w-full">
          <TabsTrigger value="all">הכל</TabsTrigger>
          <TabsTrigger value="pending">ממתינות</TabsTrigger>
          <TabsTrigger value="active">פעילות</TabsTrigger>
          <TabsTrigger value="archived">ארכיון</TabsTrigger>
        </TabsList>
        
        {['all', 'pending', 'active', 'archived'].map(tab => (
          <TabsContent key={tab} value={tab} className="mt-6">
            {filterProposalsByStatus(tab).length > 0 ? (
              <div className="grid gap-4">
                {filterProposalsByStatus(tab).map(proposal => {
                  const project = projects[proposal.project_id];
                  return (
                    <Card key={proposal.id} className="overflow-hidden hover:shadow-md transition-shadow">
                      <CardContent className="p-5">
                        <div className="flex flex-col sm:flex-row justify-between items-start mb-2">
                          <div>
                            <span className="text-xs text-gray-500">הצעה עבור:</span>
                            <h3 className="font-semibold text-lg">
                              {project ? (
                                <Link to={createPageUrl(`Project?id=${project.id}`)} className="hover:text-blue-600 transition-colors">
                                  {project.title}
                                </Link>
                              ) : (
                                'טוען שם פרויקט...'
                              )}
                            </h3>
                          </div>
                          {getStatusBadge(proposal.status, project?.status)}
                        </div>
                        <div className="text-sm text-gray-500 mb-1">
                          הוגשה: {new Date(proposal.created_date).toLocaleDateString('he-IL')}
                          <span className="mx-2">|</span>
                          סכום מוצע: ₪{proposal.proposed_amount.toLocaleString()}
                        </div>
                        <p className="text-sm text-gray-700 line-clamp-2 mt-2 mb-3">
                          {proposal.cover_letter}
                        </p>
                        <div className="flex items-center justify-end">
                           <Button size="sm" asChild>
                             <Link to={createPageUrl(`Proposal?id=${proposal.id}`)}>
                               <Eye className="ml-1 rtl:mr-1 rtl:ml-0 h-4 w-4" /> צפה בפרטי ההצעה
                             </Link>
                           </Button>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-16 bg-gray-50 rounded-lg">
                <div className="bg-gray-100 inline-flex rounded-full p-3 mb-4">
                  <FileText className="h-6 w-6 text-gray-500" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-1">אין הצעות {tab === 'all' ? '' : 'בקטגוריה זו'}</h3>
                <p className="text-gray-500 mb-4">
                  {tab === 'all' 
                    ? 'עדיין לא הגשת הצעות. התחל לחפש פרויקטים!' 
                    : 'לא נמצאו הצעות העונות לקריטריונים.'
                  }
                </p>
                {tab === 'all' && (
                  <Button asChild>
                    <Link to={createPageUrl('SearchProjects')}>
                      <Search className="ml-2 rtl:mr-2 rtl:ml-0 h-4 w-4" />
                      חפש פרויקטים
                    </Link>
                  </Button>
                )}
              </div>
            )}
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}