import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { User } from '@/api/entities';
import { ServiceCategory } from '@/api/entities';
import { Review } from '@/api/entities';
import { Project } from '@/api/entities'; // To fetch project names for reviews
import { Star, Briefcase, MessageSquare, CalendarDays, Award, Loader2, AlertCircle, MapPin } from 'lucide-react';
import { createPageUrl } from '@/utils';

export default function FreelancerProfilePage() {
  const { id: freelancerId } = useParams();
  const [freelancer, setFreelancer] = useState(null);
  const [categories, setCategories] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [projectsForReviews, setProjectsForReviews] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      if (!freelancerId) {
        setError('מזהה פרילנסר לא תקין.');
        setIsLoading(false);
        return;
      }
      try {
        const [freelancerData, serviceCategoriesData, reviewsData] = await Promise.all([
          User.get(freelancerId),
          ServiceCategory.list(),
          Review.filter({ freelancer_id: freelancerId }, '-created_date')
        ]);

        if (!freelancerData || freelancerData.role !== 'freelancer') {
          setError('פרילנסר לא נמצא.');
          setFreelancer(null);
          setIsLoading(false);
          return;
        }
        
        setFreelancer(freelancerData);
        setCategories(serviceCategoriesData);
        setReviews(reviewsData);

        // Fetch project details for each review to display project title
        if (reviewsData.length > 0) {
          const projectIds = [...new Set(reviewsData.map(r => r.project_id))];
          const projects = await Promise.all(projectIds.map(pid => Project.get(pid).catch(() => null)));
          setProjectsForReviews(projects.filter(Boolean));
        }

      } catch (err) {
        console.error('Error fetching freelancer profile:', err);
        setError('אירעה שגיאה בטעינת פרופיל הפרילנסר.');
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [freelancerId]);

  const getCategoryNames = (categoryIds) => {
    if (!categoryIds || !categories.length) return [];
    return categoryIds.map(id => {
      const category = categories.find(c => c.id === id);
      return category ? category.name : '';
    }).filter(Boolean);
  };

  const getProjectTitleForReview = (projectId) => {
    const project = projectsForReviews.find(p => p.id === projectId);
    return project ? project.title : "פרויקט לא ידוע";
  };

  const calculateAverageRating = () => {
    if (!reviews || reviews.length === 0) return 0;
    const sum = reviews.reduce((acc, review) => acc + review.rating, 0);
    return (sum / reviews.length).toFixed(1);
  };

  const averageRating = calculateAverageRating();

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="text-center">
          <Loader2 className="h-12 w-12 animate-spin text-blue-600" />
          <p className="mt-4 text-lg">טוען פרופיל פרילנסר...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Card className="w-full max-w-md text-center">
          <CardContent className="pt-6">
            <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
            <h2 className="text-xl font-semibold mb-2">שגיאה</h2>
            <p className="text-gray-600">{error}</p>
            <Button asChild className="mt-6">
              <Link to={createPageUrl('SearchFreelancers')}>חזור לחיפוש פרילנסרים</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!freelancer) {
    // This case should ideally be covered by the error state, but as a fallback:
    return (
       <div className="flex justify-center items-center h-screen">
        <p>פרילנסר לא נמצא.</p>
      </div>
    );
  }
  
  const freelancerData = freelancer.freelancer_data || {};

  return (
    <div className="container mx-auto py-8 px-4 sm:px-6 lg:px-8 max-w-4xl">
      <Card className="overflow-hidden">
        <CardHeader className="bg-gradient-to-r from-blue-500 to-indigo-600 p-8 text-white">
          <div className="flex flex-col sm:flex-row items-center gap-6">
            <Avatar className="h-28 w-28 border-4 border-white shadow-lg">
              <AvatarImage src={freelancer.photo_url || `https://avatar.vercel.sh/${freelancer.email}.png`} alt={freelancer.full_name} />
              <AvatarFallback className="text-3xl bg-white text-blue-600">{freelancer.full_name ? freelancer.full_name.substring(0, 2).toUpperCase() : 'N/A'}</AvatarFallback>
            </Avatar>
            <div>
              <h1 className="text-3xl font-bold">{freelancer.full_name}</h1>
              <p className="text-lg opacity-90">
                {freelancerData.profession === 'accountant' && 'מנהל/ת חשבונות'}
                {freelancerData.profession === 'payroll_specialist' && 'חשב/ת שכר'}
                {freelancerData.profession === 'bookkeeper' && 'הנהלת חשבונות'}
              </p>
              <div className="flex items-center mt-2">
                <Star className="h-5 w-5 text-yellow-300 fill-yellow-300 mr-1 rtl:ml-1 rtl:mr-0" />
                <span className="text-lg font-semibold">{averageRating}</span>
                <span className="opacity-80 ml-1 rtl:mr-1 rtl:ml-0">({reviews.length} ביקורות)</span>
              </div>
            </div>
          </div>
        </CardHeader>

        <CardContent className="p-6 space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <InfoCard icon={<Briefcase className="h-6 w-6 text-blue-600" />} title="ניסיון" value={`${freelancerData.experience_years || 'לא צוין'} שנים`} />
            <InfoCard icon={<Award className="h-6 w-6 text-blue-600" />} title="דרגה" value={freelancerData.profession_level || 'לא צוין'} />
            <InfoCard icon={<CalendarDays className="h-6 w-6 text-blue-600" />} title="חבר מאז" value={new Date(freelancer.created_date).toLocaleDateString('he-IL')} />
          </div>
          
          {freelancer.address_city && (
            <div className="flex items-center text-gray-600">
              <MapPin className="h-5 w-5 mr-2 rtl:ml-2 rtl:mr-0 text-gray-400" />
              <span>{freelancer.address_city}</span>
            </div>
          )}

          <div>
            <h2 className="text-xl font-semibold mb-3 text-gray-800">אודותיי</h2>
            <p className="text-gray-600 whitespace-pre-wrap leading-relaxed">
              {freelancerData.about_me || 'מידע נוסף על פרילנסר זה יתווסף בקרוב.'}
            </p>
          </div>

          <div>
            <h2 className="text-xl font-semibold mb-3 text-gray-800">תחומי התמחות</h2>
            <div className="flex flex-wrap gap-2">
              {getCategoryNames(freelancerData.expertise_area_ids).map((name, index) => (
                <Badge key={index} variant="secondary" className="text-sm px-3 py-1">{name}</Badge>
              ))}
              {getCategoryNames(freelancerData.expertise_area_ids).length === 0 && (
                <p className="text-gray-500">לא צוינו תחומי התמחות.</p>
              )}
            </div>
          </div>

          {/* Contact section - Consider adding a "Contact Freelancer" button that links to a chat or project proposal */}
          <div className="text-center">
            <Button size="lg" className="bg-green-600 hover:bg-green-700" asChild>
              {/* Link to a contact page or direct message functionality. For now, placeholder. */}
              <Link to={createPageUrl('SearchProjects')}>
                <MessageSquare className="mr-2 rtl:ml-2 rtl:mr-0 h-5 w-5" />
                צור קשר עם {freelancer.full_name.split(' ')[0]}
              </Link>
            </Button>
            <p className="text-xs text-gray-500 mt-2">
              (ייקח אותך לדף חיפוש פרויקטים, שם תוכל ליצור פרויקט ולהזמין את הפרילנסר)
            </p>
          </div>
          
          <div className="border-t pt-6">
            <h2 className="text-xl font-semibold mb-4 text-gray-800">ביקורות אחרונות ({reviews.length})</h2>
            {reviews.length > 0 ? (
              <div className="space-y-6">
                {reviews.slice(0, 5).map(review => ( // Show latest 5 reviews
                  <Card key={review.id} className="bg-gray-50">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-1">
                         <h4 className="font-medium text-gray-700">
                           {review.reviewer_id === freelancer.id ? "תגובת פרילנסר" : `לקוח: ${review.reviewer_id_full_name || "אנונימי"}`}
                         </h4>
                        <div className="flex items-center">
                          {[...Array(5)].map((_, i) => (
                            <Star key={i} className={`h-4 w-4 ${i < review.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} />
                          ))}
                        </div>
                      </div>
                       <p className="text-xs text-gray-400 mb-2">
                        עבור פרויקט: "{getProjectTitleForReview(review.project_id)}" | {new Date(review.created_date).toLocaleDateString('he-IL')}
                      </p>
                      <p className="text-sm text-gray-600">{review.comment}</p>
                      {review.freelancer_response && (
                        <div className="mt-3 pt-3 border-t border-gray-200">
                          <p className="text-sm font-semibold text-blue-600">תגובת הפרילנסר:</p>
                          <p className="text-sm text-gray-600">{review.freelancer_response}</p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
                {reviews.length > 5 && (
                  <Button variant="link" className="w-full">טען עוד ביקורות</Button> 
                )}
              </div>
            ) : (
              <p className="text-gray-500">אין עדיין ביקורות עבור פרילנסר זה.</p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

const InfoCard = ({ icon, title, value }) => (
  <div className="bg-slate-50 p-4 rounded-lg flex items-center space-x-3 rtl:space-x-reverse shadow-sm">
    <div className="p-2 bg-blue-100 rounded-full">
      {icon}
    </div>
    <div>
      <p className="text-xs text-gray-500">{title}</p>
      <p className="text-md font-semibold text-gray-800">{value}</p>
    </div>
  </div>
);