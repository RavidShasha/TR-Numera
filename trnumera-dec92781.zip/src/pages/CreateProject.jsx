import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Checkbox } from '@/components/ui/checkbox';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { User } from '@/api/entities';
import { Project } from '@/api/entities';
import { ServiceCategory } from '@/api/entities';
import { AlertCircle, Loader2, FileQuestion } from 'lucide-react';

export default function CreateProjectPage() {
  const [user, setUser] = useState(null);
  const [categories, setCategories] = useState([]);
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [formState, setFormState] = useState({
    title: '',
    description: '',
    service_category_ids: [],
    budget_min: '',
    budget_max: '',
    project_type: 'one_time',
    is_urgent: false
  });

  // Fetch current user and service categories
  useEffect(() => {
    const fetchData = async () => {
      try {
        // Get current user
        const currentUser = await User.me();
        setUser(currentUser);
        
        // If user is not a client, redirect to profile completion
        if (currentUser && currentUser.role !== 'client') {
          navigate(createPageUrl('CompleteProfileClient'));
          return;
        }

        // Check if profile is complete
        if (currentUser && (!currentUser.phone_number || !currentUser.id_card_number)) {
          navigate(createPageUrl('CompleteProfileClient'));
          return;
        }
        
        // Fetch service categories
        const fetchedCategories = await ServiceCategory.list();
        setCategories(fetchedCategories);
        
      } catch (error) {
        console.error('Error fetching data:', error);
        setError('אירעה שגיאה בטעינת הנתונים. אנא נסה שנית מאוחר יותר.');
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [navigate]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormState({ ...formState, [name]: value });
  };

  const handleNumberChange = (e) => {
    const { name, value } = e.target;
    // Only allow numbers
    if (value === '' || /^\d+$/.test(value)) {
      setFormState({ ...formState, [name]: value });
    }
  };

  const handleCategoryChange = (categoryId) => {
    setFormState(prev => {
      const currentCategories = [...prev.service_category_ids];
      if (currentCategories.includes(categoryId)) {
        return {
          ...prev,
          service_category_ids: currentCategories.filter(id => id !== categoryId)
        };
      } else {
        return {
          ...prev,
          service_category_ids: [...currentCategories, categoryId]
        };
      }
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError('');

    try {
      if (!user) {
        throw new Error('משתמש לא מחובר');
      }

      // Validate form
      if (!formState.title.trim()) {
        throw new Error('נא להזין כותרת לפרויקט');
      }

      if (!formState.description.trim()) {
        throw new Error('נא להזין תיאור לפרויקט');
      }

      if (formState.service_category_ids.length === 0) {
        throw new Error('נא לבחור לפחות תחום שירות אחד');
      }

      // Convert budget values to numbers if they exist
      const projectData = {
        ...formState,
        client_id: user.id,
        budget_min: formState.budget_min ? Number(formState.budget_min) : undefined,
        budget_max: formState.budget_max ? Number(formState.budget_max) : undefined
      };

      // Create project
      const newProject = await Project.create(projectData);
      
      // Redirect to the newly created project
      navigate(createPageUrl(`Project?id=${newProject.id}`));
      
    } catch (error) {
      console.error('Error creating project:', error);
      setError(error.message || 'אירעה שגיאה ביצירת הפרויקט. אנא נסה שנית מאוחר יותר.');
      setIsSubmitting(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-80">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto text-blue-600" />
          <p className="mt-2">טוען נתונים...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">פרסם פרויקט חדש</h1>
      
      <form onSubmit={handleSubmit} className="space-y-8">
        <Card>
          <CardHeader>
            <CardTitle>פרטי הפרויקט</CardTitle>
            <CardDescription>
              הוסף את הפרטים המלאים של הפרויקט שלך כדי למשוך פרילנסרים מתאימים
            </CardDescription>
          </CardHeader>
          
          <CardContent className="space-y-6">
            {error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
            
            <div className="space-y-4">
              <div>
                <Label htmlFor="title">כותרת הפרויקט</Label>
                <Input
                  id="title"
                  name="title"
                  value={formState.title}
                  onChange={handleChange}
                  placeholder="לדוגמה: הנהלת חשבונות שוטפת לעסק קטן"
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="description">תיאור מפורט</Label>
                <Textarea
                  id="description"
                  name="description"
                  value={formState.description}
                  onChange={handleChange}
                  placeholder="תאר את הפרויקט, הדרישות והציפיות שלך בצורה מפורטת"
                  className="h-32"
                  required
                />
              </div>

              <div>
                <Label className="mb-2 block">תחומי שירות (בחר לפחות אחד)</Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {categories.length > 0 ? (
                    categories.map((category) => (
                      <div key={category.id} className="flex items-center space-x-2 rtl:space-x-reverse">
                        <Checkbox 
                          id={`category-${category.id}`}
                          checked={formState.service_category_ids.includes(category.id)}
                          onCheckedChange={() => handleCategoryChange(category.id)}
                        />
                        <Label htmlFor={`category-${category.id}`} className="cursor-pointer">
                          {category.name}
                        </Label>
                      </div>
                    ))
                  ) : (
                    <p className="text-sm text-gray-500">טוען תחומי שירות...</p>
                  )}
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="budget_min">תקציב מינימלי (₪)</Label>
                  <Input
                    id="budget_min"
                    name="budget_min"
                    value={formState.budget_min}
                    onChange={handleNumberChange}
                    placeholder="לדוגמה: 1000"
                  />
                </div>
                <div>
                  <Label htmlFor="budget_max">תקציב מקסימלי (₪)</Label>
                  <Input
                    id="budget_max"
                    name="budget_max"
                    value={formState.budget_max}
                    onChange={handleNumberChange}
                    placeholder="לדוגמה: 5000"
                  />
                </div>
              </div>
              
              <div>
                <Label className="mb-2 block">סוג הפרויקט</Label>
                <RadioGroup 
                  value={formState.project_type}
                  onValueChange={(value) => setFormState({...formState, project_type: value})}
                  className="flex space-x-4 rtl:space-x-reverse"
                >
                  <div className="flex items-center space-x-2 rtl:space-x-reverse">
                    <RadioGroupItem value="one_time" id="one_time" />
                    <Label htmlFor="one_time">חד פעמי</Label>
                  </div>
                  <div className="flex items-center space-x-2 rtl:space-x-reverse">
                    <RadioGroupItem value="ongoing" id="ongoing" />
                    <Label htmlFor="ongoing">מתמשך</Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="flex items-center space-x-2 rtl:space-x-reverse">
                <Switch 
                  id="is_urgent"
                  checked={formState.is_urgent}
                  onCheckedChange={(checked) => setFormState({...formState, is_urgent: checked})}
                />
                <Label htmlFor="is_urgent">פרויקט דחוף</Label>
              </div>
            </div>
          </CardContent>
          
          <CardFooter className="flex justify-between">
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => navigate(-1)}
              disabled={isSubmitting}
            >
              ביטול
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting && <Loader2 className="mr-2 rtl:ml-2 rtl:mr-0 h-4 w-4 animate-spin" />}
              פרסם פרויקט
            </Button>
          </CardFooter>
        </Card>
      </form>
      
      <Alert className="mt-8 bg-blue-50 border-blue-200">
        <FileQuestion className="h-5 w-5 text-blue-600" />
        <AlertDescription className="text-blue-700">
          לאחר פרסום הפרויקט, פרילנסרים רלוונטיים יוכלו לצפות בו ולהגיש לך הצעות.
          תוכל לעיין בהצעות, לדבר עם הפרילנסרים ולבחור את הפרילנסר המתאים ביותר עבורך.
        </AlertDescription>
      </Alert>
    </div>
  );
}