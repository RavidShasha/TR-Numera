import React, { useState, useEffect, useRef } from 'react';
import { useSearchParams, Link, useNavigate } from 'react-router-dom';
import { User } from '@/api/entities';
import { Project } from '@/api/entities';
import { Message } from '@/api/entities';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Textarea } from '@/components/ui/textarea';
import { createPageUrl } from '@/utils';
import { Send, Loader2, ArrowLeft, Paperclip } from 'lucide-react';

// This is a placeholder for a detailed Project Chat page
export default function ProjectChatPage() {
  const [searchParams] = useSearchParams();
  const projectId = searchParams.get('project_id');
  const participantId = searchParams.get('participant_id'); // The other user in the chat

  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [project, setProject] = useState(null);
  const [participant, setParticipant] = useState(null);
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [isSending, setIsSending] = useState(false);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(scrollToBottom, [messages]);

  useEffect(() => {
    const fetchChatData = async () => {
      if (!projectId || !participantId) {
        navigate(createPageUrl('Chat')); // Or some error page
        return;
      }
      try {
        const currentUser = await User.me();
        setUser(currentUser);

        const [projectData, participantData] = await Promise.all([
          Project.get(projectId),
          User.get(participantId),
        ]);
        setProject(projectData);
        setParticipant(participantData);

        // Fetch messages for this specific project and participant dyad
        // This query needs OR logic, which might not be directly supported by basic .filter()
        // Assuming a simplified fetch for now
        const projectMessages = await Message.filter(
          { project_id: projectId },
          'created_date', // Sort by creation date ascending
          100 // Limit to 100 messages for now
        );
        
        // Filter messages relevant to the current user and the other participant
        const relevantMessages = projectMessages.filter(
          msg => (msg.sender_id === currentUser.id && msg.receiver_id === participantId) ||
                 (msg.sender_id === participantId && msg.receiver_id === currentUser.id)
        );
        setMessages(relevantMessages);

        // Mark messages as read (basic implementation)
        // This would ideally be an API call to update is_read status
        relevantMessages.forEach(async (msg) => {
          if (msg.receiver_id === currentUser.id && !msg.is_read) {
            // await Message.update(msg.id, { is_read: true }); // Assuming Message SDK supports this
          }
        });

      } catch (error) {
        console.error("Error fetching project chat data:", error);
        // Handle error, e.g., navigate to an error page or show a message
      } finally {
        setIsLoading(false);
      }
    };

    fetchChatData();
  }, [projectId, participantId, navigate]);
  
  // Poll for new messages (simple polling, consider WebSockets for real-time)
  useEffect(() => {
    if (!projectId || !participantId || !user) return;

    const intervalId = setInterval(async () => {
      try {
        const latestMessages = await Message.filter(
          { project_id: projectId },
          'created_date',
          100
        );
        const relevantLatest = latestMessages.filter(
          msg => (msg.sender_id === user.id && msg.receiver_id === participantId) ||
                 (msg.sender_id === participantId && msg.receiver_id === user.id)
        );
        // Only update if there are new messages to avoid re-renders
        if (relevantLatest.length > messages.length || 
            (relevantLatest.length > 0 && messages.length > 0 && relevantLatest[relevantLatest.length - 1].id !== messages[messages.length-1].id)) {
          setMessages(relevantLatest);
        }
      } catch (error) {
        console.warn("Error polling for messages:", error);
      }
    }, 5000); // Poll every 5 seconds

    return () => clearInterval(intervalId);
  }, [projectId, participantId, user, messages.length]);


  const handleSendMessage = async () => {
    if (!newMessage.trim() || !user || !project || !participant) return;
    setIsSending(true);
    try {
      const messageData = {
        project_id: project.id,
        sender_id: user.id,
        receiver_id: participant.id,
        content: newMessage.trim(),
        is_read: false, // Default for new message
      };
      const sentMessage = await Message.create(messageData);
      setMessages(prevMessages => [...prevMessages, sentMessage]);
      setNewMessage('');
    } catch (error) {
      console.error("Error sending message:", error);
      // Show error to user
    } finally {
      setIsSending(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Loader2 className="h-12 w-12 animate-spin text-blue-600" />
      </div>
    );
  }

  if (!project || !participant || !user) {
    return (
      <div className="text-center py-10">
        <p>שגיאה בטעינת הצ'אט. נסה שוב מאוחר יותר.</p>
         <Button variant="outline" onClick={() => navigate(-1)} className="mt-4">
            <ArrowLeft className="ml-2 rtl:mr-2 rtl:ml-0 h-4 w-4" /> חזור
        </Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-4 h-[calc(100vh-100px)] flex flex-col max-w-3xl">
      <header className="p-4 border-b flex items-center gap-4 sticky top-0 bg-white z-10">
        <Button variant="ghost" size="icon" onClick={() => navigate(createPageUrl('Chat'))}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <Avatar className="h-10 w-10">
          <AvatarImage src={participant.photo_url || `https://avatar.vercel.sh/${participant.email}.png`} alt={participant.full_name} />
          <AvatarFallback>{participant.full_name ? participant.full_name.substring(0, 2).toUpperCase() : '??'}</AvatarFallback>
        </Avatar>
        <div>
          <h2 className="font-semibold text-md">{participant.full_name}</h2>
          <p className="text-xs text-gray-500">פרויקט: <Link to={createPageUrl(`Project?id=${project.id}`)} className="hover:underline">{project.title}</Link></p>
        </div>
      </header>

      <ScrollArea className="flex-grow p-4 space-y-4 bg-gray-50">
        {messages.map((msg, index) => (
          <div
            key={msg.id || index} // Use msg.id if available, otherwise index as fallback
            className={`flex ${msg.sender_id === user.id ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[70%] p-3 rounded-lg shadow ${
                msg.sender_id === user.id
                  ? 'bg-blue-500 text-white rounded-br-none'
                  : 'bg-white text-gray-800 rounded-bl-none border'
              }`}
            >
              <p className="text-sm">{msg.content}</p>
              <p className={`text-xs mt-1 ${msg.sender_id === user.id ? 'text-blue-200' : 'text-gray-400'}`}>
                {new Date(msg.created_date).toLocaleTimeString('he-IL', { hour: '2-digit', minute: '2-digit' })}
              </p>
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </ScrollArea>

      <footer className="p-4 border-t bg-white sticky bottom-0">
        <div className="flex items-center gap-2">
          <Textarea
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="כתוב הודעה..."
            className="flex-grow resize-none"
            rows={1}
            onKeyPress={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSendMessage();
              }
            }}
            disabled={isSending}
          />
          <Button type="button" onClick={handleSendMessage} disabled={isSending || !newMessage.trim()}>
            {isSending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          </Button>
          {/* Placeholder for file attachment
          <Button variant="ghost" size="icon" disabled={isSending}>
            <Paperclip className="h-4 w-4" />
          </Button>
          */}
        </div>
      </footer>
    </div>
  );
}