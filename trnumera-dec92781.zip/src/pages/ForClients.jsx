import React from 'react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { CheckCircle, UserCheck, FileText, MessageSquare, ArrowLeft } from 'lucide-react';

export default function ForClientsPage() {
  return (
    <div className="space-y-12">
      <section className="text-center py-16 bg-gradient-to-r from-indigo-500 to-purple-500 text-white rounded-xl shadow-xl">
        <h1 className="text-4xl md:text-5xl font-bold mb-6">מצא את המומחה המושלם לעסק שלך</h1>
        <p className="text-lg md:text-xl mb-10 max-w-2xl mx-auto">
          פרסם פרויקטים בתחומי החשבונאות והשכר וקבל הצעות מפרילנסרים מוכשרים ומאומתים. חסוך זמן וכסף, וקבל תוצאות מקצועיות.
        </p>
        <Button size="lg" className="bg-white text-indigo-600 hover:bg-gray-100 shadow-md" asChild>
          <Link to={createPageUrl('CreateProject')}>
            פרסם פרויקט חדש <ArrowLeft className="mr-2 rtl:ml-2 rtl:mr-0 h-5 w-5" />
          </Link>
        </Button>
      </section>

      <section>
        <h2 className="text-3xl font-semibold text-center mb-10 text-gray-800">למה לחפש פרילנסרים דרכנו?</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          <FeatureCard
            icon={<UserCheck className="w-8 h-8 text-blue-500" />}
            title="פרילנסרים מאומתים ומקצועיים"
            description="כל הפרילנסרים בפלטפורמה עוברים תהליך אימות קפדני, כולל בדיקת תעודות וניסיון."
          />
          <FeatureCard
            icon={<FileText className="w-8 h-8 text-green-500" />}
            title="פרסום פרויקטים קל ומהיר"
            description="הגדר את דרישות הפרויקט שלך בקלות, קבע תקציב וקבל הצעות מותאמות מפרילנסרים רלוונטיים."
          />
          <FeatureCard
            icon={<MessageSquare className="w-8 h-8 text-purple-500" />}
            title="תקשורת וניהול פשוטים"
            description="נהל את כל התקשורת, שיתוף הקבצים והמעקב אחר התקדמות הפרויקט במקום אחד."
          />
          <FeatureCard
            icon={<CheckCircle className="w-8 h-8 text-orange-500" />}
            title="שקיפות מלאה"
            description="צפה בפרופילים של פרילנסרים, קרא ביקורות מלקוחות קודמים ובחר את המועמד המתאים ביותר עבורך."
          />
           <FeatureCard
            icon={<DollarSign className="w-8 h-8 text-red-500" />}
            title="תשלום מאובטח"
            description="שלם רק לאחר השלמת הפרויקט לשביעות רצונך, באמצעות מנגנון תשלום מאובטח."
          />
           <FeatureCard
            icon={<ShieldCheck className="w-8 h-8 text-indigo-500" />} // Re-used ShieldCheck
            title="חסכון בזמן ובעלויות"
            description="קבל גישה למאגר גדול של מומחים ללא צורך בתהליכי גיוס ארוכים ויקרים."
          />
        </div>
      </section>
      
      <section className="bg-gray-100 p-8 rounded-xl">
        <h2 className="text-3xl font-semibold text-center mb-8 text-gray-800">כך תמצא את הפרילנסר הבא שלך:</h2>
        <ol className="relative border-r border-gray-300 dark:border-gray-700 space-y-8 mr-4 rtl:border-l rtl:border-r-0 rtl:ml-4 rtl:mr-0">
          <StepItem number="1" title="הרשמה כלקוח">
            צור חשבון לקוח תוך דקות ספורות. ההרשמה חינמית וללא התחייבות.
          </StepItem>
          <StepItem number="2" title="פרסם את הפרויקט שלך">
            תאר את המשימה, הגדר את הדרישות, ציין תקציב ולוחות זמנים. ככל שתהיה מפורט יותר, כך תקבל הצעות טובות יותר.
          </StepItem>
          <StepItem number="3" title="קבל ובדוק הצעות">
            פרילנסרים רלוונטיים יגישו לך הצעות. תוכל לעיין בפרופילים שלהם, בדירוגים ובהצעות המחיר.
          </StepItem>
           <StepItem number="4" title="בחר פרילנסר והתחל לעבוד">
            בחר את הפרילנסר המתאים ביותר, סגור את תנאי העבודה והתחילו את הפרויקט. שלם בסיום ובבטחה.
          </StepItem>
        </ol>
      </section>

       <section className="text-center py-12">
        <h2 className="text-3xl font-semibold mb-6 text-gray-800">זקוק לעזרה?</h2>
        <p className="text-lg text-gray-600 mb-8 max-w-xl mx-auto">
          אנו כאן כדי לסייע לך למצוא את הפתרון הטוב ביותר לצרכים החשבונאיים שלך.
        </p>
        <Button size="lg" asChild>
          <Link to={createPageUrl('Register', { role: 'client' })}>
            הירשם עכשיו והתחל לחפש <ArrowLeft className="mr-2 rtl:ml-2 rtl:mr-0 h-5 w-5" />
          </Link>
        </Button>
      </section>
    </div>
  );
}

const FeatureCard = ({ icon, title, description }) => (
  <div className="p-6 bg-white rounded-lg shadow-lg hover:shadow-xl transition-shadow">
    <div className="flex justify-center items-center mb-4">
      {icon}
    </div>
    <h3 className="text-xl font-semibold mb-2 text-center">{title}</h3>
    <p className="text-gray-600 text-center">{description}</p>
  </div>
);

const StepItem = ({ number, title, children }) => (
  <li className="mb-10 mr-6 rtl:ml-6 rtl:mr-0">
    <span className="absolute flex items-center justify-center w-8 h-8 bg-purple-100 rounded-full -right-4 ring-4 ring-white dark:ring-gray-900 dark:bg-purple-900 rtl:-left-4 rtl:-right-auto">
      <span className="font-bold text-purple-600">{number}</span>
    </span>
    <h3 className="flex items-center mb-1 text-lg font-semibold text-gray-900 dark:text-white">
      {title}
    </h3>
    <p className="block mb-2 text-sm font-normal leading-none text-gray-500 dark:text-gray-500">
      {children}
    </p>
  </li>
);

// Placeholder icons if not imported globally
const DollarSign = (props) => (
 <svg {...props} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <line x1="12" y1="1" x2="12" y2="23"></line>
    <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
  </svg>
);
const ShieldCheck = (props) => (
  <svg {...props} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
    <path d="m9 12 2 2 4-4"></path>
  </svg>
);