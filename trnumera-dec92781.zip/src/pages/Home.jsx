import React from 'react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { ArrowLeft, Search, UserPlus, Briefcase as BriefcaseIcon } from 'lucide-react'; // Added BriefcaseIcon import

export default function HomePage() {
  return (
    <div className="space-y-12">
      <section className="text-center py-16 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl shadow-xl">
        <h1 className="text-4xl md:text-5xl font-bold mb-6">מצא את הפרילנסר המושלם, או את הפרויקט הבא שלך</h1>
        <p className="text-lg md:text-xl mb-10 max-w-2xl mx-auto">
          הפלטפורמה המובילה בישראל לחיבור בין מנהלי חשבונות וחשבי שכר לבין לקוחות הזקוקים לשירותיהם.
        </p>
        <div className="flex flex-col sm:flex-row justify-center items-center gap-4">
          <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100 shadow-md" asChild>
            <Link to={createPageUrl('SearchProjects')}>
              <Search className="ml-2 rtl:mr-2 rtl:ml-0 h-5 w-5" />
              חפש פרויקטים
            </Link>
          </Button>
          <Button size="lg" variant="outline" className="text-white border-white hover:bg-white hover:text-blue-600 shadow-md" asChild>
            <Link to={createPageUrl('Register')}>
              <UserPlus className="ml-2 rtl:mr-2 rtl:ml-0 h-5 w-5" />
              הצטרף כפרילנסר
            </Link>
          </Button>
        </div>
      </section>

      <section>
        <h2 className="text-3xl font-semibold text-center mb-10 text-gray-800">איך זה עובד?</h2>
        <div className="grid md:grid-cols-3 gap-8 text-center">
          <div className="p-6 bg-white rounded-lg shadow-lg hover:shadow-xl transition-shadow">
            <div className="bg-blue-100 text-blue-600 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
              <UserPlus className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-semibold mb-2">1. הרשמה קלה</h3>
            <p className="text-gray-600">לקוחות ופרילנסרים נרשמים במהירות ומקימים פרופיל מקצועי.</p>
          </div>
          <div className="p-6 bg-white rounded-lg shadow-lg hover:shadow-xl transition-shadow">
            <div className="bg-green-100 text-green-600 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
              <Search className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-semibold mb-2">2. חיפוש והתאמה</h3>
            <p className="text-gray-600">לקוחות מפרסמים פרויקטים, פרילנסרים מגישים הצעות או מחפשים פרויקטים רלוונטיים.</p>
          </div>
          <div className="p-6 bg-white rounded-lg shadow-lg hover:shadow-xl transition-shadow">
            <div className="bg-purple-100 text-purple-600 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
              <BriefcaseIcon className="w-8 h-8" /> {/* Used BriefcaseIcon */}
            </div>
            <h3 className="text-xl font-semibold mb-2">3. ביצוע ותשלום</h3>
            <p className="text-gray-600">עבודה משותפת, תקשורת מאובטחת וניהול תשלומים פשוט ובטוח.</p>
          </div>
        </div>
      </section>

      <section className="bg-gray-100 p-8 rounded-xl">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="text-3xl font-semibold mb-4 text-gray-800">למה לבחור בנו?</h2>
            <ul className="space-y-3 text-gray-700">
              <li className="flex items-start">
                <CheckCircle className="w-6 h-6 text-green-500 mr-2 rtl:ml-2 rtl:mr-0 mt-1" />
                <span>מאגר פרילנסרים איכותי ומאומת בתחומי החשבונאות והשכר.</span>
              </li>
              <li className="flex items-start">
                <CheckCircle className="w-6 h-6 text-green-500 mr-2 rtl:ml-2 rtl:mr-0 mt-1" />
                <span>פלטפורמה מאובטחת ונוחה לשימוש עם תמיכה מלאה בעברית.</span>
              </li>
              <li className="flex items-start">
                <CheckCircle className="w-6 h-6 text-green-500 mr-2 rtl:ml-2 rtl:mr-0 mt-1" />
                <span>תהליך שקוף והוגן לפרסום פרויקטים, הגשת הצעות ובחירת פרילנסרים.</span>
              </li>
              <li className="flex items-start">
                <CheckCircle className="w-6 h-6 text-green-500 mr-2 rtl:ml-2 rtl:mr-0 mt-1" />
                <span>כלים לניהול פרויקטים, תקשורת ותשלומים במקום אחד.</span>
              </li>
            </ul>
          </div>
          <div className="text-center">
            {/* You can add an illustrative image or graphic here */}
            <img src="https://via.placeholder.com/400x300.png?text=Image+Placeholder" alt="Illustrative" className="rounded-lg shadow-md mx-auto" />
          </div>
        </div>
      </section>

      <section className="text-center py-12">
        <h2 className="text-3xl font-semibold mb-6 text-gray-800">מוכנים להתחיל?</h2>
        <p className="text-lg text-gray-600 mb-8 max-w-xl mx-auto">
          הצטרפו עוד היום לקהילת הפרילנסרים והלקוחות שלנו ובואו נצמח יחד.
        </p>
        <div className="flex flex-col sm:flex-row justify-center items-center gap-4">
          <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white" asChild>
            <Link to={createPageUrl('ForFreelancers')}>
              אני פרילנסר/ית <ArrowLeft className="mr-2 rtl:ml-2 rtl:mr-0 h-5 w-5" />
            </Link>
          </Button>
          <Button size="lg" className="bg-green-600 hover:bg-green-700 text-white" asChild>
            <Link to={createPageUrl('ForClients')}>
              אני לקוח/ה <ArrowLeft className="mr-2 rtl:ml-2 rtl:mr-0 h-5 w-5" />
            </Link>
          </Button>
        </div>
      </section>
    </div>
  );
}

// Helper component, you might want to move it to a shared icons file if used elsewhere
const CheckCircle = (props) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
    <polyline points="22 4 12 14.01 9 11.01"></polyline>
  </svg>
);