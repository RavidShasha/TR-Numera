import Layout from "./Layout.jsx";

import Home from "./Home";

import ForFreelancers from "./ForFreelancers";

import ForClients from "./ForClients";

import About from "./About";

import TermsOfService from "./TermsOfService";

import PrivacyPolicy from "./PrivacyPolicy";

import CompleteProfileFreelancer from "./CompleteProfileFreelancer";

import CompleteProfileClient from "./CompleteProfileClient";

import ProfileSettings from "./ProfileSettings";

import ClientDashboard from "./ClientDashboard";

import FreelancerDashboard from "./FreelancerDashboard";

import AdminDashboard from "./AdminDashboard";

import CreateProject from "./CreateProject";

import MyProjectsClient from "./MyProjectsClient";

import Project from "./Project";

import SubmitProposal from "./SubmitProposal";

import ProjectProposals from "./ProjectProposals";

import Proposal from "./Proposal";

import MyProposals from "./MyProposals";

import SearchProjects from "./SearchProjects";

import SearchFreelancers from "./SearchFreelancers";

import FreelancerProfile from "./FreelancerProfile";

import MyProjectsFreelancer from "./MyProjectsFreelancer";

import Chat from "./Chat";

import ProjectChat from "./ProjectChat";

import AdminUsers from "./AdminUsers";

import AdminProjects from "./AdminProjects";

import AdminCategories from "./AdminCategories";

import Notifications from "./Notifications";

import RoleSelection from "./RoleSelection";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Home: Home,
    
    ForFreelancers: ForFreelancers,
    
    ForClients: ForClients,
    
    About: About,
    
    TermsOfService: TermsOfService,
    
    PrivacyPolicy: PrivacyPolicy,
    
    CompleteProfileFreelancer: CompleteProfileFreelancer,
    
    CompleteProfileClient: CompleteProfileClient,
    
    ProfileSettings: ProfileSettings,
    
    ClientDashboard: ClientDashboard,
    
    FreelancerDashboard: FreelancerDashboard,
    
    AdminDashboard: AdminDashboard,
    
    CreateProject: CreateProject,
    
    MyProjectsClient: MyProjectsClient,
    
    Project: Project,
    
    SubmitProposal: SubmitProposal,
    
    ProjectProposals: ProjectProposals,
    
    Proposal: Proposal,
    
    MyProposals: MyProposals,
    
    SearchProjects: SearchProjects,
    
    SearchFreelancers: SearchFreelancers,
    
    FreelancerProfile: FreelancerProfile,
    
    MyProjectsFreelancer: MyProjectsFreelancer,
    
    Chat: Chat,
    
    ProjectChat: ProjectChat,
    
    AdminUsers: AdminUsers,
    
    AdminProjects: AdminProjects,
    
    AdminCategories: AdminCategories,
    
    Notifications: Notifications,
    
    RoleSelection: RoleSelection,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Home />} />
                
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/ForFreelancers" element={<ForFreelancers />} />
                
                <Route path="/ForClients" element={<ForClients />} />
                
                <Route path="/About" element={<About />} />
                
                <Route path="/TermsOfService" element={<TermsOfService />} />
                
                <Route path="/PrivacyPolicy" element={<PrivacyPolicy />} />
                
                <Route path="/CompleteProfileFreelancer" element={<CompleteProfileFreelancer />} />
                
                <Route path="/CompleteProfileClient" element={<CompleteProfileClient />} />
                
                <Route path="/ProfileSettings" element={<ProfileSettings />} />
                
                <Route path="/ClientDashboard" element={<ClientDashboard />} />
                
                <Route path="/FreelancerDashboard" element={<FreelancerDashboard />} />
                
                <Route path="/AdminDashboard" element={<AdminDashboard />} />
                
                <Route path="/CreateProject" element={<CreateProject />} />
                
                <Route path="/MyProjectsClient" element={<MyProjectsClient />} />
                
                <Route path="/Project" element={<Project />} />
                
                <Route path="/SubmitProposal" element={<SubmitProposal />} />
                
                <Route path="/ProjectProposals" element={<ProjectProposals />} />
                
                <Route path="/Proposal" element={<Proposal />} />
                
                <Route path="/MyProposals" element={<MyProposals />} />
                
                <Route path="/SearchProjects" element={<SearchProjects />} />
                
                <Route path="/SearchFreelancers" element={<SearchFreelancers />} />
                
                <Route path="/FreelancerProfile" element={<FreelancerProfile />} />
                
                <Route path="/MyProjectsFreelancer" element={<MyProjectsFreelancer />} />
                
                <Route path="/Chat" element={<Chat />} />
                
                <Route path="/ProjectChat" element={<ProjectChat />} />
                
                <Route path="/AdminUsers" element={<AdminUsers />} />
                
                <Route path="/AdminProjects" element={<AdminProjects />} />
                
                <Route path="/AdminCategories" element={<AdminCategories />} />
                
                <Route path="/Notifications" element={<Notifications />} />
                
                <Route path="/RoleSelection" element={<RoleSelection />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}